package ru.pcmod.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.nbt.NBTTagCompound;

/**
 * Графический рабочий стол PCOS и PixelOS: окна, панель задач, меню «Пуск», мышь.
 * В PixelOS поверх клеток рисуются пиксельные иконки (слой Screen.sprite), плюс есть приложение Paint.
 * Рисуется на текстовом экране 60x22: цветные «пиксели» — это пробелы с инверсией
 * (цвет заливки = цвет символа, сам текст при этом чёрный).
 */
public class Desktop {
    static final int W = Screen.W, TB = Screen.H - 1;
    static final int TEAL = 3, GRAY = 7, WHITE = 15, CYAN = 11, GREEN = 10, RED = 12, YELLOW = 14;
    static final int MAXWIN = 5, NOTE_MAX = 31, NOTE_LINES = 200;
    static final int INFO = 0, FILES = 1, NOTE = 2, CALC = 3, CHAT = 4, NETW = 5, PAINT = 6, SHOP = 7, BANK = 8;
    static final int LW = 14;

    static final String[] MENU = {"My Computer", "Files", "Notepad", "Calculator", "Chat", "Network", "Shop", "Bank", "Terminal", "Restart", "Shut down"};
    /** Действие (menuAction) для каждого пункта классического меню и значка. */
    static final int[] MENU_ACT = {0, 1, 2, 3, 4, 5, 10, 11, 6, 7, 8};
    static final String[] ICON_TAG = {"PC", "DIR", "TXT", "123", "MSG", "NET", "SHP", "BNK", ">_"};
    static final String[] ICON_NAME = {"My PC", "Files", "Notepad", "Calc", "Chat", "Network", "Shop", "Bank", "Terminal"};
    static final int[] ICON_ACT = {0, 1, 2, 3, 4, 5, 10, 11, 6};
    static final String[] SHORT = {"My PC", "Files", "Note", "Calc", "Chat", "Net", "Paint", "Shop", "Bank"};

    // ---- PixelOS ----
    static final int PBG = 8, PTITLE = 13, PMW = 17, PW = 16, PH = 12;
    /** Пункты меню PixelOS: подпись, иконка, действие (номер для menuAction). */
    static final String[] PMENU = {"My Computer", "Files", "Notepad", "Calculator", "Paint", "Chat", "Network", "Shop", "Bank", "Console", "Restart", "Shut down"};
    static final int[] PMENU_SPR = {Sprites.PC, Sprites.FILES, Sprites.NOTE, Sprites.CALC, Sprites.PAINT, Sprites.CHAT,
            Sprites.NET, Sprites.SHOP, Sprites.BANK, Sprites.TERM, Sprites.RESTART, Sprites.POWER};
    static final int[] PMENU_ACT = {0, 1, 2, 3, 9, 4, 5, 10, 11, 6, 7, 8};
    /** Меню PixelOS в два столбца по 6 пунктов. */
    static final int PMENU_ROWS = 6;
    /** Значки рабочего стола PixelOS (столбцы по четыре). */
    static final String[] PNAME = {"My PC", "Files", "Notepad", "Calc", "Chat", "Network", "Console", "Paint", "Shop", "Bank"};
    static final int[] PICON_ACT = {0, 1, 2, 3, 4, 5, 6, 9, 10, 11};
    static final int[] PICON_SPR = {Sprites.PC, Sprites.FILES, Sprites.NOTE, Sprites.CALC, Sprites.CHAT, Sprites.NET,
            Sprites.TERM, Sprites.PAINT, Sprites.SHOP, Sprites.BANK};
    static final String[] PSHORT = {"PC", "File", "Note", "Calc", "Chat", "Net", "Art", "Shop", "Bank"};
    /** Иконка окна по его типу. */
    static final int[] TYPE_SPR = {Sprites.PC, Sprites.FILES, Sprites.NOTE, Sprites.CALC, Sprites.CHAT, Sprites.NET,
            Sprites.PAINT, Sprites.SHOP, Sprites.BANK};
    static final String[][] CALC_KEYS = {
            {"C", "<", "/", "*"},
            {"7", "8", "9", "-"},
            {"4", "5", "6", "+"},
            {"1", "2", "3", "="},
            {"0", ".", "", ""}};

    static class Win {
        int type, x, y, w, h;
        boolean min;
        // Files
        String dir = "/";
        List<String> names = new ArrayList<String>();
        int sel = -1, scroll;
        String msg = "";
        // Notepad
        String path = "";
        List<StringBuilder> lines = new ArrayList<StringBuilder>();
        int cr, cc, top;
        boolean mod;
        // Calculator
        String entry = "0";
        double acc;
        char op;
        boolean fresh, err;
        // Chat / Network
        String fNick = "", fPass = "", fIn = "", cerr = "", peer = ChatStore.GENERAL;
        int focus, cscroll, mtop;
        // Shop / Bank
        long epoch = -1;
        boolean msgOk;
        // Paint
        int[] art;
        int pcol = 12;
        String amsg = "";
    }

    final ComputerLogic l;
    final Screen s;
    final boolean pixel;
    final List<Win> wins = new ArrayList<Win>();
    boolean menu;
    boolean caret;
    String lastSig = "";
    int spawn;

    public Desktop(ComputerLogic l) {
        this.l = l;
        this.s = l.s;
        this.pixel = l.isPixel();
    }

    // ===================== вспомогательное =====================
    static String cut(String x, int n) {
        if (n <= 0) return "";
        return x.length() <= n ? x : x.substring(0, n);
    }

    static String padR(String x, int n) {
        StringBuilder b = new StringBuilder(cut(x, n));
        while (b.length() < n) b.append(' ');
        return b.toString();
    }

    static String padL(String x, int n) {
        StringBuilder b = new StringBuilder();
        for (int i = x.length(); i < n; i++) b.append(' ');
        return b.append(cut(x, n)).toString();
    }

    static String lab(PartSpec p) {
        return p == null ? "none" : p.label;
    }

    void fill(int x, int y, int w, int h, int col) {
        for (int yy = y; yy < y + h; yy++) {
            for (int xx = x; xx < x + w; xx++) s.put(xx, yy, ' ', col | 16);
        }
    }

    void txt(int x, int y, String str, int col) {
        s.text(x, y, str, col | 16);
    }

    Win top() {
        for (int i = wins.size() - 1; i >= 0; i--) {
            if (!wins.get(i).min) return wins.get(i);
        }
        return null;
    }

    void raise(Win w) {
        wins.remove(w);
        w.min = false;
        wins.add(w);
    }

    void close(Win w) {
        if (w.type == NOTE && w.mod) noteSave(w);
        wins.remove(w);
    }

    // ===================== открытие окон =====================
    Win open(int type) {
        if (type != NOTE) {
            for (Win e : wins) {
                if (e.type == type) {
                    raise(e);
                    return e;
                }
            }
        }
        if (wins.size() >= MAXWIN) return null;
        Win w = new Win();
        w.type = type;
        w.w = type == SHOP ? 56 : type == BANK ? 44 : type == PAINT ? 36 : type == INFO ? 36 : type == FILES ? 34 : type == NOTE ? 36 : type == CHAT ? 52 : type == NETW ? 40 : 22;
        w.h = type == SHOP ? 19 : type == BANK ? 17 : type == PAINT ? 17 : type == INFO ? 14 : type == FILES ? 14 : type == NOTE ? 15 : type == CHAT ? 18 : type == NETW ? 15 : 13;
        w.x = (pixel ? 16 : 11) + (spawn % 4) * 3;
        w.y = 1 + spawn % 3;
        spawn++;
        if (w.x + w.w > W) w.x = W - w.w;
        if (w.y + w.h > TB) w.y = TB - w.h;
        if (w.x < 0) w.x = 0;
        if (w.y < 0) w.y = 0;
        if (type == CHAT) {
            w.fNick = l.chat.savedNick();
            w.focus = w.fNick.length() > 0 ? 1 : 0;
        }
        if (type == NETW || type == SHOP) w.sel = -1;
        if (type == PAINT) {
            w.art = new int[PW * PH];
            paintLoad(w);
        }
        if (type == FILES) {
            NBTTagCompound r = l.root();
            w.dir = "/home/" + l.user;
            if (r == null || !VFS.isDir(r, w.dir)) w.dir = "/";
            filesRefresh(w);
        }
        wins.add(w);
        return w;
    }

    void openNotepad(String path) {
        for (Win e : wins) {
            if (e.type == NOTE && e.path.equals(path)) {
                raise(e);
                return;
            }
        }
        Win w = open(NOTE);
        if (w == null) return;
        w.path = path;
        NBTTagCompound r = l.root();
        String txt = r == null ? null : VFS.read(r, path);
        if (txt == null) txt = "";
        if (txt.endsWith("\n")) txt = txt.substring(0, txt.length() - 1);
        for (String ln : txt.split("\n", -1)) w.lines.add(new StringBuilder(ln));
        if (w.lines.isEmpty()) w.lines.add(new StringBuilder());
    }

    void menuAction(int i) {
        switch (i) {
            case 0: open(INFO); break;
            case 1: open(FILES); break;
            case 2: openNotepad("/home/" + l.user + "/notes.txt"); break;
            case 3: open(CALC); break;
            case 4: open(CHAT); break;
            case 5: open(NETW); break;
            case 6: l.enterTerminal(); break;
            case 7: l.startUp(); break;
            case 8: l.shutDown(null); break;
            case 9: open(PAINT); break;
            case 10: open(SHOP); break;
            case 11: open(BANK); break;
            default: break;
        }
    }

    // ===================== отрисовка =====================
    String sig() {
        boolean info = false;
        for (Win w : wins) {
            if (w.type == INFO && !w.min) info = true;
        }
        return l.clock() + "|" + (info ? (int) l.t.temp : -1) + "|" + l.chat.rev + ":" + l.chat.totalUnread() + "|" + l.link().sig() + "|" + shopSig();
    }

    public void tick() {
        if (!sig().equals(lastSig)) draw();
    }

    /** Какой диалог сейчас на экране (для него не копятся непрочитанные). */
    void updateViewing() {
        Win tp = top();
        if (tp != null && tp.type == CHAT && l.chat.nick != null) {
            l.chat.viewing = tp.peer;
            l.chat.unread.remove(tp.peer);
        } else {
            l.chat.viewing = null;
        }
    }

    public void draw() {
        updateViewing();
        s.clear();
        caret = false;
        if (pixel) {
            drawPixelBg();
        } else {
            fill(0, 0, W, TB, TEAL);
            for (int i = 0; i < ICON_NAME.length; i++) {
                int ix = 2 + 9 * (i / 5), y = 1 + 3 * (i % 5);
                String tag = ICON_TAG[i];
                String g = padR(" " + tag, 6);
                txt(ix, y, g, WHITE);
                txt(ix, y + 1, cut(ICON_NAME[i], 8), TEAL);
            }
        }
        Win tp = top();
        for (Win w : wins) {
            if (!w.min) drawWin(w, w == tp);
        }
        drawTaskbar();
        if (menu) drawMenu();
        if (pixel) drawPixelSprites();
        s.cursor = caret;
        lastSig = sig();
    }

    void drawTaskbar() {
        fill(0, TB, W, 1, GRAY);
        txt(0, TB, pixel ? "  Start" : " Start ", menu ? CYAN : (pixel ? PTITLE : GREEN));
        Win tp = top();
        for (int i = 0; i < wins.size() && i < MAXWIN; i++) {
            Win w = wins.get(i);
            String nm = pixel ? PSHORT[w.type] : SHORT[w.type];
            int un = l.chat.totalUnread();
            if (w.type == CHAT && un > 0) nm = "Msg" + (un > 9 ? "+" : String.valueOf(un));
            String lab = pixel ? "  " + padR(nm, 4) + " " : " " + padR(nm, 5) + " ";
            txt(8 + 7 * i, TB, lab, w == tp ? CYAN : (w.min ? YELLOW : WHITE));
        }
        String clk = l.clock();
        int unr = l.chat.totalUnread();
        if (unr > 0) {
            String m = " MSG " + (unr > 9 ? "9+" : String.valueOf(unr)) + " ";
            txt(W - clk.length() - m.length() - 2, TB, m, YELLOW);
        }
        txt(W - clk.length() - 1, TB, clk, GRAY);
    }

    void drawMenu() {
        if (pixel) {
            drawPixelMenu();
            return;
        }
        int y0 = TB - MENU.length;
        fill(0, y0, 16, MENU.length, WHITE);
        fill(0, y0, 1, MENU.length, GRAY);
        for (int i = 0; i < MENU.length; i++) txt(2, y0 + i, padR(MENU[i], 13), WHITE);
    }

    void drawWin(Win w, boolean active) {
        int tc = active ? (pixel ? PTITLE : CYAN) : GRAY;
        fill(w.x, w.y, w.w, w.h, GRAY);
        fill(w.x + 1, w.y + 1, w.w - 2, w.h - 2, WHITE);
        fill(w.x, w.y, w.w, 1, tc);
        String title;
        if (w.type == INFO) title = "My Computer";
        else if (w.type == FILES) title = "Files - " + w.dir;
        else if (w.type == NOTE) title = "Notepad - " + VFS.name(w.path);
        else if (w.type == CHAT) title = l.chat.nick != null ? "Chat - " + l.chat.nick : "Chat";
        else if (w.type == NETW) title = "Network";
        else if (w.type == PAINT) title = "Paint - art.px";
        else if (w.type == SHOP) title = "Shop - internet store";
        else if (w.type == BANK) title = "Bank";
        else title = "Calculator";
        txt(w.x + 1, w.y, cut(title, w.w - 9), tc);
        txt(w.x + w.w - 7, w.y, " _ ", GRAY);
        txt(w.x + w.w - 4, w.y, " X ", RED);
        if (w.type == INFO) drawInfo(w);
        else if (w.type == FILES) drawFiles(w);
        else if (w.type == NOTE) drawNote(w, active);
        else if (w.type == CHAT) drawChat(w, active);
        else if (w.type == NETW) drawNet(w, active);
        else if (w.type == PAINT) drawPaint(w);
        else if (w.type == SHOP) drawShop(w, active);
        else if (w.type == BANK) drawBank(w, active);
        else drawCalc(w);
    }

    List<String> infoLines() {
        TileComputer t = l.t;
        PartSpec cpu = t.spec(TileComputer.CPU), mb = t.spec(TileComputer.MB), gpu = t.spec(TileComputer.GPU),
                sto = t.spec(TileComputer.STORAGE), cool = t.spec(TileComputer.COOLER), psu = t.spec(TileComputer.PSU);
        PartSpec ram = null;
        for (int i = TileComputer.RAM0; i <= TileComputer.RAM3 && ram == null; i++) ram = t.spec(i);
        int mon = t.monitorType();
        List<String> o = new ArrayList<String>();
        o.add(pixel ? "PixelOS 1.0 Desktop" : "PCOS Desktop 2.0");
        o.add("User   : " + l.user + "@" + l.host);
        o.add("CPU    : " + lab(cpu) + "  " + (cpu == null ? 0 : cpu.cores) + "c "
                + (cpu == null ? 0.0 : cpu.ghz) + " GHz");
        o.add("Board  : " + lab(mb) + (mb == null ? "" : " (" + PartSpec.socketName(mb.socket) + ")"));
        o.add("RAM    : " + t.totalRamMB() + " MB " + (ram == null ? "" : PartSpec.ramName(ram.ramType)));
        o.add("GPU    : " + lab(gpu) + "  " + (gpu == null ? 0 : gpu.vram) + " MB");
        o.add("Disk   : " + lab(sto) + " (" + (sto == null ? 0 : sto.storageKB) + " KB)");
        o.add("Cooler : " + lab(cool));
        o.add("PSU    : " + (psu == null ? 0 : psu.watts) + " W, load " + t.requiredWatts() + " W");
        o.add("Temp   : " + (int) t.temp + " C");
        o.add("Screen : " + (mon < 0 ? "none" : MonitorType.get(mon).name));
        o.add("Net    : " + l.link().describe());
        return o;
    }

    void drawInfo(Win w) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2, ih = w.h - 2;
        List<String> lines = infoLines();
        for (int i = 0; i < lines.size() && i < ih; i++) txt(ix + 1, iy + i, cut(lines.get(i), iw - 2), WHITE);
    }

    // ---------- Files ----------
    void filesRefresh(Win w) {
        NBTTagCompound r = l.root();
        if (r == null) return;
        w.names = VFS.listDir(r, w.dir);
        if (w.sel >= w.names.size()) w.sel = w.names.size() - 1;
        int rows = w.h - 5;
        if (w.scroll > Math.max(0, w.names.size() - rows)) w.scroll = Math.max(0, w.names.size() - rows);
    }

    void filesUp(Win w) {
        w.dir = VFS.parent(w.dir);
        w.sel = -1;
        w.scroll = 0;
        w.msg = "";
        filesRefresh(w);
    }

    void filesOpen(Win w) {
        if (w.sel < 0 || w.sel >= w.names.size()) return;
        String n = w.names.get(w.sel);
        if (n.endsWith("/")) {
            w.dir = VFS.resolve(w.dir, n.substring(0, n.length() - 1));
            w.sel = -1;
            w.scroll = 0;
            w.msg = "";
            filesRefresh(w);
        } else {
            openNotepad(VFS.resolve(w.dir, n));
        }
    }

    void filesNew(Win w, boolean dir) {
        NBTTagCompound r = l.root();
        if (r == null) return;
        int cap = l.t.spec(TileComputer.STORAGE).storageKB;
        for (int i = 0; i < 100; i++) {
            String nm = dir ? (i == 0 ? "NewFolder" : "NewFolder" + i) : (i == 0 ? "newfile.txt" : "newfile" + i + ".txt");
            String p = VFS.resolve(w.dir, nm);
            if (VFS.isFile(r, p) || VFS.isDir(r, p)) continue;
            boolean ok = dir ? VFS.mkdir(r, p) : VFS.write(r, p, "", cap);
            w.msg = ok ? "Created " + nm : "No space or bad path";
            filesRefresh(w);
            return;
        }
        w.msg = "Too many files";
    }

    void filesDelete(Win w) {
        NBTTagCompound r = l.root();
        if (r == null || w.sel < 0 || w.sel >= w.names.size()) return;
        String n = w.names.get(w.sel);
        if (n.endsWith("/")) n = n.substring(0, n.length() - 1);
        String p = VFS.resolve(w.dir, n);
        if (p.equals("/") || p.equals("/home") || p.equals("/etc") || p.equals("/bin") || p.equals("/home/" + l.user)) {
            w.msg = "Cannot delete this";
            return;
        }
        int res = VFS.remove(r, p);
        w.msg = res == 0 ? "Deleted " + n : res == 2 ? "Folder is not empty" : "Not found";
        filesRefresh(w);
    }

    void drawFiles(Win w) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2, ih = w.h - 2;
        int rows = ih - 3;
        txt(ix + 1, iy, cut("C:" + w.dir, iw - 2), WHITE);
        txt(ix + 1, iy + 1, " Up ", GRAY);
        txt(ix + 6, iy + 1, " +File ", GRAY);
        txt(ix + 14, iy + 1, " +Dir ", GRAY);
        txt(ix + 21, iy + 1, " Del ", RED);
        for (int r = 0; r < rows; r++) {
            int idx = w.scroll + r;
            if (idx >= w.names.size()) break;
            txt(ix + 1, iy + 2 + r, padR(w.names.get(idx), iw - 4), idx == w.sel ? CYAN : WHITE);
        }
        txt(ix + iw - 2, iy + 2, "^", GRAY);
        txt(ix + iw - 2, iy + 1 + rows, "v", GRAY);
        NBTTagCompound r = l.root();
        String st = w.msg.length() > 0 ? w.msg
                : w.names.size() + " items, free " + (r == null ? 0 : Math.max(0, VFS.free(r, l.t.spec(TileComputer.STORAGE).storageKB)) / 1024) + " KB";
        fill(ix, iy + ih - 1, iw, 1, GRAY);
        txt(ix + 1, iy + ih - 1, cut(st, iw - 2), GRAY);
    }

    void clickFiles(Win w, int cx, int cy) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2, ih = w.h - 2;
        int rows = ih - 3;
        w.msg = "";
        if (cy == iy + 1) {
            if (cx >= ix + 1 && cx <= ix + 4) filesUp(w);
            else if (cx >= ix + 6 && cx <= ix + 12) filesNew(w, false);
            else if (cx >= ix + 14 && cx <= ix + 19) filesNew(w, true);
            else if (cx >= ix + 21 && cx <= ix + 25) filesDelete(w);
            return;
        }
        if (cx == ix + iw - 2) {
            if (cy == iy + 2) w.scroll = Math.max(0, w.scroll - 3);
            else if (cy == iy + 1 + rows) w.scroll = Math.max(0, Math.min(w.scroll + 3, Math.max(0, w.names.size() - rows)));
            return;
        }
        int r = cy - (iy + 2);
        if (r >= 0 && r < rows && cx >= ix + 1 && cx <= ix + iw - 3) {
            int idx = w.scroll + r;
            if (idx < w.names.size()) {
                if (idx == w.sel) filesOpen(w);
                else w.sel = idx;
            }
        }
    }

    void keyFiles(Win w, int key) {
        int rows = w.h - 5;
        if (key == ComputerLogic.K_UP) {
            if (w.sel > 0) w.sel--;
            else if (w.sel < 0 && !w.names.isEmpty()) w.sel = 0;
        } else if (key == ComputerLogic.K_DOWN) {
            if (w.sel < w.names.size() - 1) w.sel++;
        } else if (key == ComputerLogic.K_ENTER || key == ComputerLogic.K_NENTER) {
            filesOpen(w);
            return;
        } else if (key == ComputerLogic.K_BACK) {
            filesUp(w);
            return;
        } else if (key == ComputerLogic.K_DEL) {
            filesDelete(w);
            return;
        }
        if (w.sel >= 0) {
            if (w.sel < w.scroll) w.scroll = w.sel;
            if (w.sel >= w.scroll + rows) w.scroll = w.sel - rows + 1;
        }
    }

    // ---------- Notepad ----------
    void noteSave(Win w) {
        StringBuilder b = new StringBuilder();
        for (StringBuilder ln : w.lines) b.append(ln.toString()).append('\n');
        NBTTagCompound r = l.root();
        int cap = l.t.spec(TileComputer.STORAGE).storageKB;
        if (r != null && VFS.write(r, w.path, b.toString(), cap)) {
            w.mod = false;
            w.msg = "Saved.";
        } else {
            w.msg = "Cannot save!";
        }
    }

    void noteScroll(Win w) {
        int rows = w.h - 4;
        if (w.cr < w.top) w.top = w.cr;
        if (w.cr >= w.top + rows) w.top = w.cr - rows + 1;
        if (w.top < 0) w.top = 0;
    }

    void drawNote(Win w, boolean active) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2, ih = w.h - 2;
        txt(ix + 1, iy, " Save ", GRAY);
        txt(ix + 8, iy, cut(VFS.name(w.path) + (w.mod ? " *" : ""), iw - 9), WHITE);
        int rows = ih - 2;
        for (int r = 0; r < rows; r++) {
            int li = w.top + r;
            if (li >= w.lines.size()) break;
            txt(ix + 1, iy + 1 + r, cut(w.lines.get(li).toString(), iw - 2), WHITE);
        }
        fill(ix, iy + ih - 1, iw, 1, GRAY);
        txt(ix + 1, iy + ih - 1, cut("Ln " + (w.cr + 1) + " Col " + (w.cc + 1) + "  " + w.msg, iw - 2), GRAY);
        if (active) {
            s.cx = ix + 1 + Math.min(w.cc, iw - 3);
            s.cy = iy + 1 + (w.cr - w.top);
            caret = true;
        }
    }

    void clickNote(Win w, int cx, int cy) {
        int ix = w.x + 1, iy = w.y + 1, ih = w.h - 2;
        if (cy == iy) {
            if (cx >= ix + 1 && cx <= ix + 6) noteSave(w);
            return;
        }
        int r = cy - (iy + 1);
        if (r >= 0 && r < ih - 2) {
            int li = w.top + r;
            if (li < w.lines.size()) {
                w.cr = li;
                w.cc = Math.max(0, Math.min(cx - (ix + 1), w.lines.get(li).length()));
                w.msg = "";
            }
        }
    }

    void keyNote(Win w, char c, int key) {
        StringBuilder ln = w.lines.get(w.cr);
        w.msg = "";
        if (key == ComputerLogic.K_LEFT) {
            if (w.cc > 0) {
                w.cc--;
            } else if (w.cr > 0) {
                w.cr--;
                w.cc = w.lines.get(w.cr).length();
            }
        } else if (key == ComputerLogic.K_RIGHT) {
            if (w.cc < ln.length()) {
                w.cc++;
            } else if (w.cr < w.lines.size() - 1) {
                w.cr++;
                w.cc = 0;
            }
        } else if (key == ComputerLogic.K_UP) {
            if (w.cr > 0) {
                w.cr--;
                w.cc = Math.min(w.cc, w.lines.get(w.cr).length());
            }
        } else if (key == ComputerLogic.K_DOWN) {
            if (w.cr < w.lines.size() - 1) {
                w.cr++;
                w.cc = Math.min(w.cc, w.lines.get(w.cr).length());
            }
        } else if (key == 199) {
            w.cc = 0;
        } else if (key == 207) {
            w.cc = ln.length();
        } else if (key == ComputerLogic.K_BACK) {
            if (w.cc > 0) {
                ln.deleteCharAt(w.cc - 1);
                w.cc--;
                w.mod = true;
            } else if (w.cr > 0) {
                StringBuilder prev = w.lines.get(w.cr - 1);
                if (prev.length() + ln.length() <= NOTE_MAX) {
                    w.cc = prev.length();
                    prev.append(ln.toString());
                    w.lines.remove(w.cr);
                    w.cr--;
                    w.mod = true;
                }
            }
        } else if (key == ComputerLogic.K_DEL) {
            if (w.cc < ln.length()) {
                ln.deleteCharAt(w.cc);
                w.mod = true;
            }
        } else if (key == ComputerLogic.K_ENTER || key == ComputerLogic.K_NENTER) {
            if (w.lines.size() < NOTE_LINES) {
                StringBuilder rest = new StringBuilder(ln.substring(w.cc));
                ln.setLength(w.cc);
                w.lines.add(w.cr + 1, rest);
                w.cr++;
                w.cc = 0;
                w.mod = true;
            }
        } else if (c >= 32 && c < 127 && ln.length() < NOTE_MAX) {
            ln.insert(w.cc, c);
            w.cc++;
            w.mod = true;
        }
        noteScroll(w);
    }

    // ---------- Calculator ----------
    static boolean isOp(String k) {
        return k.equals("+") || k.equals("-") || k.equals("*") || k.equals("/");
    }

    static String fmt(double v) {
        String x = (v == Math.floor(v) && Math.abs(v) < 1e12) ? String.valueOf((long) v) : String.valueOf(v);
        return x.length() > 14 ? x.substring(0, 14) : x;
    }

    void calcPress(Win w, char k) {
        if (w.err && k != 'C') return;
        if (k >= '0' && k <= '9') {
            if (w.fresh) {
                w.entry = String.valueOf(k);
                w.fresh = false;
            } else if (w.entry.length() < 14) {
                w.entry = w.entry.equals("0") ? String.valueOf(k) : w.entry + k;
            }
        } else if (k == '.') {
            if (w.fresh) {
                w.entry = "0.";
                w.fresh = false;
            } else if (w.entry.indexOf('.') < 0 && w.entry.length() < 14) {
                w.entry = w.entry + ".";
            }
        } else if (k == 'C') {
            w.entry = "0";
            w.acc = 0;
            w.op = 0;
            w.fresh = false;
            w.err = false;
        } else if (k == 'B') {
            if (!w.fresh) w.entry = w.entry.length() > 1 ? w.entry.substring(0, w.entry.length() - 1) : "0";
        } else if (k == '+' || k == '-' || k == '*' || k == '/' || k == '=') {
            double cur;
            try {
                cur = Double.parseDouble(w.entry);
            } catch (NumberFormatException e) {
                cur = 0;
            }
            if (w.op == 0) {
                w.acc = cur;
            } else if (!w.fresh) {
                if (w.op == '+') {
                    w.acc = w.acc + cur;
                } else if (w.op == '-') {
                    w.acc = w.acc - cur;
                } else if (w.op == '*') {
                    w.acc = w.acc * cur;
                } else {
                    if (cur == 0) {
                        w.err = true;
                        w.entry = "Error";
                        w.op = 0;
                        return;
                    }
                    w.acc = w.acc / cur;
                }
            }
            w.entry = fmt(w.acc);
            w.op = k == '=' ? 0 : k;
            w.fresh = true;
        }
    }

    void drawCalc(Win w) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2;
        fill(ix + 1, iy, iw - 2, 1, GREEN);
        txt(ix + 1, iy, padL(w.entry, iw - 2), GREEN);
        for (int r = 0; r < CALC_KEYS.length; r++) {
            for (int c = 0; c < 4; c++) {
                String k = CALC_KEYS[r][c];
                if (k.length() == 0) continue;
                int col = k.equals("=") ? GREEN : k.equals("C") ? RED : isOp(k) ? YELLOW : GRAY;
                txt(ix + 2 + 4 * c, iy + 2 + 2 * r, " " + k + " ", col);
            }
        }
    }

    void clickCalc(Win w, int cx, int cy) {
        int ix = w.x + 1, iy = w.y + 1;
        for (int r = 0; r < CALC_KEYS.length; r++) {
            for (int c = 0; c < 4; c++) {
                if (cy == iy + 2 + 2 * r && cx >= ix + 2 + 4 * c && cx < ix + 5 + 4 * c) {
                    String k = CALC_KEYS[r][c];
                    if (k.length() > 0) calcPress(w, k.equals("<") ? 'B' : k.charAt(0));
                    return;
                }
            }
        }
    }

    void keyCalc(Win w, char c, int key) {
        if (key == ComputerLogic.K_ENTER || key == ComputerLogic.K_NENTER) calcPress(w, '=');
        else if (key == ComputerLogic.K_BACK) calcPress(w, 'B');
        else if (c == 'c' || c == 'C') calcPress(w, 'C');
        else if ((c >= '0' && c <= '9') || c == '.' || c == '+' || c == '-' || c == '*' || c == '/' || c == '=') calcPress(w, c);
    }

    // ---------- Chat (мессенджер) ----------
    static String mask(String x) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < x.length(); i++) b.append('*');
        return b.toString();
    }

    List<String> chatContacts() {
        List<String> o = new ArrayList<String>();
        o.add(ChatStore.GENERAL);
        o.addAll(l.chat.users);
        return o;
    }

    String contactLabel(String c) {
        ChatClient ch = l.chat;
        String base = c.equals(ChatStore.GENERAL) ? "# general" : (ch.onlineNicks.contains(c) ? "+ " : "- ") + c;
        int n = ch.unreadFor(c);
        String un = n > 0 ? "(" + (n > 9 ? "9+" : String.valueOf(n)) + ")" : "";
        return padR(cut(base, LW - un.length()), LW - un.length()) + un;
    }

    void chatPick(Win w, String peer) {
        w.peer = peer;
        w.mtop = 0;
        l.chat.unread.remove(peer);
        l.chat.viewing = peer;
    }

    void chatSelect(Win w, int delta) {
        List<String> cs = chatContacts();
        int n = cs.size();
        int idx = cs.indexOf(w.peer);
        if (idx < 0) idx = 0;
        idx = ((idx + delta) % n + n) % n;
        chatPick(w, cs.get(idx));
        int rows = w.h - 5;
        if (idx < w.cscroll) w.cscroll = idx;
        if (idx >= w.cscroll + rows) w.cscroll = idx - rows + 1;
    }

    void chatAuth(Win w, boolean register) {
        ChatClient ch = l.chat;
        if (w.fNick.length() == 0 || w.fPass.length() == 0) {
            w.cerr = "Enter nick and password";
            return;
        }
        String e = register ? ch.register(w.fNick, w.fPass) : ch.login(w.fNick, w.fPass);
        if (e != null) {
            w.cerr = e;
            return;
        }
        w.fPass = "";
        w.cerr = "";
        w.fIn = "";
        w.peer = ChatStore.GENERAL;
        w.cscroll = 0;
        w.mtop = 0;
    }

    void chatSend(Win w) {
        String text = w.fIn.trim();
        if (text.length() == 0) return;
        String e = l.chat.send(w.peer, text);
        if (e != null) {
            w.cerr = e;
        } else {
            w.fIn = "";
            w.mtop = 0;
        }
    }

    /** Строки ленты диалога с переносами (свои сообщения голубые). */
    void chatLines(Win w, int mw, List<String> txts, List<Integer> cols) {
        ChatClient ch = l.chat;
        List<ChatStore.Msg> th = ch.thread(w.peer);
        for (int i = Math.max(0, th.size() - 40); i < th.size(); i++) {
            ChatStore.Msg m = th.get(i);
            boolean me = m.from.equals(ch.nick);
            String full = ChatClient.hhmm(m.time) + " " + (me ? "me" : m.from) + ": " + m.text;
            int col = me ? CYAN : WHITE;
            int pos = 0;
            boolean first = true;
            while (pos < full.length()) {
                int room = first ? mw : mw - 2;
                int end = Math.min(full.length(), pos + room);
                txts.add((first ? "" : "  ") + full.substring(pos, end));
                cols.add(col);
                pos = end;
                first = false;
            }
        }
    }

    void drawChat(Win w, boolean active) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2;
        ChatClient ch = l.chat;
        NetLink k = l.link();
        if (!k.up()) {
            txt(ix + 1, iy + 1, "No network connection.", WHITE);
            txt(ix + 1, iy + 3, cut(k.status, iw - 2), WHITE);
            txt(ix + 1, iy + 5, "Put a cable or router next to the PC,", WHITE);
            txt(ix + 1, iy + 6, "or connect to Wi-Fi in 'Network'.", WHITE);
            return;
        }
        List<TileServer> sv = ch.servers();
        if (sv.isEmpty()) {
            txt(ix + 1, iy + 1, "No chat servers on this network.", WHITE);
            txt(ix + 1, iy + 3, "Place a Server block next to a cable", WHITE);
            txt(ix + 1, iy + 4, "or router of this network.", WHITE);
            return;
        }
        if (ch.nick == null) drawChatLogin(w, active, sv.size());
        else drawChatView(w, active);
    }

    void drawChatLogin(Win w, boolean active, int servers) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2;
        ChatClient ch = l.chat;
        TileServer srv = ch.server();
        txt(ix + 1, iy, cut("Server: " + (srv == null ? "-" : srv.domain), iw - 12), WHITE);
        if (servers > 1) txt(ix + iw - 8, iy, " Next ", GRAY);
        txt(ix + 1, iy + 2, "Nick:", WHITE);
        txt(ix + 11, iy + 2, padR(w.fNick, 18), w.focus == 0 ? CYAN : GRAY);
        txt(ix + 1, iy + 4, "Password:", WHITE);
        txt(ix + 11, iy + 4, padR(mask(w.fPass), 18), w.focus == 1 ? CYAN : GRAY);
        txt(ix + 2, iy + 6, " Login ", GREEN);
        txt(ix + 11, iy + 6, " Register ", YELLOW);
        String err = w.cerr.length() > 0 ? w.cerr : ch.err;
        if (err.length() > 0) txt(ix + 1, iy + 8, padR(err, iw - 2), RED);
        txt(ix + 1, iy + 10, "Nick: a-z, 0-9, _ (max 16 chars).", WHITE);
        txt(ix + 1, iy + 11, "Tab: next field. Enter: log in.", WHITE);
        txt(ix + 1, iy + 12, "No account yet? Fill it in, Register.", WHITE);
        if (active) {
            String f = w.focus == 0 ? w.fNick : w.fPass;
            s.cx = ix + 11 + Math.min(17, f.length());
            s.cy = iy + (w.focus == 0 ? 2 : 4);
            caret = true;
        }
    }

    void drawChatView(Win w, boolean active) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2, ih = w.h - 2;
        ChatClient ch = l.chat;
        TileServer srv = ch.server();
        List<String> cs = chatContacts();
        if (!cs.contains(w.peer)) w.peer = ChatStore.GENERAL;
        if (active) ch.unread.remove(w.peer);
        int rows = ih - 3;

        // шапка
        fill(ix, iy, iw, 1, GRAY);
        txt(ix + 1, iy, cut(ch.nick + "@" + (srv == null ? "-" : srv.domain), iw - 12), GRAY);
        txt(ix + iw - 9, iy, " Logout ", RED);

        // контакты
        fill(ix, iy + 1, LW, rows, GRAY);
        int maxScroll = Math.max(0, cs.size() - rows);
        if (w.cscroll > maxScroll) w.cscroll = maxScroll;
        for (int r = 0; r < rows; r++) {
            int idx = w.cscroll + r;
            if (idx >= cs.size()) break;
            String c = cs.get(idx);
            txt(ix, iy + 1 + r, contactLabel(c), c.equals(w.peer) ? CYAN : GRAY);
        }

        // лента сообщений
        int mx = ix + LW + 1, mw = iw - LW - 1;
        List<String> tx = new ArrayList<String>();
        List<Integer> cl = new ArrayList<Integer>();
        chatLines(w, mw, tx, cl);
        if (tx.isEmpty()) txt(mx, iy + 1, "(no messages yet)", WHITE);
        int maxTop = Math.max(0, tx.size() - rows);
        if (w.mtop > maxTop) w.mtop = maxTop;
        if (w.mtop < 0) w.mtop = 0;
        int end = tx.size() - w.mtop, start = Math.max(0, end - rows);
        int y0 = iy + 1 + rows - (end - start);
        for (int i = start; i < end; i++) txt(mx, y0 + (i - start), padR(tx.get(i), mw), cl.get(i));

        // строка состояния
        int sy = iy + ih - 2;
        String st;
        int sc = GRAY;
        if (w.cerr.length() > 0) {
            st = w.cerr;
            sc = RED;
        } else if (!ch.online) {
            st = "offline: no connection to the server";
            sc = YELLOW;
        } else {
            st = (w.mtop > 0 ? "[older] " : "") + "To: " + w.peer + "   (PgUp/PgDn scroll)";
        }
        txt(ix, sy, padR(" " + st, iw), sc);

        // поле ввода
        int iy2 = iy + ih - 1;
        int vis = iw - 10;
        String tail = w.fIn.length() > vis ? w.fIn.substring(w.fIn.length() - vis) : w.fIn;
        txt(ix, iy2, padR("> " + tail, iw - 7), CYAN);
        txt(ix + iw - 7, iy2, " Send ", GREEN);
        if (active) {
            s.cx = ix + 2 + tail.length();
            s.cy = iy2;
            caret = true;
        }
    }

    void clickChat(Win w, int cx, int cy) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2, ih = w.h - 2;
        ChatClient ch = l.chat;
        w.cerr = "";
        if (!l.link().up()) return;
        List<TileServer> sv = ch.servers();
        if (sv.isEmpty()) return;
        if (ch.nick == null) {
            if (cy == iy && sv.size() > 1 && cx >= ix + iw - 8 && cx <= ix + iw - 3) ch.nextServer();
            else if (cy == iy + 2 && cx >= ix + 11) w.focus = 0;
            else if (cy == iy + 4 && cx >= ix + 11) w.focus = 1;
            else if (cy == iy + 6 && cx >= ix + 2 && cx <= ix + 8) chatAuth(w, false);
            else if (cy == iy + 6 && cx >= ix + 11 && cx <= ix + 20) chatAuth(w, true);
            return;
        }
        if (cy == iy && cx >= ix + iw - 9 && cx <= ix + iw - 2) {
            ch.logout();
            w.fPass = "";
            w.fIn = "";
            return;
        }
        int rows = ih - 3;
        if (cy >= iy + 1 && cy < iy + 1 + rows && cx >= ix && cx < ix + LW) {
            List<String> cs = chatContacts();
            int idx = w.cscroll + (cy - iy - 1);
            if (idx < cs.size()) chatPick(w, cs.get(idx));
            return;
        }
        if (cy == iy + ih - 1 && cx >= ix + iw - 7 && cx <= ix + iw - 2) chatSend(w);
    }

    void keyChat(Win w, char c, int key) {
        ChatClient ch = l.chat;
        boolean enter = key == ComputerLogic.K_ENTER || key == ComputerLogic.K_NENTER;
        w.cerr = "";
        if (!l.link().up() || ch.servers().isEmpty()) return;
        if (ch.nick == null) {
            if (key == 15) {
                w.focus = 1 - w.focus;
            } else if (key == ComputerLogic.K_UP || key == ComputerLogic.K_DOWN) {
                ch.nextServer();
            } else if (enter) {
                chatAuth(w, false);
            } else if (key == ComputerLogic.K_BACK) {
                if (w.focus == 0 && w.fNick.length() > 0) w.fNick = w.fNick.substring(0, w.fNick.length() - 1);
                else if (w.focus == 1 && w.fPass.length() > 0) w.fPass = w.fPass.substring(0, w.fPass.length() - 1);
            } else if (c >= 33 && c < 127) {
                if (w.focus == 0) {
                    if (w.fNick.length() < 16) w.fNick = w.fNick + Character.toLowerCase(c);
                } else if (w.fPass.length() < 20) {
                    w.fPass = w.fPass + c;
                }
            }
            return;
        }
        if (enter) {
            chatSend(w);
        } else if (key == ComputerLogic.K_UP) {
            chatSelect(w, -1);
        } else if (key == ComputerLogic.K_DOWN || key == 15) {
            chatSelect(w, 1);
        } else if (key == 201) {
            w.mtop += 5;
        } else if (key == 209) {
            w.mtop = Math.max(0, w.mtop - 5);
        } else if (key == ComputerLogic.K_BACK) {
            if (w.fIn.length() > 0) w.fIn = w.fIn.substring(0, w.fIn.length() - 1);
        } else if (c >= 32 && c < 127 && w.fIn.length() < ChatStore.MAX_TEXT) {
            w.fIn = w.fIn + c;
        }
    }

    // ---------- Network (кабель и Wi-Fi) ----------
    void netConnect(Win w) {
        List<Net.Ap> aps = Net.scan(l.t);
        if (w.sel < 0 || w.sel >= aps.size()) {
            w.msg = "Select a network first";
            return;
        }
        Net.Ap a = aps.get(w.sel);
        int res = Net.check(l.t, a.ssid, w.fPass);
        NBTTagCompound r = l.root();
        if (res == Net.OK && r != null) {
            r.setString("wifi_ssid", a.ssid);
            r.setString("wifi_pass", w.fPass);
            l.relink();
            w.fPass = "";
            w.msg = "Connected to " + a.ssid;
        } else if (res == Net.BAD_PASS) {
            w.msg = "Wrong password";
        } else if (res == Net.NO_MODULE) {
            w.msg = "No Wi-Fi module installed";
        } else {
            w.msg = "Network is out of range";
        }
    }

    void netDisconnect(Win w) {
        NBTTagCompound r = l.root();
        if (r == null) return;
        r.removeTag("wifi_ssid");
        r.removeTag("wifi_pass");
        l.relink();
        w.msg = "Wi-Fi disconnected";
    }

    void drawNet(Win w, boolean active) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2, ih = w.h - 2;
        NetLink k = l.link();
        txt(ix + 1, iy, cut("Link   : " + k.describe(), iw - 2), WHITE);
        String gw = (!k.up() || k.router == null) ? "-" : k.router.ssid;
        txt(ix + 1, iy + 1, cut("Gateway: " + gw + (k.type == NetLink.WIFI ? "  " + NetLink.bars(k.signal) : ""), iw - 2), WHITE);
        StringBuilder sb = new StringBuilder();
        for (TileServer sv : k.servers) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(sv.domain);
        }
        txt(ix + 1, iy + 2, cut("Servers: " + (k.servers.isEmpty() ? "none" : sb.toString()), iw - 2), WHITE);

        boolean mod = l.t.spec(TileComputer.NET) != null;
        fill(ix, iy + 3, iw, 1, GRAY);
        txt(ix + 1, iy + 3, mod ? "Wi-Fi networks" : "No Wi-Fi module installed", GRAY);
        fill(ix, iy + ih - 1, iw, 1, GRAY);
        txt(ix + 1, iy + ih - 1, cut(w.msg, iw - 2), GRAY);
        if (!mod) {
            txt(ix + 1, iy + 5, "Install a Wi-Fi Module in the PC", WHITE);
            txt(ix + 1, iy + 6, "hardware panel, or use a cable.", WHITE);
            return;
        }
        List<Net.Ap> aps = Net.scan(l.t);
        int rows = 5;
        if (w.sel >= aps.size()) w.sel = aps.size() - 1;
        if (w.sel >= 0) {
            if (w.sel < w.scroll) w.scroll = w.sel;
            if (w.sel >= w.scroll + rows) w.scroll = w.sel - rows + 1;
        }
        if (w.scroll > Math.max(0, aps.size() - rows)) w.scroll = Math.max(0, aps.size() - rows);
        if (aps.isEmpty()) txt(ix + 1, iy + 4, "No networks in range.", WHITE);
        for (int r = 0; r < rows; r++) {
            int idx = w.scroll + r;
            if (idx >= aps.size()) break;
            Net.Ap a = aps.get(idx);
            boolean cur = k.type == NetLink.WIFI && a.ssid.equals(k.ssid);
            String row = (cur ? "* " : "  ") + padR(a.ssid, 16) + " " + NetLink.bars(a.signal) + (a.secured ? "  key" : "  open");
            txt(ix + 1, iy + 4 + r, padR(row, iw - 2), idx == w.sel ? CYAN : WHITE);
        }
        txt(ix + 1, iy + 9, "Password:", WHITE);
        txt(ix + 11, iy + 9, padR(mask(w.fPass), 18), CYAN);
        txt(ix + 2, iy + 10, " Connect ", GREEN);
        txt(ix + 13, iy + 10, " Disconnect ", YELLOW);
        if (active) {
            s.cx = ix + 11 + Math.min(17, w.fPass.length());
            s.cy = iy + 9;
            caret = true;
        }
    }

    void clickNet(Win w, int cx, int cy) {
        int ix = w.x + 1, iy = w.y + 1;
        w.msg = "";
        if (l.t.spec(TileComputer.NET) == null) return;
        int r = cy - (iy + 4);
        if (r >= 0 && r < 5) {
            int idx = w.scroll + r;
            if (idx < Net.scan(l.t).size()) w.sel = idx;
            return;
        }
        if (cy == iy + 10) {
            if (cx >= ix + 2 && cx <= ix + 10) netConnect(w);
            else if (cx >= ix + 13 && cx <= ix + 24) netDisconnect(w);
        }
    }

    void keyNet(Win w, char c, int key) {
        w.msg = "";
        if (l.t.spec(TileComputer.NET) == null) return;
        int n = Net.scan(l.t).size();
        if (key == ComputerLogic.K_UP) {
            if (w.sel > 0) w.sel--;
            else if (w.sel < 0 && n > 0) w.sel = 0;
        } else if (key == ComputerLogic.K_DOWN) {
            if (w.sel < n - 1) w.sel++;
        } else if (key == ComputerLogic.K_ENTER || key == ComputerLogic.K_NENTER) {
            netConnect(w);
        } else if (key == ComputerLogic.K_BACK) {
            if (w.fPass.length() > 0) w.fPass = w.fPass.substring(0, w.fPass.length() - 1);
        } else if (c >= 33 && c < 127 && w.fPass.length() < 16) {
            w.fPass = w.fPass + c;
        }
    }

    // ===================== ввод =====================
    public void key(char c, int key) {
        Win f = top();
        if (f != null) {
            if (f.type == FILES) keyFiles(f, key);
            else if (f.type == NOTE) keyNote(f, c, key);
            else if (f.type == CALC) keyCalc(f, c, key);
            else if (f.type == CHAT) keyChat(f, c, key);
            else if (f.type == NETW) keyNet(f, c, key);
            else if (f.type == PAINT) keyPaint(f, c, key);
            else if (f.type == SHOP) keyShop(f, c, key);
            else if (f.type == BANK) keyBank(f, c, key);
        }
        draw();
    }

    public void click(int cx, int cy) {
        if (cy == TB) {
            if (cx < 7) {
                menu = !menu;
            } else {
                menu = false;
                int i = (cx - 8) / 7;
                if (cx >= 8 && i < wins.size()) {
                    Win w = wins.get(i);
                    if (w == top()) w.min = true;
                    else raise(w);
                }
            }
            draw();
            return;
        }
        if (menu && pixel) {
            int y0 = TB - 2 * PMENU_ROWS;
            menu = false;
            if (cx < 2 * PMW && cy >= y0 && cy < TB) {
                int idx = (cx / PMW) * PMENU_ROWS + (cy - y0) / 2;
                if (idx < PMENU.length) menuAction(PMENU_ACT[idx]);
            }
            if (l.st == ComputerLogic.St.DESKTOP && l.desk == this) draw();
            return;
        }
        if (menu) {
            int y0 = TB - MENU.length;
            menu = false;
            if (cx < 16 && cy >= y0 && cy < TB) menuAction(MENU_ACT[cy - y0]);
            if (l.st == ComputerLogic.St.DESKTOP && l.desk == this) draw();
            return;
        }
        for (int i = wins.size() - 1; i >= 0; i--) {
            Win w = wins.get(i);
            if (w.min) continue;
            if (cx >= w.x && cx < w.x + w.w && cy >= w.y && cy < w.y + w.h) {
                raise(w);
                if (cy == w.y) {
                    if (cx >= w.x + w.w - 4 && cx <= w.x + w.w - 2) close(w);
                    else if (cx >= w.x + w.w - 7 && cx <= w.x + w.w - 5) w.min = true;
                } else if (w.type == FILES) {
                    clickFiles(w, cx, cy);
                } else if (w.type == NOTE) {
                    clickNote(w, cx, cy);
                } else if (w.type == CALC) {
                    clickCalc(w, cx, cy);
                } else if (w.type == CHAT) {
                    clickChat(w, cx, cy);
                } else if (w.type == NETW) {
                    clickNet(w, cx, cy);
                } else if (w.type == PAINT) {
                    clickPaint(w, cx, cy);
                } else if (w.type == SHOP) {
                    clickShop(w, cx, cy);
                } else if (w.type == BANK) {
                    clickBank(w, cx, cy);
                }
                draw();
                return;
            }
        }
        if (pixel) {
            for (int i = 0; i < PICON_ACT.length; i++) {
                int ix = 1 + 7 * (i / 4), iy = 1 + 3 * (i % 4);
                if (cx >= ix && cx <= ix + 6 && cy >= iy && cy <= iy + 2) {
                    menuAction(PICON_ACT[i]);
                    if (l.st == ComputerLogic.St.DESKTOP && l.desk == this) draw();
                    return;
                }
            }
            draw();
            return;
        }
        for (int i = 0; i < ICON_NAME.length; i++) {
            int ix = 2 + 9 * (i / 5), y = 1 + 3 * (i % 5);
            if (cx >= ix && cx <= ix + 7 && cy >= y && cy <= y + 1) {
                menuAction(ICON_ACT[i]);
                if (l.st == ComputerLogic.St.DESKTOP && l.desk == this) draw();
                return;
            }
        }
        draw();
    }

    // ===================== Shop и Bank (интернет-сервисы) =====================
    static final int SHOP_ROWS = 10;
    /** Сколько консов наличными было у игрока при последней отрисовке (-1 = неизвестно). */
    long cashSeen = -1;

    static String mmss(int sec) {
        int m = sec / 60, s2 = sec % 60;
        return m + ":" + (s2 < 10 ? "0" : "") + s2;
    }

    /** Нужны сеть и хотя бы один сервер: Shop и Bank работают через сервер сети. */
    boolean netOk() {
        return l.link().up() && l.chat.server() != null;
    }

    /** Рисует подсказку и возвращает false, если сервисы недоступны. */
    boolean servicesReady(int ix, int iy, int iw) {
        NetLink k = l.link();
        if (!k.up()) {
            txt(ix + 1, iy + 1, "No network connection.", WHITE);
            txt(ix + 1, iy + 3, cut(k.status, iw - 2), WHITE);
            txt(ix + 1, iy + 5, "Connect a cable or Wi-Fi first.", WHITE);
            return false;
        }
        if (l.chat.server() == null) {
            txt(ix + 1, iy + 1, "No server on this network.", WHITE);
            txt(ix + 1, iy + 3, "Place a Server block next to a cable", WHITE);
            txt(ix + 1, iy + 4, "or router of this network.", WHITE);
            return false;
        }
        return true;
    }

    /** Подпись для перерисовки: окно магазина/банка обновляется по секундам и при смене баланса. */
    String shopSig() {
        boolean on = false;
        for (Win w : wins) {
            if ((w.type == SHOP || w.type == BANK) && !w.min) on = true;
        }
        if (!on) return "";
        Bank b = Bank.get();
        String bal = b == null ? "-" : b.balance(l.actorId) + "/" + b.history(l.actorId).size();
        return Shop.stamp() + ":" + Shop.secondsLeft() + ":" + bal + ":" + l.actorId.length();
    }

    String account() {
        return l.actorName.length() == 0 ? "(press any key)" : l.actorName;
    }

    // ---------- Shop ----------
    void drawShop(Win w, boolean active) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2;
        if (!servicesReady(ix, iy, iw)) return;
        Bank b = Bank.get();
        if (b == null) {
            txt(ix + 1, iy + 1, "Bank is unavailable.", WHITE);
            return;
        }
        List<Shop.Offer> cat = Shop.catalog();
        long stamp = Shop.stamp();
        if (w.epoch != stamp) {
            if (w.epoch >= 0) {
                w.msg = "The catalog has changed!";
                w.msgOk = true;
            }
            w.epoch = stamp;
            w.sel = -1;
        }
        if (w.sel >= cat.size()) w.sel = cat.size() - 1;
        String id = l.actorId;
        TileServer srv = l.chat.server();
        fill(ix, iy, iw, 1, GRAY);
        txt(ix + 1, iy, cut("Shop @ " + (srv == null ? "-" : srv.domain), 30), GRAY);
        String nx = "New catalog in " + mmss(Shop.secondsLeft());
        txt(ix + iw - nx.length() - 1, iy, nx, GRAY);
        txt(ix + 1, iy + 1, cut("Balance: " + Bank.fmt(b.balance(id)) + "    " + account(), iw - 2), WHITE);
        fill(ix, iy + 2, iw, 1, GRAY);
        txt(ix + 1, iy + 2, padR("  Item", 26) + padL("Price", 7) + padL("You", 8) + padL("Stock", 8), GRAY);
        if (cat.isEmpty()) txt(ix + 1, iy + 4, "The catalog is empty (see config/pcmod_shop.cfg).", WHITE);
        for (int r = 0; r < SHOP_ROWS && r < cat.size(); r++) {
            Shop.Offer o = cat.get(r);
            int pl = Shop.playerLeft(b, id, o), st = Shop.stockLeft(b, o);
            boolean out = pl <= 0 || st <= 0;
            String you = pl == Integer.MAX_VALUE ? "-" : pl + "/" + o.limit;
            String stock = st == Integer.MAX_VALUE ? "inf" : String.valueOf(st);
            String row = padR((r == w.sel ? "> " : "  ") + o.name, 26) + padL(o.price + " K", 7) + padL(you, 8) + padL(stock, 8);
            txt(ix + 1, iy + 3 + r, padR(row, iw - 2), r == w.sel ? CYAN : (out ? GRAY : WHITE));
        }
        String det = "Select an item: Up/Down or click.";
        if (w.sel >= 0 && w.sel < cat.size()) {
            Shop.Offer o = cat.get(w.sel);
            det = o.price + " K each. Limit " + (o.limit == 0 ? "none" : o.limit + " per player")
                    + ", stock " + (o.stock == 0 ? "unlimited" : String.valueOf(o.stock));
        }
        txt(ix + 1, iy + 13, padR(det, iw - 2), WHITE);
        if (w.msg.length() > 0) txt(ix + 1, iy + 14, padR(w.msg, iw - 2), w.msgOk ? GREEN : RED);
        txt(ix + 1, iy + 15, " Buy 1 ", GREEN);
        txt(ix + 9, iy + 15, " Buy 5 ", GREEN);
        txt(ix + 17, iy + 15, " Buy max ", YELLOW);
        txt(ix + 28, iy + 15, "Enter=1  5  M=max", WHITE);
        fill(ix, iy + 16, iw, 1, GRAY);
        txt(ix + 1, iy + 16, cut("Pay with kons: top up in the Bank app.", iw - 2), GRAY);
    }

    void shopBuy(Win w, int qty) {
        w.msgOk = false;
        if (l.actor == null) return;
        if (!netOk()) {
            w.msg = "No connection to the server";
            return;
        }
        if (w.sel < 0) {
            w.msg = "Select an item first";
            return;
        }
        Bank.Res r = Shop.buy(l.actor, w.sel, qty, w.epoch);
        w.msg = r.msg;
        w.msgOk = r.ok;
    }

    void clickShop(Win w, int cx, int cy) {
        int ix = w.x + 1, iy = w.y + 1;
        w.msg = "";
        if (!netOk()) return;
        int r = cy - (iy + 3);
        if (r >= 0 && r < SHOP_ROWS) {
            if (r < Shop.catalog().size()) w.sel = r;
            return;
        }
        if (cy == iy + 15) {
            if (cx >= ix + 1 && cx <= ix + 7) shopBuy(w, 1);
            else if (cx >= ix + 9 && cx <= ix + 15) shopBuy(w, 5);
            else if (cx >= ix + 17 && cx <= ix + 25) shopBuy(w, 0);
        }
    }

    void keyShop(Win w, char c, int key) {
        w.msg = "";
        if (!netOk()) return;
        int n = Shop.catalog().size();
        if (key == ComputerLogic.K_UP) {
            if (w.sel > 0) w.sel--;
            else if (w.sel < 0 && n > 0) w.sel = 0;
        } else if (key == ComputerLogic.K_DOWN) {
            if (w.sel < n - 1) w.sel++;
        } else if (key == ComputerLogic.K_ENTER || key == ComputerLogic.K_NENTER || c == '1') {
            shopBuy(w, 1);
        } else if (c == '5') {
            shopBuy(w, 5);
        } else if (c == 'm' || c == 'M') {
            shopBuy(w, 0);
        }
    }

    // ---------- Bank ----------
    void drawBank(Win w, boolean active) {
        int ix = w.x + 1, iy = w.y + 1, iw = w.w - 2;
        if (!servicesReady(ix, iy, iw)) return;
        Bank b = Bank.get();
        if (b == null) {
            txt(ix + 1, iy + 1, "Bank is unavailable.", WHITE);
            return;
        }
        if (l.actor != null) cashSeen = Bank.cash(l.actor);
        String id = l.actorId;
        TileServer srv = l.chat.server();
        fill(ix, iy, iw, 1, GRAY);
        txt(ix + 1, iy, cut("Bank @ " + (srv == null ? "-" : srv.domain), iw - 2), GRAY);
        txt(ix + 1, iy + 2, cut("Account : " + account(), iw - 2), WHITE);
        txt(ix + 1, iy + 3, cut("Balance : " + Bank.fmt(b.balance(id)), iw - 2), WHITE);
        txt(ix + 1, iy + 4, cut("Cash    : " + (cashSeen < 0 ? "?" : Bank.fmt(cashSeen)) + " in inventory", iw - 2), WHITE);
        txt(ix + 1, iy + 6, "Amount  :", WHITE);
        String am = w.fIn.length() == 0 ? "" : w.fIn;
        txt(ix + 11, iy + 6, padR(am, 12), CYAN);
        txt(ix + 1, iy + 7, cut("Keys: D deposit, W withdraw, A all", iw - 2), WHITE);
        txt(ix + 2, iy + 8, " Deposit ", GREEN);
        txt(ix + 13, iy + 8, " Withdraw ", YELLOW);
        txt(ix + 25, iy + 8, " Deposit all ", GREEN);
        if (w.msg.length() > 0) txt(ix + 1, iy + 10, padR(w.msg, iw - 2), w.msgOk ? GREEN : RED);
        fill(ix, iy + 11, iw, 1, GRAY);
        txt(ix + 1, iy + 11, "History", GRAY);
        List<String> h = b.history(id);
        for (int r = 0; r < 3; r++) {
            int idx = h.size() - 1 - r;
            if (idx < 0) break;
            txt(ix + 1, iy + 12 + r, cut(h.get(idx), iw - 2), WHITE);
        }
        if (active) {
            s.cx = ix + 11 + Math.min(11, am.length());
            s.cy = iy + 6;
            caret = true;
        }
    }

    /** op: 0 внести сумму, 1 снять, 2 внести всё. */
    void bankDo(Win w, int op) {
        w.msgOk = false;
        if (l.actor == null) return;
        if (!netOk()) {
            w.msg = "No connection to the server";
            return;
        }
        Bank b = Bank.get();
        if (b == null) {
            w.msg = "Bank is unavailable";
            return;
        }
        long amt = 0;
        try {
            if (w.fIn.length() > 0) amt = Long.parseLong(w.fIn);
        } catch (NumberFormatException e) {
            amt = 0;
        }
        Bank.Res r = op == 1 ? b.withdraw(l.actor, amt) : b.deposit(l.actor, op == 2 ? -1L : amt);
        w.msg = r.msg;
        w.msgOk = r.ok;
        if (r.ok) w.fIn = "";
    }

    void clickBank(Win w, int cx, int cy) {
        int ix = w.x + 1, iy = w.y + 1;
        w.msg = "";
        if (cy == iy + 8) {
            if (cx >= ix + 2 && cx <= ix + 10) bankDo(w, 0);
            else if (cx >= ix + 13 && cx <= ix + 22) bankDo(w, 1);
            else if (cx >= ix + 25 && cx <= ix + 37) bankDo(w, 2);
        }
    }

    void keyBank(Win w, char c, int key) {
        w.msg = "";
        if (key == ComputerLogic.K_ENTER || key == ComputerLogic.K_NENTER) {
            bankDo(w, w.fIn.length() == 0 ? 2 : 0);
        } else if (key == ComputerLogic.K_BACK) {
            if (w.fIn.length() > 0) w.fIn = w.fIn.substring(0, w.fIn.length() - 1);
        } else if (c >= '0' && c <= '9') {
            if (w.fIn.length() < 9) w.fIn = w.fIn + c;
        } else if (c == 'd' || c == 'D') {
            bankDo(w, 0);
        } else if (c == 'w' || c == 'W') {
            bankDo(w, 1);
        } else if (c == 'a' || c == 'A') {
            bankDo(w, 2);
        }
    }

    // ===================== PixelOS: фон, иконки, меню =====================
    /** Тёмный рабочий стол с пиксельной сеткой и подписанными значками. */
    void drawPixelBg() {
        for (int y = 0; y < TB; y++) {
            for (int x = 0; x < W; x++) {
                if (x % 6 == 3 && y % 3 == 1) s.put(x, y, '.', PBG);
            }
        }
        for (int i = 0; i < PNAME.length; i++) {
            int ix = 1 + 7 * (i / 4), iy = 1 + 3 * (i % 4);
            String nm = PNAME[i];
            s.text(ix + (7 - nm.length()) / 2, iy + 2, nm, WHITE);
        }
    }

    /** Закрыт ли прямоугольник (в клетках) окном или меню: иконка поверх них смотрелась бы неправильно. */
    boolean covered(int x, int y, int w, int h) {
        for (Win k : wins) {
            if (k.min) continue;
            if (x < k.x + k.w && x + w > k.x && y < k.y + k.h && y + h > k.y) return true;
        }
        return menu && x < 2 * PMW && y + h > TB - 2 * PMENU_ROWS;
    }

    void drawPixelMenu() {
        int rows = PMENU_ROWS, y0 = TB - 2 * rows;
        fill(0, y0, 2 * PMW, 2 * rows, WHITE);
        fill(0, y0, 1, 2 * rows, PTITLE);
        fill(PMW, y0, 1, 2 * rows, GRAY);
        for (int i = 0; i < PMENU.length; i++) {
            txt((i / rows) * PMW + 5, y0 + 2 * (i % rows), padR(PMENU[i], 11), WHITE);
        }
    }

    /** Пиксельные иконки кладутся поверх текста, поэтому ставим их в самом конце отрисовки. */
    void drawPixelSprites() {
        for (int i = 0; i < PICON_ACT.length; i++) {
            int ix = 1 + 7 * (i / 4) + 2, iy = 1 + 3 * (i % 4);
            if (!covered(ix, iy, 3, 2)) s.sprite(ix, iy, PICON_SPR[i]);
        }
        s.sprite(0, TB, Sprites.mini(Sprites.LOGO));
        for (int i = 0; i < wins.size() && i < MAXWIN; i++) {
            s.sprite(8 + 7 * i, TB, Sprites.mini(TYPE_SPR[wins.get(i).type]));
        }
        if (menu) {
            int y0 = TB - 2 * PMENU_ROWS;
            for (int i = 0; i < PMENU.length; i++) {
                s.sprite((i / PMENU_ROWS) * PMW + 1, y0 + 2 * (i % PMENU_ROWS), PMENU_SPR[i]);
            }
        }
    }

    // ===================== Paint (PixelOS) =====================
    String paintPath() {
        return "/home/" + l.user + "/art.px";
    }

    void paintLoad(Win w) {
        Arrays.fill(w.art, 0);
        NBTTagCompound r = l.root();
        String txt = r == null ? null : VFS.read(r, paintPath());
        if (txt == null) {
            w.amsg = "New picture";
            return;
        }
        String[] rows = txt.split("\n");
        for (int y = 0; y < PH && y < rows.length; y++) {
            for (int x = 0; x < PW && x < rows[y].length(); x++) {
                int v = Character.digit(rows[y].charAt(x), 16);
                if (v >= 0) w.art[y * PW + x] = v;
            }
        }
        w.amsg = "Loaded";
    }

    void paintSave(Win w) {
        NBTTagCompound r = l.root();
        PartSpec sto = l.t.spec(TileComputer.STORAGE);
        if (r == null || sto == null) {
            w.amsg = "No drive";
            return;
        }
        StringBuilder b = new StringBuilder();
        for (int y = 0; y < PH; y++) {
            for (int x = 0; x < PW; x++) b.append(Character.forDigit(w.art[y * PW + x], 16));
            b.append('\n');
        }
        w.amsg = VFS.write(r, paintPath(), b.toString(), sto.storageKB) ? "Saved" : "No space";
        l.t.markDirty();
    }

    void drawPaint(Win w) {
        int ix = w.x + 2, y0 = w.y + 1;
        for (int y = 0; y < PH; y++) {
            for (int x = 0; x < PW; x++) fill(ix + 2 * x, y0 + y, 2, 1, w.art[y * PW + x]);
        }
        for (int c = 0; c < 16; c++) fill(ix + 2 * c, w.y + 13, 2, 1, c);
        txt(ix, w.y + 14, "Color", WHITE);
        txt(ix + 5, w.y + 14, "[", WHITE);
        fill(ix + 6, w.y + 14, 4, 1, w.pcol);
        txt(ix + 10, w.y + 14, "]", WHITE);
        txt(ix + 12, w.y + 14, cut(w.amsg, 20), WHITE);
        txt(ix, w.y + 15, " Clear ", GRAY);
        txt(ix + 8, w.y + 15, " Save ", GRAY);
        txt(ix + 15, w.y + 15, " Load ", GRAY);
        txt(ix + 24, w.y + 15, "Keys 0-F", WHITE);
    }

    void clickPaint(Win w, int cx, int cy) {
        int ix = w.x + 2, y0 = w.y + 1;
        if (cy >= y0 && cy < y0 + PH && cx >= ix && cx < ix + 2 * PW) {
            w.art[(cy - y0) * PW + (cx - ix) / 2] = w.pcol;
            w.amsg = "";
        } else if (cy == w.y + 13 && cx >= ix && cx < ix + 32) {
            w.pcol = (cx - ix) / 2;
        } else if (cy == w.y + 15) {
            if (cx >= ix && cx < ix + 7) {
                Arrays.fill(w.art, 0);
                w.amsg = "Cleared";
            } else if (cx >= ix + 8 && cx < ix + 14) {
                paintSave(w);
            } else if (cx >= ix + 15 && cx < ix + 21) {
                paintLoad(w);
            }
        }
    }

    /** Клавиши 0-9 и A-F выбирают цвет кисти. */
    void keyPaint(Win w, char c, int key) {
        int v = Character.digit(c, 16);
        if (v >= 0) w.pcol = v;
    }
}
