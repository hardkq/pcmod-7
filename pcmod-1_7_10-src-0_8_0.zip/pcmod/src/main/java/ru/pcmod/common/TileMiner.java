package ru.pcmod.common;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import ru.pcmod.common.PartSpec.Cat;

/**
 * Майнер-ферма. Собирается из деталей ПК: видеокарты (GPU) майнят, блок питания (PSU) даёт мощность,
 * кулеры (COOLER) отводят тепло. Работает только в сети с роутером («интернет»). Намайненные консы копятся
 * в буфере фермы, владелец забирает их кнопкой Collect прямо на счёт в банке (приложение Bank / команда /pcbank).
 */
public class TileMiner extends TileEntity implements IInventory {
    public static final int MAX_SLOTS = 12;
    /** Статусы фермы (для экрана). */
    public static final int OFF = 0, MINING = 1, NO_GPU = 2, POWER = 3, HOT = 4, NO_NET = 5, FULL = 6;
    /** Множитель охлаждения: на ферме стоят мощные вентиляторы. */
    public static final int COOL_MULT = 4;
    /** Консов в час (72000 тиков) на 1 МХ/с при курсе 1.00. */
    public static final double K_PER_MH_HOUR = 0.5;

    private final ItemStack[] inv = new ItemStack[MAX_SLOTS];
    public boolean on;
    public double temp = 25;
    public long stored;
    private double pending;
    private boolean hot;
    public String owner = "", ownerName = "";

    // вычисляемое состояние (считается на сервере)
    public int status, hashNow, baseHash, market = 100, incomeX10, load, psuW, gpuCount, wattsGpu, cooling = 10;
    private boolean online;
    private int timer, netTimer, saveTimer;

    // ---------- устройство фермы ----------
    public int tier() {
        Block b = getBlockType();
        return b instanceof BlockNetDevice ? ((BlockNetDevice) b).tier : 0;
    }

    public int gpuSlots() {
        return tier() == 0 ? 4 : 8;
    }

    public int psuSlots() {
        return tier() == 0 ? 1 : 2;
    }

    public long cap() {
        return tier() == 0 ? 20000L : 60000L;
    }

    static PartSpec specOf(ItemStack s) {
        return s != null && s.getItem() instanceof ItemPart ? ((ItemPart) s.getItem()).spec : null;
    }

    private PartSpec spec(int i) {
        return specOf(inv[i]);
    }

    /** Какая деталь нужна в слот: сначала видеокарты, потом блоки питания, потом кулеры. */
    public Cat kindOf(int i) {
        if (i < gpuSlots()) return Cat.GPU;
        if (i < gpuSlots() + psuSlots()) return Cat.PSU;
        return Cat.COOLER;
    }

    /** Курс майнинга на текущие игровые сутки: 0.60 .. 1.60 (одинаков для всех ферм). */
    public static int market(World w) {
        long day = w == null ? 0L : w.getTotalWorldTime() / 24000L;
        Random r = new Random(day * 0x9E3779B97F4A7C15L + 0x632BE59BD9B4E019L);
        r.nextInt();
        return 60 + r.nextInt(101);
    }

    // ---------- расчёт ----------
    private void evaluate() {
        int g = 0, hs = 0, w = 0, ps = 0, cl = 0;
        int gs = gpuSlots(), ss = psuSlots(), n = getSizeInventory();
        for (int i = 0; i < gs; i++) {
            PartSpec p = spec(i);
            if (p != null) {
                g++;
                hs += p.hash;
                w += p.watts;
            }
        }
        for (int i = gs; i < gs + ss; i++) {
            PartSpec p = spec(i);
            if (p != null) ps += p.watts;
        }
        for (int i = gs + ss; i < n; i++) {
            PartSpec p = spec(i);
            if (p != null) cl += p.cooling;
        }
        gpuCount = g;
        wattsGpu = w;
        baseHash = hs;
        load = g == 0 ? 0 : w + 20 * (tier() + 1);
        psuW = ps;
        cooling = Math.max(10, cl * COOL_MULT);
        market = market(worldObj);
        if (!on) status = hot ? HOT : OFF;
        else if (g == 0) status = NO_GPU;
        else if (ps < load) status = POWER;
        else if (!online) status = NO_NET;
        else if (stored >= cap()) status = FULL;
        else status = MINING;
        hashNow = status == MINING ? (temp >= 90 ? hs / 2 : hs) : 0;
        incomeX10 = (int) Math.round(hashNow * K_PER_MH_HOUR * market / 100.0 * 10.0);
    }

    @Override
    public void updateEntity() {
        if (worldObj == null || worldObj.isRemote) return;
        if (++timer >= 20) {
            timer = 0;
            step();
        }
    }

    /** Раз в секунду: сеть, нагрев, доход. */
    private void step() {
        if (++netTimer >= 5) {
            netTimer = 0;
            online = Net.onlineAt(worldObj, xCoord, yCoord, zCoord);
        }
        evaluate();
        double target = 25;
        if (status == MINING) target = 25 + wattsGpu * 45.0 / cooling;
        else if (on && gpuCount > 0 && status != POWER) target = 25 + wattsGpu * 45.0 / cooling * 0.15;
        temp += (target - temp) * 0.1;
        if (on && temp >= 100) {
            on = false;
            hot = true;
            temp = 100;
        }
        if (status == MINING) {
            pending += hashNow * K_PER_MH_HOUR * market / 100.0 / 3600.0;
            long whole = (long) pending;
            if (whole > 0) {
                pending -= whole;
                stored = Math.min(cap(), stored + whole);
            }
        }
        evaluate();
        if (++saveTimer >= 10) {
            saveTimer = 0;
            markDirty();
        }
    }

    /** Значения для окна (контейнер рассылает их игроку). */
    public int[] syncValues() {
        evaluate();
        return new int[]{status, on ? 1 : 0, hashNow, market, incomeX10, (int) temp, load, psuW,
                (int) Math.min(stored, 2000000000L), (int) cap()};
    }

    // ---------- кнопки окна ----------
    public String togglePower() {
        if (on) {
            on = false;
        } else {
            if (temp > 80) return "Farm is too hot (" + (int) temp + " C), let it cool down first";
            on = true;
            hot = false;
        }
        markDirty();
        evaluate();
        return null;
    }

    public String collect(EntityPlayer p) {
        if (stored <= 0) return "Nothing to collect yet";
        String id = p.getUniqueID().toString();
        if (owner.length() > 0 && !owner.equals(id)) return "Only the owner (" + ownerName + ") can collect the earnings";
        Bank b = Bank.get();
        if (b == null) return "Bank is unavailable";
        if (owner.length() == 0) {
            owner = id;
            ownerName = p.getCommandSenderName();
        }
        long room = Bank.MAX_BALANCE - b.balance(id);
        long amt = Math.min(stored, room);
        if (amt <= 0) return "Account limit reached";
        b.rename(id, p.getCommandSenderName());
        b.setBalance(id, b.balance(id) + amt);
        b.log(id, "+" + Bank.fmt(amt) + " mining");
        stored -= amt;
        markDirty();
        return "Collected " + Bank.fmt(amt) + " to your bank account";
    }

    public ItemStack takeSilently(int i) {
        ItemStack s = inv[i];
        inv[i] = null;
        return s;
    }

    // ---------- IInventory ----------
    @Override
    public int getSizeInventory() {
        return gpuSlots() + psuSlots() * 2;
    }

    @Override
    public ItemStack getStackInSlot(int i) {
        return i >= 0 && i < MAX_SLOTS ? inv[i] : null;
    }

    @Override
    public ItemStack decrStackSize(int i, int n) {
        if (i < 0 || i >= MAX_SLOTS || inv[i] == null) return null;
        ItemStack out;
        if (inv[i].stackSize <= n) {
            out = inv[i];
            inv[i] = null;
        } else {
            out = inv[i].splitStack(n);
            if (inv[i].stackSize == 0) inv[i] = null;
        }
        markDirty();
        return out;
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int i) {
        return null;
    }

    @Override
    public void setInventorySlotContents(int i, ItemStack s) {
        if (i < 0 || i >= MAX_SLOTS) return;
        inv[i] = s;
        if (s != null && s.stackSize > 1) s.stackSize = 1;
        markDirty();
    }

    @Override
    public String getInventoryName() {
        return "Miner Farm";
    }

    @Override
    public boolean hasCustomInventoryName() {
        return false;
    }

    @Override
    public int getInventoryStackLimit() {
        return 1;
    }

    @Override
    public boolean isUseableByPlayer(EntityPlayer p) {
        return worldObj != null && worldObj.getTileEntity(xCoord, yCoord, zCoord) == this
                && p.getDistanceSq(xCoord + 0.5, yCoord + 0.5, zCoord + 0.5) <= 64;
    }

    @Override
    public void openInventory() {
    }

    @Override
    public void closeInventory() {
    }

    @Override
    public boolean isItemValidForSlot(int i, ItemStack s) {
        PartSpec sp = specOf(s);
        if (sp == null || i < 0 || i >= getSizeInventory() || sp.cat != kindOf(i)) return false;
        return sp.cat != Cat.GPU || sp.hash > 0;
    }

    // ---------- NBT ----------
    @Override
    public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag);
        for (int i = 0; i < MAX_SLOTS; i++) inv[i] = null;
        NBTTagList l = tag.getTagList("Items", 10);
        for (int i = 0; i < l.tagCount(); i++) {
            NBTTagCompound c = l.getCompoundTagAt(i);
            int s = c.getByte("Slot") & 255;
            if (s < MAX_SLOTS) inv[s] = ItemStack.loadItemStackFromNBT(c);
        }
        on = tag.getBoolean("on");
        hot = tag.getBoolean("hot");
        temp = tag.hasKey("temp") ? tag.getDouble("temp") : 25;
        stored = tag.getLong("stored");
        pending = tag.getDouble("pending");
        owner = tag.getString("owner");
        ownerName = tag.getString("ownerName");
    }

    @Override
    public void writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag);
        NBTTagList l = new NBTTagList();
        for (int i = 0; i < MAX_SLOTS; i++) {
            if (inv[i] != null) {
                NBTTagCompound c = new NBTTagCompound();
                c.setByte("Slot", (byte) i);
                inv[i].writeToNBT(c);
                l.appendTag(c);
            }
        }
        tag.setTag("Items", l);
        tag.setBoolean("on", on);
        tag.setBoolean("hot", hot);
        tag.setDouble("temp", temp);
        tag.setLong("stored", stored);
        tag.setDouble("pending", pending);
        tag.setString("owner", owner);
        tag.setString("ownerName", ownerName);
    }
}
