package ru.pcmod.common;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerComputer extends Container {
    public final TileComputer tile;
    /** x,y каждого слота компонентов (индекс = номер слота TileComputer). */
    public static final int[][] POS = {
            {8, 22},   // MB
            {34, 22},  // CPU
            {60, 22},  // COOLER
            {8, 58},   // RAM1
            {34, 58},  // RAM2
            {60, 58},  // RAM3
            {86, 58},  // RAM4
            {86, 22},  // GPU
            {138, 22}, // STORAGE
            {112, 22}, // PSU
            {138, 58}, // MEDIA
            {112, 58}  // NET (Wi-Fi модуль)
    };

    public ContainerComputer(InventoryPlayer inv, TileComputer t) {
        this.tile = t;
        for (int i = 0; i < TileComputer.SLOTS; i++) {
            addSlotToContainer(new SlotPart(t, i, POS[i][0], POS[i][1]));
        }
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                addSlotToContainer(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 140 + r * 18));
            }
        }
        for (int c = 0; c < 9; c++) {
            addSlotToContainer(new Slot(inv, c, 8 + c * 18, 198));
        }
    }

    @Override
    public boolean canInteractWith(EntityPlayer p) {
        return tile.isUseableByPlayer(p);
    }

    @Override
    public ItemStack transferStackInSlot(EntityPlayer p, int idx) {
        ItemStack result = null;
        Slot slot = (Slot) inventorySlots.get(idx);
        if (slot != null && slot.getHasStack()) {
            ItemStack st = slot.getStack();
            result = st.copy();
            if (idx < TileComputer.SLOTS) {
                if (!mergeItemStack(st, TileComputer.SLOTS, inventorySlots.size(), true)) return null;
            } else {
                boolean moved = false;
                for (int i = 0; i < TileComputer.SLOTS; i++) {
                    Slot s = (Slot) inventorySlots.get(i);
                    if (!s.getHasStack() && s.isItemValid(st)) {
                        s.putStack(st.splitStack(1));
                        moved = true;
                        break;
                    }
                }
                if (!moved) return null;
            }
            if (st.stackSize == 0) slot.putStack(null);
            else slot.onSlotChanged();
            if (st.stackSize == result.stackSize) return null;
            slot.onPickupFromSlot(p, st);
        }
        return result;
    }
}
