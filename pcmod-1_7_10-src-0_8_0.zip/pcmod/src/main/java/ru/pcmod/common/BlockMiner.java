package ru.pcmod.common;

import net.minecraft.block.Block;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

/** Майнер-ферма F1 (4 видеокарты) / F2 (8 видеокарт). Ставится вплотную к кабелю или роутеру, ПКМ открывает окно. */
public class BlockMiner extends BlockNetDevice {
    public BlockMiner(int tier) {
        super("miner", tier, GuiHandler.MINER);
    }

    @Override
    public TileEntity createNewTileEntity(World world, int meta) {
        return new TileMiner();
    }

    /** Кто поставил ферму, тот и владелец: только он забирает намайненное. */
    @Override
    public void onBlockPlacedBy(World w, int x, int y, int z, EntityLivingBase p, ItemStack s) {
        super.onBlockPlacedBy(w, x, y, z, p, s);
        if (!w.isRemote && p instanceof EntityPlayer) {
            TileEntity te = w.getTileEntity(x, y, z);
            if (te instanceof TileMiner) {
                ((TileMiner) te).owner = ((EntityPlayer) p).getUniqueID().toString();
                ((TileMiner) te).ownerName = ((EntityPlayer) p).getCommandSenderName();
                te.markDirty();
            }
        }
    }

    /** При разрушении детали из слотов выпадают. */
    @Override
    public void breakBlock(World w, int x, int y, int z, Block block, int meta) {
        TileEntity te = w.getTileEntity(x, y, z);
        if (te instanceof TileMiner && !w.isRemote) {
            TileMiner m = (TileMiner) te;
            for (int i = 0; i < m.getSizeInventory(); i++) {
                ItemStack st = m.takeSilently(i);
                if (st != null) w.spawnEntityInWorld(new EntityItem(w, x + 0.5, y + 0.5, z + 0.5, st));
            }
        }
        super.breakBlock(w, x, y, z, block, meta);
    }
}
