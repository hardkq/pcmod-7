package ru.pcmod.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraft.world.WorldSavedData;

/**
 * Банк мира: счета игроков (по UUID) в «консах», купюры, пополнение и снятие.
 * Данные лежат в сохранении мира (WorldSavedData основного мира), поэтому общие для всех ПК.
 * Здесь же хранятся счётчики покупок магазина за текущий период ротации каталога.
 */
public class Bank extends WorldSavedData {
    public static final String ID = "pcmod_bank";
    /** Номиналы купюр (метаданные предмета = индекс). */
    public static final int[] DENOM = {1, 5, 10, 50, 100, 500, 1000};
    public static final long MAX_BALANCE = 2000000000L;
    public static final long MAX_WITHDRAW = 100000L;
    static final int LOG_MAX = 8;

    /** Результат операции: ok + текст для экрана. */
    public static final class Res {
        public final boolean ok;
        public final String msg;

        public Res(boolean ok, String msg) {
            this.ok = ok;
            this.msg = msg;
        }
    }

    private final Map<String, Long> bal = new HashMap<String, Long>();
    private final Map<String, String> names = new HashMap<String, String>();
    private final Map<String, List<String>> logs = new HashMap<String, List<String>>();
    /** Покупки магазина в текущем периоде: "uuid|offer" -> сколько куплено игроком; "offer" -> продано всего. */
    private final Map<String, Integer> bought = new HashMap<String, Integer>();
    private final Map<String, Integer> sold = new HashMap<String, Integer>();
    private long epoch = -1;

    public Bank(String name) {
        super(name);
    }

    /** Банк основного мира или null, если сервер ещё не запущен. */
    public static Bank get() {
        MinecraftServer srv = MinecraftServer.getServer();
        if (srv == null) return null;
        World w = srv.worldServerForDimension(0);
        if (w == null || w.mapStorage == null) return null;
        Bank b = (Bank) w.mapStorage.loadData(Bank.class, ID);
        if (b == null) {
            b = new Bank(ID);
            w.mapStorage.setData(ID, b);
        }
        return b;
    }

    // ===================== счета =====================
    public long balance(String id) {
        Long v = bal.get(id);
        return v == null ? 0L : v.longValue();
    }

    public void setBalance(String id, long v) {
        bal.put(id, Long.valueOf(Math.max(0L, Math.min(MAX_BALANCE, v))));
        markDirty();
    }

    public void rename(String id, String name) {
        if (name != null && !name.equals(names.get(id))) {
            names.put(id, name);
            markDirty();
        }
    }

    public void log(String id, String text) {
        List<String> l = logs.get(id);
        if (l == null) {
            l = new ArrayList<String>();
            logs.put(id, l);
        }
        l.add(text);
        while (l.size() > LOG_MAX) l.remove(0);
        markDirty();
    }

    /** Последние операции, новые в конце. */
    public List<String> history(String id) {
        List<String> l = logs.get(id);
        return l == null ? new ArrayList<String>() : l;
    }

    // ===================== периоды магазина =====================
    /** Новый период каталога: счётчики покупок обнуляются. */
    public void roll(long ep) {
        if (epoch != ep) {
            epoch = ep;
            bought.clear();
            sold.clear();
            markDirty();
        }
    }

    public int boughtBy(String id, String offer) {
        Integer v = bought.get(id + "|" + offer);
        return v == null ? 0 : v.intValue();
    }

    public int soldTotal(String offer) {
        Integer v = sold.get(offer);
        return v == null ? 0 : v.intValue();
    }

    public void addPurchase(String id, String offer, int qty) {
        String k = id + "|" + offer;
        bought.put(k, Integer.valueOf(boughtBy(id, offer) + qty));
        sold.put(offer, Integer.valueOf(soldTotal(offer) + qty));
        markDirty();
    }

    // ===================== наличные =====================
    public static int value(ItemStack s) {
        if (s == null || s.getItem() != ModItems.bill) return 0;
        return Bank.DENOM[ItemBill.meta(s)];
    }

    /** Сколько консов наличными в основном инвентаре игрока. */
    public static long cash(EntityPlayer p) {
        long sum = 0;
        ItemStack[] inv = p.inventory.mainInventory;
        for (int i = 0; i < inv.length; i++) sum += (long) value(inv[i]) * (inv[i] == null ? 0 : inv[i].stackSize);
        return sum;
    }

    /** Забирает все купюры из инвентаря, возвращает их сумму. */
    public static long takeCash(EntityPlayer p) {
        long sum = 0;
        ItemStack[] inv = p.inventory.mainInventory;
        for (int i = 0; i < inv.length; i++) {
            int v = value(inv[i]);
            if (v > 0) {
                sum += (long) v * inv[i].stackSize;
                inv[i] = null;
            }
        }
        syncInventory(p);
        return sum;
    }

    public static void syncInventory(EntityPlayer p) {
        p.inventory.markDirty();
        if (p.inventoryContainer != null) p.inventoryContainer.detectAndSendChanges();
    }

    /** Кладёт предметы в инвентарь, остаток, не влезший в сумки, выбрасывает рядом с игроком. */
    public static void give(EntityPlayer p, ItemStack st) {
        p.inventory.addItemStackToInventory(st);
        if (st.stackSize > 0) p.entityDropItem(st, 0.5F);
        syncInventory(p);
    }

    /** Выдаёт сумму купюрами (крупными номиналами вперёд). */
    public static void giveCash(EntityPlayer p, long amount) {
        for (int i = DENOM.length - 1; i >= 0 && amount > 0; i--) {
            long n = amount / DENOM[i];
            amount -= n * DENOM[i];
            while (n > 0) {
                int c = (int) Math.min(n, 64L);
                give(p, new ItemStack(ModItems.bill, c, i));
                n -= c;
            }
        }
    }

    public static String fmt(long v) {
        return v + " K";
    }

    // ===================== операции =====================
    /** Пополнение со своих купюр. amount < 0 — внести всё. Сдача возвращается купюрами. */
    public Res deposit(EntityPlayer p, long amount) {
        String id = p.getUniqueID().toString();
        rename(id, p.getCommandSenderName());
        long have = cash(p);
        if (have <= 0) return new Res(false, "No kons banknotes in your inventory");
        if (amount < 0) amount = have;
        if (amount == 0) return new Res(false, "Enter an amount");
        if (amount > have) return new Res(false, "You carry only " + fmt(have));
        if (balance(id) + amount > MAX_BALANCE) return new Res(false, "Account limit reached");
        long taken = takeCash(p);
        long change = taken - amount;
        if (change > 0) giveCash(p, change);
        setBalance(id, balance(id) + amount);
        log(id, "+" + fmt(amount) + " deposit");
        return new Res(true, "Deposited " + fmt(amount) + (change > 0 ? " (change " + fmt(change) + ")" : ""));
    }

    /** Снятие купюрами. */
    public Res withdraw(EntityPlayer p, long amount) {
        String id = p.getUniqueID().toString();
        rename(id, p.getCommandSenderName());
        if (amount <= 0) return new Res(false, "Enter an amount");
        if (amount > MAX_WITHDRAW) return new Res(false, "Max withdrawal is " + fmt(MAX_WITHDRAW));
        if (balance(id) < amount) return new Res(false, "Not enough funds on the account");
        setBalance(id, balance(id) - amount);
        giveCash(p, amount);
        log(id, "-" + fmt(amount) + " withdraw");
        return new Res(true, "Withdrew " + fmt(amount));
    }

    // ===================== NBT =====================
    @Override
    public void readFromNBT(NBTTagCompound tag) {
        bal.clear();
        names.clear();
        logs.clear();
        bought.clear();
        sold.clear();
        NBTTagList acc = tag.getTagList("acc", 10);
        for (int i = 0; i < acc.tagCount(); i++) {
            NBTTagCompound c = acc.getCompoundTagAt(i);
            String id = c.getString("id");
            if (id.length() == 0) continue;
            bal.put(id, Long.valueOf(c.getLong("b")));
            names.put(id, c.getString("n"));
            NBTTagList ll = c.getTagList("log", 8);
            List<String> l = new ArrayList<String>();
            for (int j = 0; j < ll.tagCount(); j++) l.add(ll.getStringTagAt(j));
            logs.put(id, l);
        }
        epoch = tag.hasKey("epoch") ? tag.getLong("epoch") : -1L;
        NBTTagList bl = tag.getTagList("bought", 10);
        for (int i = 0; i < bl.tagCount(); i++) {
            NBTTagCompound c = bl.getCompoundTagAt(i);
            bought.put(c.getString("k"), Integer.valueOf(c.getInteger("n")));
        }
        NBTTagList sl = tag.getTagList("sold", 10);
        for (int i = 0; i < sl.tagCount(); i++) {
            NBTTagCompound c = sl.getCompoundTagAt(i);
            sold.put(c.getString("k"), Integer.valueOf(c.getInteger("n")));
        }
    }

    @Override
    public void writeToNBT(NBTTagCompound tag) {
        NBTTagList acc = new NBTTagList();
        for (Map.Entry<String, Long> e : bal.entrySet()) {
            NBTTagCompound c = new NBTTagCompound();
            c.setString("id", e.getKey());
            c.setLong("b", e.getValue().longValue());
            String n = names.get(e.getKey());
            c.setString("n", n == null ? "" : n);
            NBTTagList ll = new NBTTagList();
            for (String s : history(e.getKey())) ll.appendTag(new net.minecraft.nbt.NBTTagString(s));
            c.setTag("log", ll);
            acc.appendTag(c);
        }
        tag.setTag("acc", acc);
        tag.setLong("epoch", epoch);
        NBTTagList bl = new NBTTagList();
        for (Map.Entry<String, Integer> e : bought.entrySet()) {
            NBTTagCompound c = new NBTTagCompound();
            c.setString("k", e.getKey());
            c.setInteger("n", e.getValue().intValue());
            bl.appendTag(c);
        }
        tag.setTag("bought", bl);
        NBTTagList sl = new NBTTagList();
        for (Map.Entry<String, Integer> e : sold.entrySet()) {
            NBTTagCompound c = new NBTTagCompound();
            c.setString("k", e.getKey());
            c.setInteger("n", e.getValue().intValue());
            sl.appendTag(c);
        }
        tag.setTag("sold", sl);
    }

    /** Имя игрока по UUID (для команд и экрана). */
    public String nameOf(String id) {
        String n = names.get(id);
        return n == null ? id : n;
    }
}
