package ru.pcmod.common;

import net.minecraft.block.Block;
import net.minecraft.world.IBlockAccess;

/** Видеокабель: соединяет корпус ПК с монитором. В цепочке между ними может быть до {@link VideoLink#MAX_CABLES} кабелей. */
public class BlockVideoCable extends BlockWire {
    public BlockVideoCable() {
        super("pcmod.video_cable", "pcmod:video_cable");
    }

    @Override
    public boolean connects(IBlockAccess w, int x, int y, int z, int d) {
        Block b = w.getBlock(x + Net.DX[d], y + Net.DY[d], z + Net.DZ[d]);
        return b instanceof BlockVideoCable || b instanceof BlockMonitor || b instanceof BlockComputer;
    }
}
