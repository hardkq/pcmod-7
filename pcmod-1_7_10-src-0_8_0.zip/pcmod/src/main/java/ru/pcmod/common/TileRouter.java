package ru.pcmod.common;

import net.minecraft.block.Block;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;

/** Роутер: раздаёт Wi-Fi (SSID, пароль) и объединяет кабели и серверы в сеть. */
public class TileRouter extends TileEntity {
    public String ssid = "";
    public String pass = "";
    public boolean wifiOn = true;
    /** Для GUI на клиенте (сам пароль клиенту не отправляется). */
    public boolean hasPassClient;

    public int tier() {
        if (worldObj == null) return 0;
        Block b = getBlockType();
        return b instanceof BlockNetDevice ? ((BlockNetDevice) b).tier : 0;
    }

    /** Радиус Wi-Fi в блоках. */
    public int range() {
        return tier() == 0 ? 24 : 64;
    }

    @Override
    public boolean canUpdate() {
        return false;
    }

    @Override
    public void validate() {
        super.validate();
        if (worldObj != null && !worldObj.isRemote) {
            if (ssid.length() == 0) {
                ssid = "PCNet-" + Integer.toHexString((xCoord * 31 + yCoord * 7 + zCoord * 17) & 0xFFFF).toUpperCase();
            }
            Net.register(this);
        }
    }

    @Override
    public void invalidate() {
        super.invalidate();
        Net.unregister(this);
    }

    @Override
    public void onChunkUnload() {
        super.onChunkUnload();
        Net.unregister(this);
    }

    /** null = применено, иначе текст ошибки. */
    public String applyConfig(String newSsid, String newPass, boolean on, boolean clearPass) {
        if (!Net.validSsid(newSsid)) return "SSID: 1-16 chars (A-Z, a-z, 0-9, _, -)";
        if (newPass.length() > 0 && !Net.validPass(newPass)) return "Password: 1-16 chars, no spaces";
        ssid = newSsid;
        if (clearPass) pass = "";
        else if (newPass.length() > 0) pass = newPass;
        wifiOn = on;
        markDirty();
        if (worldObj != null) worldObj.markBlockForUpdate(xCoord, yCoord, zCoord);
        return null;
    }

    @Override
    public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag);
        ssid = tag.getString("ssid");
        pass = tag.getString("pass");
        wifiOn = !tag.hasKey("wifiOn") || tag.getBoolean("wifiOn");
    }

    @Override
    public void writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag);
        tag.setString("ssid", ssid);
        tag.setString("pass", pass);
        tag.setBoolean("wifiOn", wifiOn);
    }

    @Override
    public Packet getDescriptionPacket() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setString("ssid", ssid);
        tag.setBoolean("hasPass", pass.length() > 0);
        tag.setBoolean("wifiOn", wifiOn);
        return new S35PacketUpdateTileEntity(xCoord, yCoord, zCoord, 0, tag);
    }

    @Override
    public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt) {
        NBTTagCompound tag = pkt.func_148857_g();
        ssid = tag.getString("ssid");
        hasPassClient = tag.getBoolean("hasPass");
        wifiOn = tag.getBoolean("wifiOn");
    }
}
