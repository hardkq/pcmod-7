package ru.pcmod.common;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;

/** Купюра «Конс». Номинал зависит от метаданных: 1, 5, 10, 50, 100, 500, 1000. */
public class ItemBill extends Item {
    @SideOnly(Side.CLIENT)
    private IIcon[] icons;

    public ItemBill() {
        setHasSubtypes(true);
        setMaxDamage(0);
        setMaxStackSize(64);
    }

    public static int meta(ItemStack s) {
        int m = s == null ? 0 : s.getItemDamage();
        return m < 0 ? 0 : m >= Bank.DENOM.length ? Bank.DENOM.length - 1 : m;
    }

    @Override
    public String getUnlocalizedName(ItemStack s) {
        return "item.pcmod.bill_" + Bank.DENOM[meta(s)];
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerIcons(IIconRegister reg) {
        icons = new IIcon[Bank.DENOM.length];
        for (int i = 0; i < icons.length; i++) icons[i] = reg.registerIcon("pcmod:bill_" + Bank.DENOM[i]);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public IIcon getIconFromDamage(int meta) {
        int m = meta < 0 ? 0 : meta >= icons.length ? icons.length - 1 : meta;
        return icons[m];
    }

    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void getSubItems(Item item, CreativeTabs tab, List list) {
        for (int i = 0; i < Bank.DENOM.length; i++) list.add(new ItemStack(item, 1, i));
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean adv) {
        list.add("§7Kons banknote: " + Bank.DENOM[meta(stack)] + " K");
        list.add("§7Deposit it in the PCOS 'Bank' app");
    }
}
