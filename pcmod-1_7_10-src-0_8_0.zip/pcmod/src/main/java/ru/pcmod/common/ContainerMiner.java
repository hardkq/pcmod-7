package ru.pcmod.common;

import java.util.Arrays;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;

/**
 * Контейнер майнер-фермы: слоты GPU / PSU / кулер + инвентарь игрока.
 * Состояние фермы идёт клиенту «полосками прогресса» (каждое число двумя половинками по 16 бит),
 * кнопки окна приходят как enchantItem (0 = Power, 1 = Collect), отдельные пакеты не нужны.
 */
public class ContainerMiner extends ContainerBlank {
    public static final int HEIGHT = 246, INV_X = 19, INV_Y = 166, HOTBAR_Y = 224, GPU_Y = 104, SUP_Y = 134;
    public static final int VALUES = 10;

    public final TileMiner miner;
    public final int slots;
    /** Значения для экрана (на клиенте приходят с сервера). */
    public final int[] data = new int[VALUES];
    private final int[] lo = new int[VALUES], hi = new int[VALUES], last = new int[VALUES];

    public ContainerMiner(InventoryPlayer inv, TileMiner t) {
        super(t);
        this.miner = t;
        this.slots = t.getSizeInventory();
        int g = t.gpuSlots(), p = t.psuSlots();
        int gx = (200 - g * 18) / 2;
        for (int i = 0; i < g; i++) addSlotToContainer(new SlotMiner(t, i, gx + i * 18, GPU_Y));
        for (int i = 0; i < p; i++) addSlotToContainer(new SlotMiner(t, g + i, 10 + i * 18, SUP_Y));
        for (int i = 0; i < p; i++) addSlotToContainer(new SlotMiner(t, g + p + i, 110 + i * 18, SUP_Y));
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) addSlotToContainer(new Slot(inv, c + r * 9 + 9, INV_X + c * 18, INV_Y + r * 18));
        }
        for (int c = 0; c < 9; c++) addSlotToContainer(new Slot(inv, c, INV_X + c * 18, HOTBAR_Y));
        Arrays.fill(last, Integer.MIN_VALUE);
    }

    @Override
    public void addCraftingToCrafters(ICrafting c) {
        super.addCraftingToCrafters(c);
        Arrays.fill(last, Integer.MIN_VALUE);
    }

    @Override
    public void detectAndSendChanges() {
        super.detectAndSendChanges();
        if (miner.getWorldObj() == null || miner.getWorldObj().isRemote) return;
        int[] now = miner.syncValues();
        for (int i = 0; i < VALUES; i++) {
            if (now[i] == last[i]) continue;
            last[i] = now[i];
            for (Object o : crafters) {
                ICrafting c = (ICrafting) o;
                c.sendProgressBarUpdate(this, i * 2, now[i] & 0xFFFF);
                c.sendProgressBarUpdate(this, i * 2 + 1, now[i] >>> 16);
            }
        }
    }

    @Override
    public void updateProgressBar(int id, int value) {
        int i = id >> 1;
        if (i < 0 || i >= VALUES) return;
        if ((id & 1) == 0) lo[i] = value & 0xFFFF;
        else hi[i] = value & 0xFFFF;
        data[i] = lo[i] | (hi[i] << 16);
    }

    @Override
    public boolean enchantItem(EntityPlayer p, int id) {
        if (miner.getWorldObj() == null || miner.getWorldObj().isRemote) return false;
        String msg = id == 0 ? miner.togglePower() : id == 1 ? miner.collect(p) : null;
        if (msg != null) p.addChatMessage(new ChatComponentText(msg));
        return true;
    }

    @Override
    public ItemStack transferStackInSlot(EntityPlayer p, int idx) {
        ItemStack result = null;
        Slot slot = (Slot) inventorySlots.get(idx);
        if (slot != null && slot.getHasStack()) {
            ItemStack st = slot.getStack();
            result = st.copy();
            if (idx < slots) {
                if (!mergeItemStack(st, slots, inventorySlots.size(), true)) return null;
            } else {
                boolean moved = false;
                for (int i = 0; i < slots; i++) {
                    Slot s = (Slot) inventorySlots.get(i);
                    if (!s.getHasStack() && s.isItemValid(st)) {
                        s.putStack(st.splitStack(1));
                        moved = true;
                        break;
                    }
                }
                if (!moved) return null;
            }
            if (st.stackSize == 0) slot.putStack(null);
            else slot.onSlotChanged();
            if (st.stackSize == result.stackSize) return null;
            slot.onPickupFromSlot(p, st);
        }
        return result;
    }
}
