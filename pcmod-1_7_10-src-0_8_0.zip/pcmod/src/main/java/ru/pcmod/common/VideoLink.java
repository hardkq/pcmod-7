package ru.pcmod.common;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

/** Поиск связи «корпус ПК - монитор»: вплотную или через цепочку видеокабелей (до MAX_CABLES штук). */
public final class VideoLink {
    /** Сколько видеокабелей может быть между корпусом и монитором. */
    public static final int MAX_CABLES = 3;
    private static final int[][] DIRS = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};

    private VideoLink() {
    }

    /** Позиции {x, y, z} всех мониторов, подключённых к корпусу в (x, y, z). Ближайшие идут первыми. */
    public static List<int[]> monitorsOf(World w, int x, int y, int z) {
        return search(w, x, y, z, true);
    }

    /** ПК, к которому подключён монитор в (x, y, z), или null. */
    public static TileComputer computerOf(World w, int x, int y, int z) {
        for (int[] p : search(w, x, y, z, false)) {
            TileEntity te = w.getTileEntity(p[0], p[1], p[2]);
            if (te instanceof TileComputer) return (TileComputer) te;
        }
        return null;
    }

    /** Поиск в ширину от точки старта по видеокабелям; ищет мониторы (wantMonitor) или корпуса ПК. */
    private static List<int[]> search(World w, int sx, int sy, int sz, boolean wantMonitor) {
        List<int[]> found = new ArrayList<int[]>();
        Set<Long> seen = new HashSet<Long>();
        ArrayDeque<int[]> queue = new ArrayDeque<int[]>();
        seen.add(key(sx, sy, sz));
        queue.add(new int[]{sx, sy, sz, 0}); // последнее число - сколько кабелей пройдено
        while (!queue.isEmpty()) {
            int[] cur = queue.poll();
            for (int[] d : DIRS) {
                int x = cur[0] + d[0], y = cur[1] + d[1], z = cur[2] + d[2];
                if (y < 0 || y > 255 || !w.blockExists(x, y, z) || !seen.add(key(x, y, z))) continue;
                Block b = w.getBlock(x, y, z);
                if (wantMonitor ? b instanceof BlockMonitor : b instanceof BlockComputer) {
                    found.add(new int[]{x, y, z});
                } else if (b instanceof BlockVideoCable && cur[3] < MAX_CABLES) {
                    queue.add(new int[]{x, y, z, cur[3] + 1});
                }
            }
        }
        return found;
    }

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF);
    }
}
