package ru.pcmod.common;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;

/** Контейнер сервера: отсеки под HDD + инвентарь игрока. Настройки (домен) идут через PacketNetConfig как раньше. */
public class ContainerServer extends ContainerBlank {
    public static final int BAY_Y = 120, INV_X = 19, INV_Y = 148, HOTBAR_Y = 206;
    public final TileServer server;
    public final int bays;

    public ContainerServer(InventoryPlayer inv, TileServer t) {
        super(t);
        this.server = t;
        this.bays = t.bays();
        int x0 = bayX0(bays);
        for (int i = 0; i < bays; i++) addSlotToContainer(new SlotDrive(t, i, x0 + i * 18, BAY_Y));
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) addSlotToContainer(new Slot(inv, c + r * 9 + 9, INV_X + c * 18, INV_Y + r * 18));
        }
        for (int c = 0; c < 9; c++) addSlotToContainer(new Slot(inv, c, INV_X + c * 18, HOTBAR_Y));
    }

    /** X первого отсека (ширина окна 200), отсеки центрируются. */
    public static int bayX0(int bays) {
        return (200 - bays * 18) / 2;
    }

    @Override
    public ItemStack slotClick(int slotId, int button, int mode, EntityPlayer p) {
        if (slotId >= 0 && slotId < bays && !server.getWorldObj().isRemote) {
            Slot s = (Slot) inventorySlots.get(slotId);
            if (s.getHasStack() && !s.canTakeStack(p)) {
                p.addChatMessage(new ChatComponentText(
                        "Drive is in use: too many accounts for the remaining storage (wipe chat data first)"));
            }
        }
        return super.slotClick(slotId, button, mode, p);
    }

    @Override
    public ItemStack transferStackInSlot(EntityPlayer p, int idx) {
        ItemStack result = null;
        Slot slot = (Slot) inventorySlots.get(idx);
        if (slot != null && slot.getHasStack()) {
            ItemStack st = slot.getStack();
            result = st.copy();
            if (idx < bays) {
                if (!slot.canTakeStack(p)) return null;
                if (!mergeItemStack(st, bays, inventorySlots.size(), true)) return null;
            } else {
                boolean moved = false;
                for (int i = 0; i < bays; i++) {
                    Slot s = (Slot) inventorySlots.get(i);
                    if (!s.getHasStack() && s.isItemValid(st)) {
                        s.putStack(st.splitStack(1));
                        moved = true;
                        break;
                    }
                }
                if (!moved) return null;
            }
            if (st.stackSize == 0) slot.putStack(null);
            else slot.onSlotChanged();
            if (st.stackSize == result.stackSize) return null;
            slot.onPickupFromSlot(p, st);
        }
        return result;
    }
}
