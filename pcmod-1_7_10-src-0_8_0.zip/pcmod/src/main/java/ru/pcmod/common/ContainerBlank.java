package ru.pcmod.common;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

/** Пустой контейнер для GUI настроек роутера и сервера (нужен, чтобы FML открыл экран). */
public class ContainerBlank extends Container {
    public final TileEntity tile;

    public ContainerBlank(TileEntity t) {
        this.tile = t;
    }

    @Override
    public boolean canInteractWith(EntityPlayer p) {
        World w = tile.getWorldObj();
        return w != null && w.getTileEntity(tile.xCoord, tile.yCoord, tile.zCoord) == tile
                && p.getDistanceSq(tile.xCoord + 0.5, tile.yCoord + 0.5, tile.zCoord + 0.5) <= 64;
    }
}
