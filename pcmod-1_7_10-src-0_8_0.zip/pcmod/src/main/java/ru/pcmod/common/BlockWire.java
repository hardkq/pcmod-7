package ru.pcmod.common;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.IIcon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

/** Основа для проводов: тонкий блок с «жилами» в сторону соединённых соседей (сетевой и видеокабель). */
public abstract class BlockWire extends Block {
    /** Выставляется клиентом при регистрации рендера. */
    public static int renderId = -1;
    private static final float A = 0.375F, B = 0.625F;
    @SideOnly(Side.CLIENT)
    private IIcon icon;

    private final String iconName;

    protected BlockWire(String name, String iconName) {
        super(Material.circuits);
        this.iconName = iconName;
        setBlockName(name);
        setHardness(0.4F);
        setResistance(2.0F);
        setStepSound(soundTypeMetal);
        setCreativeTab(ModItems.tab);
        setBlockBounds(A, A, A, B, B, B);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public int getRenderType() {
        return renderId;
    }

    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World w, int x, int y, int z) {
        return null;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerBlockIcons(IIconRegister r) {
        icon = r.registerIcon(iconName);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public IIcon getIcon(int side, int meta) {
        return icon;
    }

    /** Тянется ли провод в сторону d (0 низ, 1 верх, 2 север, 3 юг, 4 запад, 5 восток). */
    public abstract boolean connects(IBlockAccess w, int x, int y, int z, int d);

    @Override
    public void setBlockBoundsBasedOnState(IBlockAccess w, int x, int y, int z) {
        float minX = A, minY = A, minZ = A, maxX = B, maxY = B, maxZ = B;
        if (connects(w, x, y, z, 0)) minY = 0.0F;
        if (connects(w, x, y, z, 1)) maxY = 1.0F;
        if (connects(w, x, y, z, 2)) minZ = 0.0F;
        if (connects(w, x, y, z, 3)) maxZ = 1.0F;
        if (connects(w, x, y, z, 4)) minX = 0.0F;
        if (connects(w, x, y, z, 5)) maxX = 1.0F;
        setBlockBounds(minX, minY, minZ, maxX, maxY, maxZ);
    }
}
