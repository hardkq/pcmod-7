package ru.pcmod.common;

import net.minecraft.world.World;

public class CommonProxy {
    public World clientWorld() {
        return null;
    }

    /** Клиентская регистрация (рендер кабеля); на сервере ничего не делает. */
    public void registerRenderers() {
    }
}
