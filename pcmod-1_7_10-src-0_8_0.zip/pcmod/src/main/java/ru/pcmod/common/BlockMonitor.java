package ru.pcmod.common;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import ru.pcmod.PCMod;

/** Блок монитора. Ставится вплотную к корпусу ПК или соединяется с ним видеокабелем (до 3 блоков); ПКМ открывает экран подключённого ПК. */
public class BlockMonitor extends Block {
    public final int type;
    @SideOnly(Side.CLIENT)
    private IIcon iconFront, iconSide;

    public BlockMonitor(int type) {
        super(Material.iron);
        this.type = type;
        setBlockName("pcmod.monitor" + type);
        setHardness(2.0F);
        setResistance(8.0F);
        setStepSound(soundTypeMetal);
        setCreativeTab(ModItems.tab);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerBlockIcons(IIconRegister r) {
        iconFront = r.registerIcon("pcmod:monitor" + type + "_front");
        iconSide = r.registerIcon("pcmod:monitor" + type + "_side");
    }

    @Override
    @SideOnly(Side.CLIENT)
    public IIcon getIcon(int side, int meta) {
        if (side == 0 || side == 1) return iconSide;
        if (meta == 0) meta = 3;
        return side == meta ? iconFront : iconSide;
    }

    @Override
    public void onBlockPlacedBy(World w, int x, int y, int z, EntityLivingBase p, ItemStack s) {
        int l = MathHelper.floor_double(p.rotationYaw * 4.0F / 360.0F + 0.5D) & 3;
        int meta = l == 0 ? 2 : l == 1 ? 5 : l == 2 ? 3 : 4;
        w.setBlockMetadataWithNotify(x, y, z, meta, 2);
    }

    @Override
    public boolean onBlockActivated(World w, int x, int y, int z, EntityPlayer p, int side, float hx, float hy, float hz) {
        if (w.isRemote) return true;
        TileComputer c = VideoLink.computerOf(w, x, y, z);
        if (c != null) {
            p.openGui(PCMod.instance, GuiHandler.MONITOR, w, c.xCoord, c.yCoord, c.zCoord);
            return true;
        }
        p.addChatMessage(new ChatComponentText("This monitor is not connected. Place it next to a PC case or link it with video cables (up to " + VideoLink.MAX_CABLES + ")."));
        return true;
    }
}
