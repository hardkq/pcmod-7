package ru.pcmod.common;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

/** Отсек сервера: принимает только HDD. Диск нельзя вынуть, если без него не поместятся аккаунты. */
public class SlotDrive extends Slot {
    private final TileServer tile;

    public SlotDrive(TileServer t, int index, int x, int y) {
        super(t, index, x, y);
        this.tile = t;
    }

    @Override
    public boolean isItemValid(ItemStack s) {
        return tile.isItemValidForSlot(getSlotIndex(), s);
    }

    @Override
    public boolean canTakeStack(EntityPlayer p) {
        return tile.canRemoveDrive(getSlotIndex());
    }

    @Override
    public int getSlotStackLimit() {
        return 1;
    }
}
