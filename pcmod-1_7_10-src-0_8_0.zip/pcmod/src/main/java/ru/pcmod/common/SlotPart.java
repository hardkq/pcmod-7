package ru.pcmod.common;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

/** Слот для компонента: пока ПК включён, менять железо нельзя. */
public class SlotPart extends Slot {
    private final TileComputer tile;

    public SlotPart(TileComputer t, int index, int x, int y) {
        super(t, index, x, y);
        this.tile = t;
    }

    @Override
    public boolean isItemValid(ItemStack s) {
        return !tile.isOn() && tile.isItemValidForSlot(getSlotIndex(), s);
    }

    @Override
    public boolean canTakeStack(EntityPlayer p) {
        return !tile.isOn();
    }

    @Override
    public int getSlotStackLimit() {
        return 1;
    }
}
