package ru.pcmod.common;

import net.minecraft.block.Block;
import net.minecraft.world.IBlockAccess;

/** Сетевой кабель: сам соединяется с соседними кабелями, роутерами, серверами и ПК. */
public class BlockCable extends BlockWire {
    public BlockCable() {
        super("pcmod.cable", "pcmod:cable");
    }

    @Override
    public boolean connects(IBlockAccess w, int x, int y, int z, int d) {
        Block b = w.getBlock(x + Net.DX[d], y + Net.DY[d], z + Net.DZ[d]);
        return b instanceof BlockCable || b instanceof BlockNetDevice || b instanceof BlockComputer;
    }
}
