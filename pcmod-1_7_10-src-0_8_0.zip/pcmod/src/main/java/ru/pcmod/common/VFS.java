package ru.pcmod.common;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

/** Виртуальная файловая система PCOS. Хранится в NBT предмета-накопителя (ключ "pcos"). */
public class VFS {
    public static final int OS_SIZE = 24 * 1024;
    /** PixelOS занимает на накопителе заметно больше места, чем PCOS. */
    public static final int PIXEL_OS_SIZE = 96 * 1024;

    /** Код установленной ОС: "pixel" или "pcos" (старые диски без поля - PCOS). */
    public static String osId(NBTTagCompound r) {
        return r != null && "pixel".equals(r.getString("os")) ? "pixel" : "pcos";
    }

    public static String osName(NBTTagCompound r) {
        return osId(r).equals("pixel") ? "PixelOS" : "PCOS";
    }

    public static int osSize(NBTTagCompound r) {
        return osId(r).equals("pixel") ? PIXEL_OS_SIZE : OS_SIZE;
    }

    public static NBTTagCompound root(ItemStack d) {
        if (d == null || !d.hasTagCompound()) return null;
        NBTTagCompound tg = d.getTagCompound();
        return tg.hasKey("pcos", 10) ? tg.getCompoundTag("pcos") : null;
    }

    public static boolean hasOS(ItemStack d) {
        NBTTagCompound r = root(d);
        return r != null && r.getBoolean("installed");
    }

    public static void format(ItemStack d) {
        if (d == null) return;
        NBTTagCompound tg = d.hasTagCompound() ? d.getTagCompound() : new NBTTagCompound();
        tg.setTag("pcos", new NBTTagCompound());
        d.setTagCompound(tg);
    }

    public static String hash(String p) {
        int h = 7;
        for (int i = 0; i < p.length(); i++) h = h * 31 + p.charAt(i);
        return Integer.toHexString(h ^ 0x5bd1e995);
    }

    public static void install(ItemStack d, String user, String pass, String host) {
        install(d, user, pass, host, "pcos");
    }

    public static void install(ItemStack d, String user, String pass, String host, String os) {
        boolean px = "pixel".equals(os);
        String name = px ? "PixelOS" : "PCOS";
        NBTTagCompound tg = d.hasTagCompound() ? d.getTagCompound() : new NBTTagCompound();
        NBTTagCompound r = new NBTTagCompound();
        r.setBoolean("installed", true);
        if (px) r.setString("os", "pixel");
        r.setString("user", user);
        r.setString("pass", hash(pass));
        r.setString("host", host);
        r.setTag("dirs", new NBTTagList());
        r.setTag("files", new NBTTagList());
        tg.setTag("pcos", r);
        d.setTagCompound(tg);
        mkdirRaw(r, "/");
        mkdirRaw(r, "/home");
        mkdirRaw(r, "/home/" + user);
        mkdirRaw(r, "/etc");
        mkdirRaw(r, "/bin");
        setFile(r, "/etc/hostname", host + "\n");
        setFile(r, "/etc/motd", "Welcome to " + name + " 1.0\n");
        setFile(r, "/home/" + user + "/readme.txt", px
                ? "Welcome to PixelOS!\nOpen Paint on the desktop and draw your own pixel art.\n"
                + "Terminal commands: help, neofetch, lshw, sensors\n"
                : "Welcome to PCOS!\nTry: help, neofetch, lshw, sensors, edit notes.txt\n");
    }

    // ---------- низкоуровневые списки ----------
    private static NBTTagList list(NBTTagCompound r, String key) {
        if (!r.hasKey(key, 9)) r.setTag(key, new NBTTagList());
        return r.getTagList(key, 10);
    }

    private static int find(NBTTagList l, String path) {
        for (int i = 0; i < l.tagCount(); i++) {
            if (l.getCompoundTagAt(i).getString("p").equals(path)) return i;
        }
        return -1;
    }

    private static void removeAt(NBTTagCompound r, String key, int idx) {
        NBTTagList old = list(r, key);
        NBTTagList nw = new NBTTagList();
        for (int i = 0; i < old.tagCount(); i++) {
            if (i != idx) nw.appendTag(old.getCompoundTagAt(i));
        }
        r.setTag(key, nw);
    }

    private static void mkdirRaw(NBTTagCompound r, String path) {
        NBTTagCompound c = new NBTTagCompound();
        c.setString("p", path);
        list(r, "dirs").appendTag(c);
    }

    private static void setFile(NBTTagCompound r, String path, String content) {
        NBTTagList l = list(r, "files");
        int i = find(l, path);
        if (i >= 0) {
            l.getCompoundTagAt(i).setString("c", content);
        } else {
            NBTTagCompound c = new NBTTagCompound();
            c.setString("p", path);
            c.setString("c", content);
            l.appendTag(c);
        }
    }

    // ---------- пути ----------
    public static String resolve(String cwd, String p) {
        String full = p.startsWith("/") ? p : (cwd.equals("/") ? "/" + p : cwd + "/" + p);
        ArrayList<String> out = new ArrayList<String>();
        for (String part : full.split("/")) {
            if (part.length() == 0 || part.equals(".")) continue;
            if (part.equals("..")) {
                if (!out.isEmpty()) out.remove(out.size() - 1);
            } else {
                out.add(part);
            }
        }
        if (out.isEmpty()) return "/";
        StringBuilder b = new StringBuilder();
        for (String o : out) b.append('/').append(o);
        return b.toString();
    }

    public static String parent(String path) {
        int i = path.lastIndexOf('/');
        return i <= 0 ? "/" : path.substring(0, i);
    }

    public static String name(String path) {
        return path.substring(path.lastIndexOf('/') + 1);
    }

    // ---------- операции ----------
    public static boolean isDir(NBTTagCompound r, String path) {
        return find(list(r, "dirs"), path) >= 0;
    }

    public static boolean isFile(NBTTagCompound r, String path) {
        return find(list(r, "files"), path) >= 0;
    }

    public static String read(NBTTagCompound r, String path) {
        NBTTagList l = list(r, "files");
        int i = find(l, path);
        return i < 0 ? null : l.getCompoundTagAt(i).getString("c");
    }

    public static int usedBytes(NBTTagCompound r) {
        int n = 0;
        NBTTagList f = list(r, "files");
        for (int i = 0; i < f.tagCount(); i++) n += f.getCompoundTagAt(i).getString("c").length() + 16;
        n += list(r, "dirs").tagCount() * 16;
        return n;
    }

    public static int free(NBTTagCompound r, int capKB) {
        return capKB * 1024 - osSize(r) - usedBytes(r);
    }

    public static boolean write(NBTTagCompound r, String path, String content, int capKB) {
        if (path.equals("/") || isDir(r, path) || !isDir(r, parent(path))) return false;
        int oldLen = 0, extra = 16;
        if (isFile(r, path)) {
            oldLen = read(r, path).length();
            extra = 0;
        }
        if (free(r, capKB) < content.length() - oldLen + extra) return false;
        setFile(r, path, content);
        return true;
    }

    public static boolean mkdir(NBTTagCompound r, String path) {
        if (isDir(r, path) || isFile(r, path) || !isDir(r, parent(path))) return false;
        mkdirRaw(r, path);
        return true;
    }

    /** 0 = ok, 1 = не найдено, 2 = каталог не пуст. */
    public static int remove(NBTTagCompound r, String path) {
        int fi = find(list(r, "files"), path);
        if (fi >= 0) {
            removeAt(r, "files", fi);
            return 0;
        }
        int di = find(list(r, "dirs"), path);
        if (di < 0) return 1;
        if (!listDir(r, path).isEmpty()) return 2;
        removeAt(r, "dirs", di);
        return 0;
    }

    public static List<String> listDir(NBTTagCompound r, String dir) {
        TreeSet<String> out = new TreeSet<String>();
        NBTTagList d = list(r, "dirs");
        for (int i = 0; i < d.tagCount(); i++) {
            String p = d.getCompoundTagAt(i).getString("p");
            if (!p.equals("/") && parent(p).equals(dir)) out.add(name(p) + "/");
        }
        NBTTagList f = list(r, "files");
        for (int i = 0; i < f.tagCount(); i++) {
            String p = f.getCompoundTagAt(i).getString("p");
            if (parent(p).equals(dir)) out.add(name(p));
        }
        return new ArrayList<String>(out);
    }
}
