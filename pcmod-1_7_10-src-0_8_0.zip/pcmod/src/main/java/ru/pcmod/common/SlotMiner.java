package ru.pcmod.common;

import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

/** Слот фермы: принимает только свою деталь (GPU, PSU или кулер). */
public class SlotMiner extends Slot {
    private final TileMiner tile;

    public SlotMiner(TileMiner t, int index, int x, int y) {
        super(t, index, x, y);
        this.tile = t;
    }

    @Override
    public boolean isItemValid(ItemStack s) {
        return tile.isItemValidForSlot(getSlotIndex(), s);
    }

    @Override
    public int getSlotStackLimit() {
        return 1;
    }
}
