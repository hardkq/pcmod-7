package ru.pcmod.common;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

/** Роутер: ПКМ открывает настройки Wi-Fi (SSID, пароль, вкл/выкл). */
public class BlockRouter extends BlockNetDevice {
    public BlockRouter(int tier) {
        super("router", tier, GuiHandler.ROUTER);
    }

    @Override
    public TileEntity createNewTileEntity(World world, int meta) {
        return new TileRouter();
    }
}
