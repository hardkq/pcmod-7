package ru.pcmod.common;

import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemPart extends Item {
    public final PartSpec spec;

    public ItemPart(PartSpec spec) {
        this.spec = spec;
        setMaxStackSize(1);
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean adv) {
        String g = "\u00a77";
        switch (spec.cat) {
            case MOTHERBOARD:
                list.add(g + "Socket " + PartSpec.socketName(spec.socket));
                list.add(g + spec.ramSlots + " x " + PartSpec.ramName(spec.ramType) + " slots");
                break;
            case CPU:
                list.add(g + "Socket " + PartSpec.socketName(spec.socket));
                list.add(g + spec.cores + " cores @ " + spec.ghz + " GHz");
                list.add(g + "TDP " + spec.watts + " W");
                break;
            case COOLER:
                list.add(g + "Cooling rating " + spec.cooling);
                break;
            case RAM:
                list.add(g + PartSpec.ramName(spec.ramType) + ", " + spec.memMB + " MB");
                break;
            case GPU:
                list.add(g + "VRAM " + spec.vram + " MB");
                list.add(g + "Draw " + spec.watts + " W");
                if (spec.hash > 0) list.add("\u00a76Mining: " + spec.hash + " MH/s (miner farm)");
                break;
            case STORAGE:
                list.add(g + "Capacity " + spec.storageKB + " KB");
                list.add(g + "Speed x" + spec.speed);
                if (spec.hdd) {
                    list.add("\u00a73Server drive: +" + TileServer.accountsFor(spec.storageKB) + " accounts, +"
                            + TileServer.msgsFor(spec.storageKB) + " messages");
                }
                if (VFS.hasOS(stack)) {
                    list.add("\u00a7a" + VFS.osName(VFS.root(stack)) + " installed");
                }
                break;
            case PSU:
                list.add(g + "Output " + spec.watts + " W");
                break;
            case MEDIA:
                if (spec.os.equals("pixel")) {
                    list.add(g + "Bootable PixelOS installer");
                    list.add("\u00a7ePixel-art desktop. Needs a powerful PC:");
                    list.add("\u00a7e6+ cores, 8 GB RAM, GT-700+ GPU, 128 KB drive");
                } else {
                    list.add(g + "Bootable PCOS installer");
                }
                break;
            case NET:
                list.add(g + "Wi-Fi adapter: connects the PC to a router wirelessly");
                break;
            default:
                break;
        }
    }
}
