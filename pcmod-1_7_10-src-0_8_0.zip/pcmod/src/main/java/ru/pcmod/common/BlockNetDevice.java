package ru.pcmod.common;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import ru.pcmod.PCMod;

/** Общая основа роутера и сервера: ориентация, текстуры, открытие GUI по ПКМ. */
public abstract class BlockNetDevice extends BlockContainer {
    public final int tier;
    private final String kind;
    private final int gui;
    @SideOnly(Side.CLIENT)
    private IIcon iconFront, iconSide;

    protected BlockNetDevice(String kind, int tier, int gui) {
        super(Material.iron);
        this.kind = kind;
        this.tier = tier;
        this.gui = gui;
        setBlockName("pcmod." + kind + tier);
        setHardness(2.0F);
        setResistance(8.0F);
        setStepSound(soundTypeMetal);
        setCreativeTab(ModItems.tab);
    }

    @Override
    public int getRenderType() {
        return 0;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerBlockIcons(IIconRegister r) {
        iconFront = r.registerIcon("pcmod:" + kind + tier + "_front");
        iconSide = r.registerIcon("pcmod:" + kind + tier + "_side");
    }

    @Override
    @SideOnly(Side.CLIENT)
    public IIcon getIcon(int side, int meta) {
        if (side == 0 || side == 1) return iconSide;
        if (meta == 0) meta = 3;
        return side == meta ? iconFront : iconSide;
    }

    @Override
    public void onBlockPlacedBy(World w, int x, int y, int z, EntityLivingBase p, ItemStack s) {
        int l = MathHelper.floor_double(p.rotationYaw * 4.0F / 360.0F + 0.5D) & 3;
        int meta = l == 0 ? 2 : l == 1 ? 5 : l == 2 ? 3 : 4;
        w.setBlockMetadataWithNotify(x, y, z, meta, 2);
    }

    @Override
    public boolean onBlockActivated(World w, int x, int y, int z, EntityPlayer p, int side, float hx, float hy, float hz) {
        if (!w.isRemote) p.openGui(PCMod.instance, gui, w, x, y, z);
        return true;
    }
}
