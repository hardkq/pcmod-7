package ru.pcmod.common;

import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

/** Сервер: ставится вплотную к кабелю или роутеру, ПКМ открывает настройки (домен) и отсеки под HDD. */
public class BlockServer extends BlockNetDevice {
    public BlockServer(int tier) {
        super("server", tier, GuiHandler.SERVER);
    }

    @Override
    public TileEntity createNewTileEntity(World world, int meta) {
        return new TileServer();
    }

    /** При разрушении сервера диски из отсеков выпадают. */
    @Override
    public void breakBlock(World w, int x, int y, int z, Block block, int meta) {
        TileEntity te = w.getTileEntity(x, y, z);
        if (te instanceof TileServer && !w.isRemote) {
            TileServer s = (TileServer) te;
            for (int i = 0; i < s.getSizeInventory(); i++) {
                ItemStack st = s.takeDriveSilently(i);
                if (st != null) w.spawnEntityInWorld(new EntityItem(w, x + 0.5, y + 0.5, z + 0.5, st));
            }
        }
        super.breakBlock(w, x, y, z, block, meta);
    }
}
