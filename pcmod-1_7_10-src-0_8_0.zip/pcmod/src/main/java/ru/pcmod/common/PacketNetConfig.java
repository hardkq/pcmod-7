package ru.pcmod.common;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;

/**
 * Клиент -> сервер: настройки роутера или сервера из GUI.
 * flags: 1 = Wi-Fi включён, 2 = убрать пароль, 4 = стереть данные чата (только сервер).
 * Роутер: a = SSID, b = новый пароль (пусто = не менять). Сервер: a = домен.
 */
public class PacketNetConfig implements IMessage {
    public int x, y, z, flags;
    public String a = "", b = "";

    public PacketNetConfig() { }

    public PacketNetConfig(int x, int y, int z, int flags, String a, String b) {
        this.x = x; this.y = y; this.z = z; this.flags = flags; this.a = a; this.b = b;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        x = buf.readInt(); y = buf.readInt(); z = buf.readInt(); flags = buf.readInt();
        a = ByteBufUtils.readUTF8String(buf);
        b = ByteBufUtils.readUTF8String(buf);
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(x); buf.writeInt(y); buf.writeInt(z); buf.writeInt(flags);
        ByteBufUtils.writeUTF8String(buf, a);
        ByteBufUtils.writeUTF8String(buf, b);
    }

    private static final ConcurrentLinkedQueue<Object[]> QUEUE = new ConcurrentLinkedQueue<Object[]>();

    public static class Handler implements IMessageHandler<PacketNetConfig, IMessage> {
        @Override
        public IMessage onMessage(PacketNetConfig m, MessageContext ctx) {
            QUEUE.add(new Object[]{ctx.getServerHandler().playerEntity, m});
            return null;
        }
    }

    /** Вызывается каждый серверный тик (в основном потоке). */
    public static void drain() {
        Object[] o;
        while ((o = QUEUE.poll()) != null) {
            EntityPlayerMP p = (EntityPlayerMP) o[0];
            PacketNetConfig m = (PacketNetConfig) o[1];
            if (!(p.openContainer instanceof ContainerBlank)) continue;
            ContainerBlank cb = (ContainerBlank) p.openContainer;
            TileEntity te = cb.tile;
            if (te.xCoord != m.x || te.yCoord != m.y || te.zCoord != m.z || !cb.canInteractWith(p)) continue;
            String err = null;
            String ok = null;
            if (te instanceof TileRouter) {
                TileRouter r = (TileRouter) te;
                err = r.applyConfig(m.a.trim(), m.b, (m.flags & 1) != 0, (m.flags & 2) != 0);
                ok = "Router saved: " + r.ssid + (r.pass.length() > 0 ? " (password set)" : " (open network)")
                        + (r.wifiOn ? ", Wi-Fi on" : ", Wi-Fi off");
            } else if (te instanceof TileServer) {
                TileServer s = (TileServer) te;
                err = s.applyConfig(m.a.trim(), (m.flags & 4) != 0);
                ok = "Server saved: " + s.domain + ((m.flags & 4) != 0 ? " (chat data wiped)" : "");
            }
            if (ok != null) p.addChatMessage(new ChatComponentText(err != null ? err : ok));
        }
    }
}
