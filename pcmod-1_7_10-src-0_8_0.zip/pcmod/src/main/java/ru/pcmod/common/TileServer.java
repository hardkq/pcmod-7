package ru.pcmod.common;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;

/**
 * Сервер сети: имя (домен) и чат-сервис (аккаунты, история сообщений).
 * Объём не фиксирован: базовый минимум + каждый HDD в отсеке добавляет аккаунты и сообщения.
 */
public class TileServer extends TileEntity implements IInventory {
    /** Всего ячеек в инвентаре; активных отсеков: S1 = 4, S2 = 8. */
    public static final int MAX_BAYS = 8;
    /** Жёсткие потолки, чтобы файл мира не раздувался. */
    public static final int HARD_MAX_ACC = 512, HARD_MAX_MSG = 5000;

    public String domain = "";
    private final ItemStack[] drives = new ItemStack[MAX_BAYS];
    /** Для GUI на клиенте. */
    public int cAcc, cMsg;
    private final ChatStore store = new ChatStore();

    public int tier() {
        if (worldObj == null) return 0;
        Block b = getBlockType();
        return b instanceof BlockNetDevice ? ((BlockNetDevice) b).tier : 0;
    }

    public int bays() {
        return tier() == 0 ? 4 : 8;
    }

    /** Аккаунтов и сообщений на каждый КБ диска. */
    public static int accountsFor(int kb) {
        return kb / 4;
    }

    public static int msgsFor(int kb) {
        return kb * 4;
    }

    public static boolean isDrive(ItemStack s) {
        return s != null && s.getItem() instanceof ItemPart && ((ItemPart) s.getItem()).spec.hdd;
    }

    /** Суммарная ёмкость установленных дисков (КБ), без диска в слоте skip (-1 = учитывать все). */
    public int driveKB(int skip) {
        int kb = 0, n = bays();
        for (int i = 0; i < n; i++) {
            if (i != skip && isDrive(drives[i])) kb += ((ItemPart) drives[i].getItem()).spec.storageKB;
        }
        return kb;
    }

    public int driveCount() {
        int c = 0, n = bays();
        for (int i = 0; i < n; i++) if (isDrive(drives[i])) c++;
        return c;
    }

    /** Встроенный минимум (как в версиях до отсеков), чтобы старые серверы не потеряли данные. */
    private int baseAccounts() {
        return tier() == 0 ? 8 : 32;
    }

    private int baseMsgs() {
        return tier() == 0 ? 100 : 300;
    }

    private int accCap(int skip) {
        return Math.min(HARD_MAX_ACC, baseAccounts() + accountsFor(driveKB(skip)));
    }

    public int maxAccounts() {
        return accCap(-1);
    }

    public int maxMsgs() {
        return Math.min(HARD_MAX_MSG, baseMsgs() + msgsFor(driveKB(-1)));
    }

    /** Нельзя вынуть диск, если без него аккаунтов окажется больше, чем влезает. История сообщений просто обрезается. */
    public boolean canRemoveDrive(int slot) {
        if (worldObj == null || worldObj.isRemote) return true;
        if (drives[slot] == null) return true;
        return store.accounts.size() <= accCap(slot);
    }

    private void drivesChanged() {
        markDirty();
        if (worldObj != null && !worldObj.isRemote) {
            int max = maxMsgs();
            while (store.msgs.size() > max) store.msgs.remove(0);
            worldObj.markBlockForUpdate(xCoord, yCoord, zCoord);
        }
    }

    /** Отправить клиенту актуальные счётчики (при открытии GUI). */
    public void syncClient() {
        if (worldObj != null && !worldObj.isRemote) worldObj.markBlockForUpdate(xCoord, yCoord, zCoord);
    }

    /** Для выпадения предметов при разрушении блока: забирает диск без уведомлений. */
    public ItemStack takeDriveSilently(int i) {
        ItemStack s = drives[i];
        drives[i] = null;
        return s;
    }

    // ---------- IInventory (отсеки для HDD) ----------
    @Override
    public int getSizeInventory() {
        return MAX_BAYS;
    }

    @Override
    public ItemStack getStackInSlot(int i) {
        return drives[i];
    }

    @Override
    public ItemStack decrStackSize(int i, int n) {
        ItemStack s = drives[i];
        if (s == null) return null;
        ItemStack r;
        if (s.stackSize <= n) {
            r = s;
            drives[i] = null;
        } else {
            r = s.splitStack(n);
            if (s.stackSize == 0) drives[i] = null;
        }
        drivesChanged();
        return r;
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int i) {
        return null;
    }

    @Override
    public void setInventorySlotContents(int i, ItemStack s) {
        if (s != null && s.stackSize > 1) s.stackSize = 1;
        drives[i] = s;
        drivesChanged();
    }

    @Override
    public String getInventoryName() {
        return "container.pcmod.server";
    }

    @Override
    public boolean hasCustomInventoryName() {
        return false;
    }

    @Override
    public int getInventoryStackLimit() {
        return 1;
    }

    @Override
    public boolean isUseableByPlayer(EntityPlayer p) {
        return worldObj != null && worldObj.getTileEntity(xCoord, yCoord, zCoord) == this
                && p.getDistanceSq(xCoord + 0.5, yCoord + 0.5, zCoord + 0.5) <= 64;
    }

    @Override
    public void openInventory() {
    }

    @Override
    public void closeInventory() {
    }

    @Override
    public boolean isItemValidForSlot(int i, ItemStack s) {
        return i >= 0 && i < bays() && isDrive(s);
    }

    public ChatStore store() {
        store.maxAccounts = maxAccounts();
        store.maxMsgs = maxMsgs();
        return store;
    }

    long now() {
        return worldObj.getTotalWorldTime();
    }

    long day() {
        return worldObj.getWorldTime();
    }

    public String register(String nick, String hash) {
        String e = store().register(nick, hash, now());
        if (e == null) markDirty();
        return e;
    }

    public String login(String nick, String hash) {
        return store().login(nick, hash, now());
    }

    public String send(String nick, String hash, String to, String text) {
        String e = store().send(nick, hash, to, text, now(), day());
        if (e == null) markDirty();
        return e;
    }

    @Override
    public boolean canUpdate() {
        return false;
    }

    @Override
    public void validate() {
        super.validate();
        if (worldObj != null && !worldObj.isRemote && domain.length() == 0) {
            domain = "chat" + Integer.toHexString((xCoord * 31 + yCoord * 7 + zCoord * 17) & 0xFFFF) + ".net";
        }
    }

    /** null = применено, иначе текст ошибки. */
    public String applyConfig(String newDomain, boolean wipe) {
        if (!Net.validDomain(newDomain)) return "Domain: 1-20 chars (a-z, 0-9, ., -)";
        domain = newDomain;
        if (wipe) store.wipe();
        markDirty();
        if (worldObj != null) worldObj.markBlockForUpdate(xCoord, yCoord, zCoord);
        return null;
    }

    @Override
    public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag);
        domain = tag.getString("domain");
        store.accounts.clear();
        store.msgs.clear();
        NBTTagList acc = tag.getTagList("accounts", 10);
        for (int i = 0; i < acc.tagCount(); i++) {
            NBTTagCompound c = acc.getCompoundTagAt(i);
            ChatStore.Account a = new ChatStore.Account();
            a.nick = c.getString("n");
            a.hash = c.getString("h");
            a.seen = c.getLong("s");
            store.accounts.add(a);
        }
        NBTTagList ms = tag.getTagList("msgs", 10);
        for (int i = 0; i < ms.tagCount(); i++) {
            NBTTagCompound c = ms.getCompoundTagAt(i);
            ChatStore.Msg m = new ChatStore.Msg();
            m.id = c.getInteger("id");
            m.from = c.getString("f");
            m.to = c.getString("t");
            m.text = c.getString("x");
            m.time = c.getLong("ts");
            store.msgs.add(m);
        }
        for (int i = 0; i < MAX_BAYS; i++) drives[i] = null;
        NBTTagList dl = tag.getTagList("drives", 10);
        for (int i = 0; i < dl.tagCount(); i++) {
            NBTTagCompound c = dl.getCompoundTagAt(i);
            int slot = c.getByte("Slot") & 255;
            if (slot < MAX_BAYS) drives[slot] = ItemStack.loadItemStackFromNBT(c);
        }
        store.nextId = Math.max(1, tag.getInteger("nextId"));
        for (ChatStore.Msg m : store.msgs) store.nextId = Math.max(store.nextId, m.id + 1);
    }

    @Override
    public void writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag);
        tag.setString("domain", domain);
        NBTTagList acc = new NBTTagList();
        for (ChatStore.Account a : store.accounts) {
            NBTTagCompound c = new NBTTagCompound();
            c.setString("n", a.nick);
            c.setString("h", a.hash);
            c.setLong("s", a.seen);
            acc.appendTag(c);
        }
        tag.setTag("accounts", acc);
        NBTTagList ms = new NBTTagList();
        for (ChatStore.Msg m : store.msgs) {
            NBTTagCompound c = new NBTTagCompound();
            c.setInteger("id", m.id);
            c.setString("f", m.from);
            c.setString("t", m.to);
            c.setString("x", m.text);
            c.setLong("ts", m.time);
            ms.appendTag(c);
        }
        tag.setTag("msgs", ms);
        NBTTagList dl = new NBTTagList();
        for (int i = 0; i < MAX_BAYS; i++) {
            if (drives[i] == null) continue;
            NBTTagCompound c = new NBTTagCompound();
            c.setByte("Slot", (byte) i);
            drives[i].writeToNBT(c);
            dl.appendTag(c);
        }
        tag.setTag("drives", dl);
        tag.setInteger("nextId", store.nextId);
    }

    @Override
    public Packet getDescriptionPacket() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setString("domain", domain);
        tag.setInteger("acc", store.accounts.size());
        tag.setInteger("msg", store.msgs.size());
        return new S35PacketUpdateTileEntity(xCoord, yCoord, zCoord, 0, tag);
    }

    @Override
    public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt) {
        NBTTagCompound tag = pkt.func_148857_g();
        domain = tag.getString("domain");
        cAcc = tag.getInteger("acc");
        cMsg = tag.getInteger("msg");
    }
}
