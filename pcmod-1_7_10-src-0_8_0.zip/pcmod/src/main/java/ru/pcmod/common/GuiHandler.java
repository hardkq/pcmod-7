package ru.pcmod.common;

import cpw.mods.fml.common.network.IGuiHandler;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import ru.pcmod.client.GuiHardware;
import ru.pcmod.client.GuiMiner;
import ru.pcmod.client.GuiMonitor;
import ru.pcmod.client.GuiNetDevice;

public class GuiHandler implements IGuiHandler {
    public static final int HW = 0, MONITOR = 1, ROUTER = 2, SERVER = 3, MINER = 4;

    @Override
    public Object getServerGuiElement(int id, EntityPlayer p, World w, int x, int y, int z) {
        TileEntity te = w.getTileEntity(x, y, z);
        if (id == ROUTER) return te instanceof TileRouter ? new ContainerBlank(te) : null;
        if (id == SERVER) {
            if (!(te instanceof TileServer)) return null;
            ((TileServer) te).syncClient();
            return new ContainerServer(p.inventory, (TileServer) te);
        }
        if (id == MINER) return te instanceof TileMiner ? new ContainerMiner(p.inventory, (TileMiner) te) : null;
        if (!(te instanceof TileComputer)) return null;
        TileComputer c = (TileComputer) te;
        c.screen.dirty = true;
        return id == HW ? new ContainerComputer(p.inventory, c) : new ContainerScreen(c);
    }

    @Override
    public Object getClientGuiElement(int id, EntityPlayer p, World w, int x, int y, int z) {
        TileEntity te = w.getTileEntity(x, y, z);
        if (id == ROUTER) return te instanceof TileRouter ? new GuiNetDevice(new ContainerBlank(te), te) : null;
        if (id == SERVER) {
            return te instanceof TileServer
                    ? new GuiNetDevice(new ContainerServer(p.inventory, (TileServer) te), te) : null;
        }
        if (id == MINER) {
            return te instanceof TileMiner
                    ? new GuiMiner(new ContainerMiner(p.inventory, (TileMiner) te), (TileMiner) te) : null;
        }
        if (!(te instanceof TileComputer)) return null;
        TileComputer c = (TileComputer) te;
        if (id == HW) return new GuiHardware(new ContainerComputer(p.inventory, c), c);
        return new GuiMonitor(new ContainerScreen(c), c);
    }
}
