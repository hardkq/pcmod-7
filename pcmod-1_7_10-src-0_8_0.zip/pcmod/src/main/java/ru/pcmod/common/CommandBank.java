package ru.pcmod.common;

import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;

/**
 * Команды операторов:
 * /pcbank balance|give|take|set &lt;игрок&gt; [сумма]   - счета игроков (онлайн)
 * /pcshop reload|refresh|status                     - каталог магазина
 */
public class CommandBank extends CommandBase {
    private final boolean shop;

    public CommandBank(boolean shop) {
        this.shop = shop;
    }

    @Override
    public String getCommandName() {
        return shop ? "pcshop" : "pcbank";
    }

    @Override
    public String getCommandUsage(ICommandSender s) {
        return shop ? "/pcshop <reload|refresh|status>" : "/pcbank <balance|give|take|set> <player> [amount]";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    private static void say(ICommandSender s, String t) {
        s.addChatMessage(new ChatComponentText(t));
    }

    private static EntityPlayer find(String name) {
        List<?> all = MinecraftServer.getServer().getConfigurationManager().playerEntityList;
        for (Object o : all) {
            if (o instanceof EntityPlayer && ((EntityPlayer) o).getCommandSenderName().equalsIgnoreCase(name)) {
                return (EntityPlayer) o;
            }
        }
        return null;
    }

    @Override
    public void processCommand(ICommandSender s, String[] a) {
        if (shop) {
            shopCmd(s, a);
            return;
        }
        if (a.length < 2) {
            say(s, getCommandUsage(s));
            return;
        }
        Bank b = Bank.get();
        EntityPlayer p = find(a[1]);
        if (b == null || p == null) {
            say(s, "Player not found (must be online): " + a[1]);
            return;
        }
        String id = p.getUniqueID().toString();
        b.rename(id, p.getCommandSenderName());
        String op = a[0];
        if (op.equals("balance")) {
            say(s, p.getCommandSenderName() + ": " + Bank.fmt(b.balance(id)));
            return;
        }
        long v;
        try {
            v = a.length >= 3 ? Long.parseLong(a[2]) : -1L;
        } catch (NumberFormatException e) {
            v = -1L;
        }
        if (v < 0) {
            say(s, "Amount must be a number >= 0");
            return;
        }
        if (op.equals("give")) {
            b.setBalance(id, b.balance(id) + v);
            b.log(id, "+" + Bank.fmt(v) + " admin");
        } else if (op.equals("take")) {
            b.setBalance(id, b.balance(id) - v);
            b.log(id, "-" + Bank.fmt(v) + " admin");
        } else if (op.equals("set")) {
            b.setBalance(id, v);
            b.log(id, "= " + Bank.fmt(v) + " admin");
        } else {
            say(s, getCommandUsage(s));
            return;
        }
        say(s, p.getCommandSenderName() + ": " + Bank.fmt(b.balance(id)));
    }

    private void shopCmd(ICommandSender s, String[] a) {
        String op = a.length > 0 ? a[0] : "status";
        if (op.equals("reload")) {
            Shop.load();
            say(s, "Shop config reloaded: " + Shop.poolSize() + " offers in the pool");
        } else if (op.equals("refresh")) {
            Shop.reroll();
            say(s, "Catalog refreshed, purchase limits reset");
        } else if (op.equals("status")) {
            say(s, "Pool: " + Shop.poolSize() + ", catalog: " + Shop.catalog().size()
                    + " offers, next change in " + Shop.secondsLeft() + " s");
        } else {
            say(s, getCommandUsage(s));
        }
    }
}
