package ru.pcmod.common;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;

/** Пустой контейнер: нужен, чтобы FML открыл GUI монитора. */
public class ContainerScreen extends Container {
    public final TileComputer tile;

    public ContainerScreen(TileComputer t) {
        this.tile = t;
    }

    @Override
    public boolean canInteractWith(EntityPlayer p) {
        return tile.isUseableByPlayer(p);
    }
}
