package ru.pcmod.common;

import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import ru.pcmod.common.PartSpec.Cat;

public class ModItems {
    public static CreativeTabs tab;
    public static Item circuit,
            mbBasic, mbPlus, mbMid, mbPro, mbElite,
            cpuSolo, cpuDual, cpuTri, cpuQuad, cpuHexa, cpuOcta, cpuDeca, cpuDodeca,
            coolStock, coolTower, coolLiquid,
            ramD3a, ramD3b, ramD3c, ramD4z, ramD4a, ramD4b, ramD4c, ramD5a, ramD5b, ramD5c,
            gpu1, gpu300, gpu2, gpu700, gpu3, gpu1200, gpu2000,
            hdd250, hdd, hdd1000, hdd2000, hdd4000, hdd8000, ssd, nvme,
            psu300, psu500, psu750, psu1000, installDisk, installDiskPixel, wifiModule, bill;
    public static Block computer, cable, videoCable;
    public static final Block[] routers = new Block[2];
    public static final Block[] servers = new Block[2];
    public static final Block[] miners = new Block[2];
    public static final Block[] monitors = new Block[MonitorType.ALL.length];

    public static void init() {
        tab = new CreativeTabs("pcmod") {
            @Override
            @SideOnly(Side.CLIENT)
            public Item getTabIconItem() {
                return cpuQuad;
            }
        };

        circuit = new Item();
        circuit.setUnlocalizedName("pcmod.circuit").setTextureName("pcmod:circuit").setCreativeTab(tab);
        GameRegistry.registerItem(circuit, "circuit");

        // ---- материнские платы ----
        mbBasic = part("mb_basic", new PartSpec(Cat.MOTHERBOARD, "PCM-A100").socket(1).ramType(1).ramSlots(2));
        mbPlus = part("mb_plus", new PartSpec(Cat.MOTHERBOARD, "PCM-B200").socket(1).ramType(1).ramSlots(4));
        mbMid = part("mb_mid", new PartSpec(Cat.MOTHERBOARD, "PCM-X300").socket(2).ramType(2).ramSlots(2));
        mbPro = part("mb_pro", new PartSpec(Cat.MOTHERBOARD, "PCM-X500").socket(2).ramType(2).ramSlots(4));
        mbElite = part("mb_elite", new PartSpec(Cat.MOTHERBOARD, "PCM-Z900").socket(3).ramType(3).ramSlots(4));

        // ---- процессоры ----
        cpuSolo = part("cpu_solo", new PartSpec(Cat.CPU, "Solo S1").socket(1).cores(1).ghz(1.6).watts(35));
        cpuDual = part("cpu_dual", new PartSpec(Cat.CPU, "Duo C2").socket(1).cores(2).ghz(2.0).watts(65));
        cpuTri = part("cpu_tri", new PartSpec(Cat.CPU, "Tri T3").socket(1).cores(3).ghz(2.6).watts(80));
        cpuQuad = part("cpu_quad", new PartSpec(Cat.CPU, "Quad Q4").socket(1).cores(4).ghz(3.0).watts(95));
        cpuHexa = part("cpu_hexa", new PartSpec(Cat.CPU, "Hexa X6").socket(2).cores(6).ghz(3.6).watts(105));
        cpuOcta = part("cpu_octa", new PartSpec(Cat.CPU, "Octa X8").socket(2).cores(8).ghz(4.2).watts(125));
        cpuDeca = part("cpu_deca", new PartSpec(Cat.CPU, "Deca Z10").socket(3).cores(10).ghz(4.8).watts(140));
        cpuDodeca = part("cpu_dodeca", new PartSpec(Cat.CPU, "Dodeca Z12").socket(3).cores(12).ghz(5.2).watts(170));

        // ---- кулеры ----
        coolStock = part("cooler_stock", new PartSpec(Cat.COOLER, "Stock Cooler").cooling(70));
        coolTower = part("cooler_tower", new PartSpec(Cat.COOLER, "Tower Cooler").cooling(160));
        coolLiquid = part("cooler_liquid", new PartSpec(Cat.COOLER, "Liquid Cooler").cooling(260));

        // ---- оперативная память ----
        ramD3a = part("ram_d3_1", new PartSpec(Cat.RAM, "DDR3 1 GB").ramType(1).memMB(1024));
        ramD3b = part("ram_d3_2", new PartSpec(Cat.RAM, "DDR3 2 GB").ramType(1).memMB(2048));
        ramD3c = part("ram_d3_4", new PartSpec(Cat.RAM, "DDR3 4 GB").ramType(1).memMB(4096));
        ramD4z = part("ram_d4_2", new PartSpec(Cat.RAM, "DDR4 2 GB").ramType(2).memMB(2048));
        ramD4a = part("ram_d4_4", new PartSpec(Cat.RAM, "DDR4 4 GB").ramType(2).memMB(4096));
        ramD4b = part("ram_d4_8", new PartSpec(Cat.RAM, "DDR4 8 GB").ramType(2).memMB(8192));
        ramD4c = part("ram_d4_16", new PartSpec(Cat.RAM, "DDR4 16 GB").ramType(2).memMB(16384));
        ramD5a = part("ram_d5_8", new PartSpec(Cat.RAM, "DDR5 8 GB").ramType(3).memMB(8192));
        ramD5b = part("ram_d5_16", new PartSpec(Cat.RAM, "DDR5 16 GB").ramType(3).memMB(16384));
        ramD5c = part("ram_d5_32", new PartSpec(Cat.RAM, "DDR5 32 GB").ramType(3).memMB(32768));

        // ---- видеокарты ----
        gpu1 = part("gpu_1", new PartSpec(Cat.GPU, "GT-100").tier(1).vram(256).watts(40).hash(2));
        gpu300 = part("gpu_300", new PartSpec(Cat.GPU, "GT-300").tier(2).vram(512).watts(60).hash(6));
        gpu2 = part("gpu_2", new PartSpec(Cat.GPU, "GT-500").tier(2).vram(1024).watts(90).hash(12));
        gpu700 = part("gpu_700", new PartSpec(Cat.GPU, "GT-700").tier(3).vram(2048).watts(120).hash(24));
        gpu3 = part("gpu_3", new PartSpec(Cat.GPU, "GT-900").tier(3).vram(4096).watts(160).hash(40));
        gpu1200 = part("gpu_1200", new PartSpec(Cat.GPU, "GX-1200").tier(3).vram(8192).watts(220).hash(70));
        gpu2000 = part("gpu_2000", new PartSpec(Cat.GPU, "GX-2000").tier(3).vram(16384).watts(300).hash(120));

        // ---- накопители ----
        // HDD (ставятся и в ПК, и в отсеки серверов). Размеры не меньше 48 КБ, чтобы в любой влезала PCOS (24 КБ).
        hdd250 = part("hdd_250", new PartSpec(Cat.STORAGE, "HDD 250").storageKB(48).speed(1).hdd());
        hdd = part("hdd", new PartSpec(Cat.STORAGE, "HDD 500").storageKB(64).speed(1).hdd());
        hdd1000 = part("hdd_1000", new PartSpec(Cat.STORAGE, "HDD 1000").storageKB(128).speed(1).hdd());
        hdd2000 = part("hdd_2000", new PartSpec(Cat.STORAGE, "HDD 2000").storageKB(256).speed(1).hdd());
        hdd4000 = part("hdd_4000", new PartSpec(Cat.STORAGE, "HDD 4000").storageKB(512).speed(2).hdd());
        hdd8000 = part("hdd_8000", new PartSpec(Cat.STORAGE, "HDD 8000 Enterprise").storageKB(768).speed(2).hdd());
        ssd = part("ssd", new PartSpec(Cat.STORAGE, "SSD 2000").storageKB(256).speed(3));
        nvme = part("nvme", new PartSpec(Cat.STORAGE, "NVMe X").storageKB(1024).speed(6));

        // ---- блоки питания ----
        psu300 = part("psu_300", new PartSpec(Cat.PSU, "PSU 300W").watts(300));
        psu500 = part("psu_500", new PartSpec(Cat.PSU, "PSU 500W").watts(500));
        psu750 = part("psu_750", new PartSpec(Cat.PSU, "PSU 750W").watts(750));
        psu1000 = part("psu_1000", new PartSpec(Cat.PSU, "PSU 1000W").watts(1000));

        installDisk = part("install_disk", new PartSpec(Cat.MEDIA, "PCOS Installer"));
        installDiskPixel = part("install_disk_pixel", new PartSpec(Cat.MEDIA, "PixelOS Installer").os("pixel"));

        // ---- сеть ----
        wifiModule = part("wifi_module", new PartSpec(Cat.NET, "Wi-Fi Module"));

        // ---- деньги: купюры «Конс» ----
        bill = new ItemBill();
        bill.setUnlocalizedName("pcmod.bill").setCreativeTab(tab);
        GameRegistry.registerItem(bill, "bill");

        computer = new BlockComputer();
        GameRegistry.registerBlock(computer, "computer");

        for (int i = 0; i < monitors.length; i++) {
            monitors[i] = new BlockMonitor(i);
            GameRegistry.registerBlock(monitors[i], "monitor" + i);
        }

        cable = new BlockCable();
        GameRegistry.registerBlock(cable, "cable");
        videoCable = new BlockVideoCable();
        GameRegistry.registerBlock(videoCable, "video_cable");
        for (int i = 0; i < routers.length; i++) {
            routers[i] = new BlockRouter(i);
            GameRegistry.registerBlock(routers[i], "router" + i);
            servers[i] = new BlockServer(i);
            GameRegistry.registerBlock(servers[i], "server" + i);
            miners[i] = new BlockMiner(i);
            GameRegistry.registerBlock(miners[i], "miner" + i);
        }
    }

    private static Item part(String name, PartSpec spec) {
        Item i = new ItemPart(spec);
        i.setUnlocalizedName("pcmod." + name).setTextureName("pcmod:" + name).setCreativeTab(tab);
        GameRegistry.registerItem(i, name);
        return i;
    }

    public static void addRecipes() {
        Item iron = Items.iron_ingot, gold = Items.gold_ingot, nug = Items.gold_nugget,
                red = Items.redstone, dia = Items.diamond, qz = Items.quartz, em = Items.emerald;
        Block pane = Blocks.glass_pane;
        ItemStack lapis = new ItemStack(Items.dye, 1, 4);

        GameRegistry.addRecipe(new ItemStack(circuit, 2), "gig", "rqr", "gig",
                'g', nug, 'i', iron, 'r', red, 'q', qz);

        GameRegistry.addRecipe(new ItemStack(computer), "iii", "cgc", "iri",
                'i', iron, 'c', circuit, 'g', pane, 'r', red);

        // ---- материнские платы ----
        GameRegistry.addRecipe(new ItemStack(mbBasic), "rcr", "cic", "rcr", 'r', red, 'c', circuit, 'i', iron);
        GameRegistry.addRecipe(new ItemStack(mbPlus), "rcr", "cMc", "rcr", 'r', red, 'c', circuit, 'M', mbBasic);
        GameRegistry.addRecipe(new ItemStack(mbMid), "gcg", "cMc", "gcg", 'g', gold, 'c', circuit, 'M', mbBasic);
        GameRegistry.addRecipe(new ItemStack(mbPro), "gcg", "cMc", "gdg",
                'g', gold, 'c', circuit, 'M', mbBasic, 'd', dia);
        GameRegistry.addRecipe(new ItemStack(mbElite), "ded", "cMc", "dgd",
                'd', dia, 'e', em, 'c', circuit, 'M', mbPro, 'g', gold);

        // ---- процессоры ----
        GameRegistry.addRecipe(new ItemStack(cpuSolo), "iri", "rcr", "iri", 'i', iron, 'r', red, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(cpuDual), "rgr", "gcg", "rgr", 'r', red, 'g', gold, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(cpuTri), "gcg", "gCg", "rgr", 'r', red, 'g', gold, 'c', circuit, 'C', cpuDual);
        GameRegistry.addRecipe(new ItemStack(cpuQuad), "gdg", "gCg", "gdg", 'g', gold, 'd', dia, 'C', cpuDual);
        GameRegistry.addRecipe(new ItemStack(cpuHexa), "dgd", "gQg", "dgd", 'g', gold, 'd', dia, 'Q', cpuQuad);
        GameRegistry.addRecipe(new ItemStack(cpuOcta), "ded", "dCd", "ded", 'd', dia, 'e', em, 'C', cpuQuad);
        GameRegistry.addRecipe(new ItemStack(cpuDeca), "ded", "eOe", "ded", 'd', dia, 'e', em, 'O', cpuOcta);
        GameRegistry.addRecipe(new ItemStack(cpuDodeca), "bdb", "dDd", "bdb",
                'b', Blocks.diamond_block, 'd', dia, 'D', cpuDeca);

        // ---- кулеры ----
        GameRegistry.addRecipe(new ItemStack(coolStock), "bbb", "brb", "iii", 'b', Blocks.iron_bars, 'r', red, 'i', iron);
        GameRegistry.addRecipe(new ItemStack(coolTower), "bib", "iSi", "bib", 'b', Blocks.iron_bars, 'i', iron, 'S', coolStock);
        GameRegistry.addRecipe(new ItemStack(coolLiquid), "glg", "lTl", "gig",
                'g', pane, 'l', lapis, 'i', iron, 'T', coolTower);

        // ---- оперативная память ----
        GameRegistry.addRecipe(new ItemStack(ramD3a), "rrr", "cnc", 'r', red, 'c', circuit, 'n', nug);
        GameRegistry.addShapelessRecipe(new ItemStack(ramD3b), ramD3a, ramD3a, red);
        GameRegistry.addShapelessRecipe(new ItemStack(ramD3c), ramD3b, ramD3b, red);
        GameRegistry.addRecipe(new ItemStack(ramD4z), "rrr", "cic", 'r', red, 'c', circuit, 'i', iron);
        GameRegistry.addRecipe(new ItemStack(ramD4a), "rrr", "cqc", 'r', red, 'c', circuit, 'q', qz);
        GameRegistry.addShapelessRecipe(new ItemStack(ramD4b), ramD4a, ramD4a, red);
        GameRegistry.addShapelessRecipe(new ItemStack(ramD4c), ramD4b, ramD4b, red);
        GameRegistry.addRecipe(new ItemStack(ramD5a), "rdr", "cqc", 'r', red, 'd', dia, 'c', circuit, 'q', qz);
        GameRegistry.addShapelessRecipe(new ItemStack(ramD5b), ramD5a, ramD5a, red);
        GameRegistry.addShapelessRecipe(new ItemStack(ramD5c), ramD5b, ramD5b, red);

        // ---- видеокарты ----
        GameRegistry.addRecipe(new ItemStack(gpu1), "iri", "rcr", "iii", 'i', iron, 'r', red, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(gpu300), "igi", "rGr", "ccc",
                'i', iron, 'g', gold, 'r', red, 'G', gpu1, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(gpu2), "gdg", "iGi", "ccc", 'g', gold, 'd', dia, 'i', iron, 'G', gpu1, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(gpu700), "gdg", "dGd", "ccc", 'g', gold, 'd', dia, 'G', gpu2, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(gpu3), "ded", "dGd", "ccc", 'd', dia, 'e', em, 'G', gpu2, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(gpu1200), "ded", "eGe", "ccc", 'd', dia, 'e', em, 'G', gpu3, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(gpu2000), "bdb", "dGd", "ccc",
                'b', Blocks.diamond_block, 'd', dia, 'G', gpu1200, 'c', circuit);

        // ---- накопители ----
        GameRegistry.addRecipe(new ItemStack(hdd), "iii", "rcr", "iii", 'i', iron, 'r', red, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(hdd250), "iii", "rcr", 'i', iron, 'r', red, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(hdd1000), "igi", "rHr", "igi", 'i', iron, 'g', gold, 'r', red, 'H', hdd);
        GameRegistry.addRecipe(new ItemStack(hdd2000), "ggg", "cHc", "ggg", 'g', gold, 'c', circuit, 'H', hdd1000);
        GameRegistry.addRecipe(new ItemStack(hdd4000), "dgd", "cHc", "dgd", 'd', dia, 'g', gold, 'c', circuit, 'H', hdd2000);
        GameRegistry.addRecipe(new ItemStack(hdd8000), "ded", "cHc", "ded", 'd', dia, 'e', em, 'c', circuit, 'H', hdd4000);
        GameRegistry.addRecipe(new ItemStack(ssd), "ggg", "rcr", "ggg", 'g', gold, 'r', red, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(nvme), "dgd", "rcr", "dgd", 'd', dia, 'g', gold, 'r', red, 'c', circuit);

        // ---- блоки питания ----
        GameRegistry.addRecipe(new ItemStack(psu300), "iii", "rcr", "igi", 'i', iron, 'r', red, 'c', circuit, 'g', gold);
        GameRegistry.addRecipe(new ItemStack(psu500), "ggg", "iPi", "ggg", 'g', gold, 'i', iron, 'P', psu300);
        GameRegistry.addRecipe(new ItemStack(psu750), "dgd", "gPg", "dgd", 'd', dia, 'g', gold, 'P', psu500);
        GameRegistry.addRecipe(new ItemStack(psu1000), "ded", "gPg", "ded", 'd', dia, 'e', em, 'g', gold, 'P', psu750);

        GameRegistry.addShapelessRecipe(new ItemStack(installDisk), circuit, Items.paper, red, iron);
        GameRegistry.addShapelessRecipe(new ItemStack(installDiskPixel), installDisk, dia, lapis);

        // ---- деньги ----
        GameRegistry.addShapelessRecipe(new ItemStack(bill, 1, 0), Items.paper, nug);
        GameRegistry.addShapelessRecipe(new ItemStack(bill, 1, 2), Items.paper, gold);
        GameRegistry.addShapelessRecipe(new ItemStack(bill, 3, 2), Items.paper, em);
        GameRegistry.addShapelessRecipe(new ItemStack(bill, 1, 3), Items.paper, dia);
        for (int i = 0; i + 1 < Bank.DENOM.length; i++) {
            int n = Bank.DENOM[i + 1] / Bank.DENOM[i];
            Object[] in = new Object[n];
            for (int k = 0; k < n; k++) in[k] = new ItemStack(bill, 1, i);
            GameRegistry.addShapelessRecipe(new ItemStack(bill, 1, i + 1), in);
            GameRegistry.addShapelessRecipe(new ItemStack(bill, n, i), new ItemStack(bill, 1, i + 1));
        }

        // ---- мониторы ----
        GameRegistry.addRecipe(new ItemStack(monitors[0]), "iii", "igi", "iri",
                'i', iron, 'g', pane, 'r', red);
        GameRegistry.addShapelessRecipe(new ItemStack(monitors[1]), monitors[0], Items.glowstone_dust);
        GameRegistry.addShapelessRecipe(new ItemStack(monitors[2]), monitors[0],
                new ItemStack(Items.dye, 1, 1), new ItemStack(Items.dye, 1, 2), new ItemStack(Items.dye, 1, 4));
        GameRegistry.addRecipe(new ItemStack(monitors[3]), "ppp", "pcp", "iri",
                'p', pane, 'c', circuit, 'i', iron, 'r', red);
        GameRegistry.addShapelessRecipe(new ItemStack(monitors[4]), monitors[3], dia, red);

        // ---- сеть: Wi-Fi модуль, кабель, роутеры, серверы ----
        Item pearl = Items.ender_pearl;
        GameRegistry.addRecipe(new ItemStack(wifiModule), " r ", "geg", "ccc",
                'r', red, 'g', gold, 'e', pearl, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(cable, 6), "iii", "rcr",
                'i', iron, 'r', red, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(videoCable, 4), "iii", "gcg",
                'i', iron, 'g', gold, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(routers[0]), "iri", "cwc", "iii",
                'i', iron, 'r', red, 'c', circuit, 'w', wifiModule);
        GameRegistry.addRecipe(new ItemStack(routers[1]), "gdg", "wRw", "ccc",
                'g', gold, 'd', dia, 'w', wifiModule, 'R', routers[0], 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(servers[0]), "iri", "cMc", "ihi",
                'i', iron, 'r', red, 'c', circuit, 'M', mbBasic, 'h', hdd);
        // ---- майнер-фермы ----
        GameRegistry.addRecipe(new ItemStack(miners[0]), "iri", "cKc", "iii",
                'i', iron, 'r', red, 'c', circuit, 'K', cable);
        GameRegistry.addRecipe(new ItemStack(miners[1]), "gdg", "MKM", "ccc",
                'g', gold, 'd', dia, 'M', miners[0], 'K', cable, 'c', circuit);
        GameRegistry.addRecipe(new ItemStack(servers[1]), "gdg", "cSc", "isi",
                'g', gold, 'd', dia, 'c', circuit, 'S', servers[0], 'i', iron, 's', ssd);
    }
}
