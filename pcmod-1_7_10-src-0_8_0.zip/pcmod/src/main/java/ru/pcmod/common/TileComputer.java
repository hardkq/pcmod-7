package ru.pcmod.common;

import cpw.mods.fml.common.network.NetworkRegistry;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
import net.minecraft.util.AxisAlignedBB;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import ru.pcmod.PCMod;
import ru.pcmod.common.PartSpec.Cat;

public class TileComputer extends TileEntity implements IInventory {
    public static final int SLOTS = 12;
    public static final int MB = 0, CPU = 1, COOLER = 2, RAM0 = 3, RAM3 = 6, GPU = 7, STORAGE = 8, PSU = 9, MEDIA = 10, NET = 11;
    public static final Cat[] SLOT_CAT = {
            Cat.MOTHERBOARD, Cat.CPU, Cat.COOLER, Cat.RAM, Cat.RAM, Cat.RAM, Cat.RAM,
            Cat.GPU, Cat.STORAGE, Cat.PSU, Cat.MEDIA, Cat.NET};

    private final ItemStack[] inv = new ItemStack[SLOTS];

    /** 0 = сначала накопитель, 1 = сначала загрузочный носитель. */
    public int bootOrder;
    public boolean fastBoot;
    public final Screen screen = new Screen();
    public double temp = 25;
    private ComputerLogic logic;

    // ================= логика / сеть =================
    @Override
    public void updateEntity() {
        if (worldObj == null || worldObj.isRemote) return;
        if (logic == null) logic = new ComputerLogic(this);
        logic.tick();
        if (screen.dirty && worldObj.getTotalWorldTime() % 2 == 0) {
            screen.dirty = false;
            PCMod.net.sendToAllAround(new PacketScreen(xCoord, yCoord, zCoord, screen),
                    new NetworkRegistry.TargetPoint(worldObj.provider.dimensionId, xCoord + 0.5, yCoord + 0.5, zCoord + 0.5, 24));
        }
    }

    /** Экран и состояние уходят клиенту при загрузке чанка, чтобы монитор и светодиод сразу показывали верное. */
    @Override
    public Packet getDescriptionPacket() {
        NBTTagCompound tag = new NBTTagCompound();
        ByteBuf b = Unpooled.buffer();
        screen.write(b);
        byte[] d = new byte[b.readableBytes()];
        b.readBytes(d);
        tag.setByteArray("scr", d);
        return new S35PacketUpdateTileEntity(xCoord, yCoord, zCoord, 0, tag);
    }

    @Override
    public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt) {
        byte[] d = pkt.func_148857_g().getByteArray("scr");
        if (d.length > 0) screen.read(Unpooled.wrappedBuffer(d));
    }

    /** Корпус рисует экран на соседнем мониторе, поэтому область отрисовки шире блока. */
    @Override
    public AxisAlignedBB getRenderBoundingBox() {
        return AxisAlignedBB.getBoundingBox(xCoord - 1, yCoord - 1, zCoord - 1, xCoord + 2, yCoord + 2, zCoord + 2);
    }

    public boolean isOn() {
        if (worldObj != null && worldObj.isRemote) return screen.on;
        return logic != null && logic.isOn();
    }

    /** Действие от игрока: ПК запоминает, кто сейчас за клавиатурой (для банка и магазина). */
    public void handleAction(EntityPlayer p, int type, char c, int key) {
        if (worldObj == null || worldObj.isRemote) return;
        if (logic == null) logic = new ComputerLogic(this);
        logic.setActor(p);
        try {
            handleAction(type, c, key);
        } finally {
            logic.clearActor();
        }
    }

    public void handleAction(int type, char c, int key) {
        if (worldObj == null || worldObj.isRemote) return;
        if (logic == null) logic = new ComputerLogic(this);
        if (type == 0) logic.onKey(c, key);
        else if (type == 1) logic.power();
        else if (type == 2) logic.reset();
        else if (type == 5) logic.onClick(c, key);
    }

    // ================= компоненты и совместимость =================
    public PartSpec spec(int slot) {
        ItemStack s = inv[slot];
        if (s != null && s.getItem() instanceof ItemPart) return ((ItemPart) s.getItem()).spec;
        return null;
    }

    public int totalRamMB() {
        int n = 0;
        for (int i = RAM0; i <= RAM3; i++) {
            PartSpec r = spec(i);
            if (r != null) n += r.memMB;
        }
        return n;
    }

    public int ramCount() {
        int n = 0;
        for (int i = RAM0; i <= RAM3; i++) if (spec(i) != null) n++;
        return n;
    }

    private List<int[]> monCache = new ArrayList<int[]>();
    private long monCacheAt = -1000;

    /** Позиции подключённых мониторов (вплотную или через видеокабели до 3 блоков); пересчитывается раз в полсекунды. */
    public List<int[]> monitors() {
        if (worldObj == null) return monCache;
        long now = worldObj.getTotalWorldTime();
        if (now - monCacheAt >= 10L || now < monCacheAt) {
            monCacheAt = now;
            monCache = VideoLink.monitorsOf(worldObj, xCoord, yCoord, zCoord);
        }
        return monCache;
    }

    /** Тип подключённого монитора (ближайшего) или -1, если монитора нет. */
    public int monitorType() {
        if (worldObj == null) return -1;
        for (int[] p : monitors()) {
            if (!worldObj.blockExists(p[0], p[1], p[2])) continue;
            Block b = worldObj.getBlock(p[0], p[1], p[2]);
            if (b instanceof BlockMonitor) return ((BlockMonitor) b).type;
        }
        return -1;
    }

    public int gpuTier() {
        PartSpec g = spec(GPU);
        return g == null ? 0 : g.tier;
    }

    public int requiredWatts() {
        PartSpec cpu = spec(CPU), gpu = spec(GPU);
        return 30 + (cpu == null ? 0 : cpu.watts) + (gpu == null ? 0 : gpu.watts) + 3 * ramCount()
                + (spec(STORAGE) == null ? 0 : 5);
    }

    /** Критические проблемы: с ними ПК не включится. */
    public List<String> errors() {
        List<String> e = new ArrayList<String>();
        PartSpec mb = spec(MB), cpu = spec(CPU), gpu = spec(GPU), psu = spec(PSU);
        if (mb == null) e.add("No motherboard");
        if (cpu == null) e.add("No CPU");
        else if (mb != null && cpu.socket != mb.socket)
            e.add("CPU " + PartSpec.socketName(cpu.socket) + " does not fit board " + PartSpec.socketName(mb.socket));
        int cnt = 0;
        for (int i = RAM0; i <= RAM3; i++) {
            PartSpec r = spec(i);
            if (r == null) continue;
            cnt++;
            if (mb != null) {
                if (r.ramType != mb.ramType)
                    e.add("RAM" + (i - RAM0 + 1) + " is " + PartSpec.ramName(r.ramType) + ", board needs " + PartSpec.ramName(mb.ramType));
                if (i - RAM0 >= mb.ramSlots)
                    e.add("Board has only " + mb.ramSlots + " RAM slots (RAM" + (i - RAM0 + 1) + ")");
            }
        }
        if (cnt == 0) e.add("No RAM");
        if (gpu == null) e.add("No GPU (no video output)");
        if (psu == null) e.add("No PSU");
        else if (psu.watts < requiredWatts()) e.add("PSU too weak: " + psu.watts + " W < " + requiredWatts() + " W");
        return e;
    }

    public List<String> warnings() {
        List<String> w = new ArrayList<String>();
        PartSpec cpu = spec(CPU), cool = spec(COOLER);
        if (cpu != null) {
            if (cool == null) w.add("No cooler: CPU will overheat");
            else if (25 + cpu.watts * 45.0 / cool.cooling >= 95) w.add("Cooler too weak for this CPU");
        }
        if (spec(STORAGE) == null) w.add("No storage drive");
        if (monitorType() < 0) w.add("No monitor connected (next to the case or via video cable)");
        return w;
    }

    // ================= NBT =================
    @Override
    public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag);
        NBTTagList list = tag.getTagList("Items", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound c = list.getCompoundTagAt(i);
            int slot = c.getByte("Slot");
            if (slot >= 0 && slot < SLOTS) inv[slot] = ItemStack.loadItemStackFromNBT(c);
        }
        bootOrder = tag.getInteger("bootOrder");
        fastBoot = tag.getBoolean("fastBoot");
    }

    @Override
    public void writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag);
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < SLOTS; i++) {
            if (inv[i] != null) {
                NBTTagCompound c = new NBTTagCompound();
                c.setByte("Slot", (byte) i);
                inv[i].writeToNBT(c);
                list.appendTag(c);
            }
        }
        tag.setTag("Items", list);
        tag.setInteger("bootOrder", bootOrder);
        tag.setBoolean("fastBoot", fastBoot);
    }

    // ================= IInventory =================
    @Override public int getSizeInventory() { return SLOTS; }
    @Override public ItemStack getStackInSlot(int i) { return inv[i]; }

    @Override
    public ItemStack decrStackSize(int i, int n) {
        if (inv[i] == null) return null;
        ItemStack r;
        if (inv[i].stackSize <= n) {
            r = inv[i];
            inv[i] = null;
        } else {
            r = inv[i].splitStack(n);
            if (inv[i].stackSize == 0) inv[i] = null;
        }
        markDirty();
        return r;
    }

    @Override
    public ItemStack getStackInSlotOnClosing(int i) {
        ItemStack s = inv[i];
        inv[i] = null;
        return s;
    }

    @Override
    public void setInventorySlotContents(int i, ItemStack s) {
        inv[i] = s;
        if (s != null && s.stackSize > 1) s.stackSize = 1;
        markDirty();
    }

    @Override public String getInventoryName() { return "container.pcmod.computer"; }
    @Override public boolean hasCustomInventoryName() { return false; }
    @Override public int getInventoryStackLimit() { return 1; }

    @Override
    public boolean isUseableByPlayer(EntityPlayer p) {
        return worldObj.getTileEntity(xCoord, yCoord, zCoord) == this
                && p.getDistanceSq(xCoord + 0.5, yCoord + 0.5, zCoord + 0.5) <= 64;
    }

    @Override public void openInventory() { }
    @Override public void closeInventory() { }

    @Override
    public boolean isItemValidForSlot(int i, ItemStack s) {
        return s != null && s.getItem() instanceof ItemPart && ((ItemPart) s.getItem()).spec.cat == SLOT_CAT[i];
    }
}
