package ru.pcmod.common;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import ru.pcmod.PCMod;

/** Сервер -> клиент: содержимое экрана. */
public class PacketScreen implements IMessage {
    public int x, y, z;
    public byte[] data;

    public PacketScreen() { }

    public PacketScreen(int x, int y, int z, Screen s) {
        this.x = x; this.y = y; this.z = z;
        ByteBuf b = Unpooled.buffer();
        s.write(b);
        data = new byte[b.readableBytes()];
        b.readBytes(data);
    }

    @Override
    public void fromBytes(ByteBuf b) {
        x = b.readInt(); y = b.readInt(); z = b.readInt();
        int n = b.readInt();
        data = new byte[n];
        b.readBytes(data);
    }

    @Override
    public void toBytes(ByteBuf b) {
        b.writeInt(x); b.writeInt(y); b.writeInt(z);
        b.writeInt(data.length);
        b.writeBytes(data);
    }

    public static class Handler implements IMessageHandler<PacketScreen, IMessage> {
        @Override
        public IMessage onMessage(PacketScreen m, MessageContext ctx) {
            World w = PCMod.proxy.clientWorld();
            if (w == null) return null;
            TileEntity te = w.getTileEntity(m.x, m.y, m.z);
            if (te instanceof TileComputer) {
                ((TileComputer) te).screen.read(Unpooled.wrappedBuffer(m.data));
            }
            return null;
        }
    }
}
