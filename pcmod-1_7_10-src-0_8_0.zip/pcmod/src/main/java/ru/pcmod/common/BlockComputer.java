package ru.pcmod.common;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import ru.pcmod.PCMod;

public class BlockComputer extends BlockContainer {
    @SideOnly(Side.CLIENT)
    private IIcon iconFront, iconSide, iconTop;

    public BlockComputer() {
        super(Material.iron);
        setBlockName("pcmod.computer");
        setHardness(3.0F);
        setResistance(10.0F);
        setStepSound(soundTypeMetal);
        setCreativeTab(ModItems.tab);
    }

    @Override
    public TileEntity createNewTileEntity(World world, int meta) {
        return new TileComputer();
    }

    @Override
    public int getRenderType() {
        return 0;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerBlockIcons(IIconRegister r) {
        iconFront = r.registerIcon("pcmod:computer_front");
        iconSide = r.registerIcon("pcmod:computer_side");
        iconTop = r.registerIcon("pcmod:computer_top");
    }

    @Override
    @SideOnly(Side.CLIENT)
    public IIcon getIcon(int side, int meta) {
        if (side == 0 || side == 1) return iconTop;
        if (meta == 0) meta = 3;
        return side == meta ? iconFront : iconSide;
    }

    @Override
    public void onBlockPlacedBy(World w, int x, int y, int z, EntityLivingBase p, ItemStack s) {
        int l = MathHelper.floor_double(p.rotationYaw * 4.0F / 360.0F + 0.5D) & 3;
        int meta = l == 0 ? 2 : l == 1 ? 5 : l == 2 ? 3 : 4;
        w.setBlockMetadataWithNotify(x, y, z, meta, 2);
    }

    @Override
    public boolean onBlockActivated(World w, int x, int y, int z, EntityPlayer p, int side, float hx, float hy, float hz) {
        if (!w.isRemote) {
            ItemStack held = p.getHeldItem();
            boolean part = held != null && held.getItem() instanceof ItemPart;
            if (!part) {
                TileEntity te = w.getTileEntity(x, y, z);
                if (!(te instanceof TileComputer) || ((TileComputer) te).monitorType() < 0) {
                    p.addChatMessage(new ChatComponentText("No monitor connected. Place a monitor next to the PC case or link it with video cables."));
                    return true;
                }
            }
            p.openGui(PCMod.instance, part ? GuiHandler.HW : GuiHandler.MONITOR, w, x, y, z);
        }
        return true;
    }

    @Override
    public void breakBlock(World w, int x, int y, int z, Block b, int meta) {
        TileEntity te = w.getTileEntity(x, y, z);
        if (te instanceof TileComputer && !w.isRemote) {
            TileComputer c = (TileComputer) te;
            for (int i = 0; i < TileComputer.SLOTS; i++) {
                ItemStack s = c.getStackInSlot(i);
                if (s != null) {
                    EntityItem e = new EntityItem(w, x + 0.5, y + 0.5, z + 0.5, s);
                    w.spawnEntityInWorld(e);
                }
            }
        }
        super.breakBlock(w, x, y, z, b, meta);
    }
}
