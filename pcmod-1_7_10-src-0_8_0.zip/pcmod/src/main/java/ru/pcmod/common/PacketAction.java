package ru.pcmod.common;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;
import ru.pcmod.PCMod;

/** Клиент -> сервер. type: 0 клавиша, 1 питание, 2 reset, 3 открыть железо, 4 открыть монитор, 5 клик мыши (c = x, key = y клетки). */
public class PacketAction implements IMessage {
    public int x, y, z, type, key;
    public char c;

    public PacketAction() { }

    public PacketAction(int x, int y, int z, int type, char c, int key) {
        this.x = x; this.y = y; this.z = z; this.type = type; this.c = c; this.key = key;
    }

    @Override
    public void fromBytes(ByteBuf b) {
        x = b.readInt(); y = b.readInt(); z = b.readInt();
        type = b.readByte(); c = b.readChar(); key = b.readInt();
    }

    @Override
    public void toBytes(ByteBuf b) {
        b.writeInt(x); b.writeInt(y); b.writeInt(z);
        b.writeByte(type); b.writeChar(c); b.writeInt(key);
    }

    private static final ConcurrentLinkedQueue<Object[]> QUEUE = new ConcurrentLinkedQueue<Object[]>();

    public static class Handler implements IMessageHandler<PacketAction, IMessage> {
        @Override
        public IMessage onMessage(PacketAction m, MessageContext ctx) {
            // Обрабатываем позже, в основном потоке сервера.
            QUEUE.add(new Object[]{ctx.getServerHandler().playerEntity, m});
            return null;
        }
    }

    /** Вызывается каждый серверный тик. */
    public static void drain() {
        Object[] o;
        while ((o = QUEUE.poll()) != null) {
            EntityPlayerMP p = (EntityPlayerMP) o[0];
            PacketAction m = (PacketAction) o[1];
            World w = p.worldObj;
            if (!w.blockExists(m.x, m.y, m.z)) continue;
            TileEntity te = w.getTileEntity(m.x, m.y, m.z);
            if (!(te instanceof TileComputer)) continue;
            if (p.getDistanceSq(m.x + 0.5, m.y + 0.5, m.z + 0.5) > 64) continue;
            boolean onScreen = p.openContainer instanceof ContainerScreen;
            boolean onHw = p.openContainer instanceof ContainerComputer;
            if (!onScreen && !onHw) continue;
            TileComputer tc = (TileComputer) te;
            switch (m.type) {
                case 0:
                    if (onScreen) tc.handleAction(p, 0, m.c, m.key);
                    break;
                case 5:
                    if (onScreen) tc.handleAction(p, 5, m.c, m.key);
                    break;
                case 1:
                case 2:
                    tc.handleAction(m.type, m.c, m.key);
                    break;
                case 3:
                    p.openGui(PCMod.instance, GuiHandler.HW, w, m.x, m.y, m.z);
                    break;
                case 4:
                    if (tc.monitorType() < 0) {
                        p.addChatMessage(new ChatComponentText("No monitor connected. Place a monitor next to the PC case or link it with video cables."));
                    } else {
                        p.openGui(PCMod.instance, GuiHandler.MONITOR, w, m.x, m.y, m.z);
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
