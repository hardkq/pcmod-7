package ru.pcmod.common;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

/**
 * Сеть мода. Хабы — кабели и роутеры (соседние блоки соединяются в одну сеть).
 * ПК подключается по проводу (кабель или роутер вплотную к корпусу) либо по Wi-Fi
 * (модуль Wi-Fi в ПК + SSID/пароль, сохранённые в ОС на накопителе).
 * Серверы цепляются к хабам вплотную и видны всем ПК этой сети.
 */
public final class Net {
    public static final int OK = 0, OUT = 1, BAD_PASS = 2, NO_MODULE = 3;
    static final int MAX_HUBS = 512;
    /** Направления в порядке сторон блока: низ, верх, север, юг, запад, восток. */
    public static final int[] DX = {0, 0, 0, 0, -1, 1};
    public static final int[] DY = {-1, 1, 0, 0, 0, 0};
    public static final int[] DZ = {0, 0, -1, 1, 0, 0};

    private static final List<TileRouter> ROUTERS = new CopyOnWriteArrayList<TileRouter>();

    private Net() { }

    /** Точка доступа Wi-Fi в зоне действия. */
    public static class Ap {
        public String ssid = "";
        public int signal;
        public boolean secured;
        public TileRouter router;
    }

    // ===================== реестр роутеров =====================
    public static void register(TileRouter r) {
        if (!ROUTERS.contains(r)) ROUTERS.add(r);
    }

    public static void unregister(TileRouter r) {
        ROUTERS.remove(r);
    }

    public static void clear() {
        ROUTERS.clear();
    }

    // ===================== проверка вводимых данных =====================
    public static boolean validSsid(String s) {
        return s != null && s.matches("[A-Za-z0-9_-]{1,16}");
    }

    public static boolean validPass(String s) {
        return s != null && s.matches("[\\x21-\\x7E]{1,16}");
    }

    public static boolean validDomain(String s) {
        return s != null && s.matches("[a-z0-9][a-z0-9.-]{0,19}");
    }

    // ===================== проводная сеть =====================
    static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }

    static boolean isHub(World w, int x, int y, int z) {
        if (y < 0 || y > 255 || !w.blockExists(x, y, z)) return false;
        Block b = w.getBlock(x, y, z);
        return b instanceof BlockCable || b instanceof BlockRouter;
    }

    /** Все хабы, связанные с начальными (поиск в ширину, не больше MAX_HUBS). */
    static List<int[]> bfs(World w, List<int[]> seeds) {
        List<int[]> out = new ArrayList<int[]>();
        HashSet<Long> seen = new HashSet<Long>();
        ArrayDeque<int[]> q = new ArrayDeque<int[]>();
        for (int[] s : seeds) {
            if (seen.add(key(s[0], s[1], s[2]))) {
                q.add(s);
                out.add(s);
            }
        }
        while (!q.isEmpty() && out.size() < MAX_HUBS) {
            int[] c = q.poll();
            for (int d = 0; d < 6; d++) {
                int x = c[0] + DX[d], y = c[1] + DY[d], z = c[2] + DZ[d];
                if (!isHub(w, x, y, z)) continue;
                if (!seen.add(key(x, y, z))) continue;
                int[] n = {x, y, z};
                q.add(n);
                out.add(n);
            }
        }
        return out;
    }

    static List<int[]> hubsAroundPc(World w, TileComputer pc) {
        List<int[]> seeds = new ArrayList<int[]>();
        for (int d = 0; d < 6; d++) {
            int x = pc.xCoord + DX[d], y = pc.yCoord + DY[d], z = pc.zCoord + DZ[d];
            if (isHub(w, x, y, z)) seeds.add(new int[]{x, y, z});
        }
        return seeds.isEmpty() ? seeds : bfs(w, seeds);
    }

    static List<int[]> hubsOfRouter(World w, TileRouter r) {
        List<int[]> seeds = new ArrayList<int[]>();
        seeds.add(new int[]{r.xCoord, r.yCoord, r.zCoord});
        return bfs(w, seeds);
    }

    static TileRouter firstRouter(World w, List<int[]> hubs) {
        for (int[] h : hubs) {
            TileEntity te = w.getTileEntity(h[0], h[1], h[2]);
            if (te instanceof TileRouter && !te.isInvalid()) return (TileRouter) te;
        }
        return null;
    }

    /** Подключён ли блок (например, майнер-ферма) к сети с роутером: сосед-хаб и роутер в той же сети. */
    public static boolean onlineAt(World w, int x, int y, int z) {
        List<int[]> seeds = new ArrayList<int[]>();
        for (int d = 0; d < 6; d++) {
            int nx = x + DX[d], ny = y + DY[d], nz = z + DZ[d];
            if (isHub(w, nx, ny, nz)) seeds.add(new int[]{nx, ny, nz});
        }
        if (seeds.isEmpty()) return false;
        return firstRouter(w, bfs(w, seeds)) != null;
    }

    static void collectServers(World w, List<int[]> hubs, List<TileServer> out) {
        for (int[] h : hubs) {
            for (int d = 0; d < 6; d++) {
                int x = h[0] + DX[d], y = h[1] + DY[d], z = h[2] + DZ[d];
                if (y < 0 || y > 255 || !w.blockExists(x, y, z)) continue;
                TileEntity te = w.getTileEntity(x, y, z);
                if (te instanceof TileServer && !te.isInvalid() && !out.contains(te)) out.add((TileServer) te);
            }
        }
    }

    // ===================== Wi-Fi =====================
    static double dist(TileRouter r, TileComputer pc) {
        double dx = r.xCoord - pc.xCoord, dy = r.yCoord - pc.yCoord, dz = r.zCoord - pc.zCoord;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    static boolean inRange(TileRouter r, TileComputer pc) {
        return !r.isInvalid() && r.wifiOn && r.getWorldObj() == pc.getWorldObj() && dist(r, pc) <= r.range();
    }

    static int signal(double d, int range) {
        double q = d / Math.max(1, range);
        return q <= 0.25 ? 4 : q <= 0.5 ? 3 : q <= 0.75 ? 2 : 1;
    }

    /** Сети Wi-Fi в зоне действия (по одной на SSID, самая сильная), сильные первыми. */
    public static List<Ap> scan(TileComputer pc) {
        List<Ap> out = new ArrayList<Ap>();
        if (pc.spec(TileComputer.NET) == null || pc.getWorldObj() == null) return out;
        Map<String, Ap> best = new HashMap<String, Ap>();
        for (TileRouter r : ROUTERS) {
            if (!inRange(r, pc) || r.ssid.length() == 0) continue;
            int sig = signal(dist(r, pc), r.range());
            Ap old = best.get(r.ssid);
            if (old == null || sig > old.signal) {
                Ap a = new Ap();
                a.ssid = r.ssid;
                a.signal = sig;
                a.secured = r.pass.length() > 0;
                a.router = r;
                best.put(r.ssid, a);
            }
        }
        out.addAll(best.values());
        Collections.sort(out, new Comparator<Ap>() {
            @Override
            public int compare(Ap a, Ap b) {
                if (a.signal != b.signal) return b.signal - a.signal;
                return a.ssid.compareTo(b.ssid);
            }
        });
        return out;
    }

    /** Подходящий роутер (ближайший с этим SSID, в зоне действия, пароль совпал) или null. */
    static TileRouter bestRouter(TileComputer pc, String ssid, String pass) {
        TileRouter best = null;
        double bd = 1e18;
        for (TileRouter r : ROUTERS) {
            if (!inRange(r, pc) || !r.ssid.equals(ssid)) continue;
            if (r.pass.length() > 0 && !r.pass.equals(pass)) continue;
            double d = dist(r, pc);
            if (d < bd) {
                bd = d;
                best = r;
            }
        }
        return best;
    }

    /** OK / OUT (сеть не найдена или далеко) / BAD_PASS / NO_MODULE. */
    public static int check(TileComputer pc, String ssid, String pass) {
        if (pc.spec(TileComputer.NET) == null) return NO_MODULE;
        boolean found = false;
        for (TileRouter r : ROUTERS) {
            if (!inRange(r, pc) || !r.ssid.equals(ssid)) continue;
            found = true;
            if (r.pass.length() == 0 || r.pass.equals(pass)) return OK;
        }
        return found ? BAD_PASS : OUT;
    }

    // ===================== итоговое подключение =====================
    /** Считает текущее подключение ПК. root — корень ОС на накопителе (там лежат настройки Wi-Fi). */
    public static NetLink resolve(TileComputer pc, NBTTagCompound root) {
        NetLink k = new NetLink();
        World w = pc.getWorldObj();
        if (w == null) return k;

        // 1) провод имеет приоритет
        List<int[]> hubs = hubsAroundPc(w, pc);
        boolean cable = !hubs.isEmpty();
        if (cable) {
            TileRouter r = firstRouter(w, hubs);
            if (r != null) {
                k.type = NetLink.WIRED;
                k.router = r;
                collectServers(w, hubs, k.servers);
                return k;
            }
            k.status = "Cable has no router";
        }

        // 2) Wi-Fi
        if (pc.spec(TileComputer.NET) == null) {
            if (!cable) k.status = "No cable, no Wi-Fi module";
            return k;
        }
        String ssid = root == null ? "" : root.getString("wifi_ssid");
        String pass = root == null ? "" : root.getString("wifi_pass");
        if (ssid.length() == 0) {
            if (!cable) k.status = "Wi-Fi: not connected";
            return k;
        }
        TileRouter r = bestRouter(pc, ssid, pass);
        if (r == null) {
            int c = check(pc, ssid, pass);
            k.status = c == BAD_PASS ? "Wi-Fi: wrong password" : "Wi-Fi: " + ssid + " out of range";
            return k;
        }
        k.type = NetLink.WIFI;
        k.ssid = ssid;
        k.router = r;
        k.signal = signal(dist(r, pc), r.range());
        collectServers(w, hubsOfRouter(w, r), k.servers);
        return k;
    }
}
