package ru.pcmod;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.event.FMLServerStoppedEvent;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import ru.pcmod.common.CommandBank;
import ru.pcmod.common.CommonProxy;
import ru.pcmod.common.GuiHandler;
import ru.pcmod.common.ModItems;
import ru.pcmod.common.Net;
import ru.pcmod.common.PacketAction;
import ru.pcmod.common.PacketNetConfig;
import ru.pcmod.common.PacketScreen;
import ru.pcmod.common.Shop;
import ru.pcmod.common.TileComputer;
import ru.pcmod.common.TileMiner;
import ru.pcmod.common.TileRouter;
import ru.pcmod.common.TileServer;

@Mod(modid = PCMod.MODID, name = "PC Mod", version = "0.8.0")
public class PCMod {
    public static final String MODID = "pcmod";

    @Mod.Instance(MODID)
    public static PCMod instance;

    @SidedProxy(clientSide = "ru.pcmod.client.ClientProxy", serverSide = "ru.pcmod.common.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper net;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        Shop.setConfigDir(e.getModConfigurationDirectory());
        ModItems.init();
        GameRegistry.registerTileEntity(TileComputer.class, "pcmod_computer");
        GameRegistry.registerTileEntity(TileRouter.class, "pcmod_router");
        GameRegistry.registerTileEntity(TileServer.class, "pcmod_server");
        GameRegistry.registerTileEntity(TileMiner.class, "pcmod_miner");
        net = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        net.registerMessage(PacketAction.Handler.class, PacketAction.class, 0, Side.SERVER);
        net.registerMessage(PacketScreen.Handler.class, PacketScreen.class, 1, Side.CLIENT);
        net.registerMessage(PacketNetConfig.Handler.class, PacketNetConfig.class, 2, Side.SERVER);
        proxy.registerRenderers();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        Net.clear();
        Shop.load();
        e.registerServerCommand(new CommandBank(false));
        e.registerServerCommand(new CommandBank(true));
    }

    @Mod.EventHandler
    public void serverStopped(FMLServerStoppedEvent e) {
        Net.clear();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        NetworkRegistry.INSTANCE.registerGuiHandler(this, new GuiHandler());
        FMLCommonHandler.instance().bus().register(new ServerTicker());
        ModItems.addRecipes();
    }

    public static class ServerTicker {
        @SubscribeEvent
        public void onTick(TickEvent.ServerTickEvent e) {
            if (e.phase == TickEvent.Phase.END) {
                PacketAction.drain();
                PacketNetConfig.drain();
            }
        }
    }
}
