package ru.pcmod.client;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.world.IBlockAccess;
import org.lwjgl.opengl.GL11;
import ru.pcmod.common.BlockWire;

/** Рисует кабель: центральный «узел» и жилы в сторону соединённых соседей. */
@SideOnly(Side.CLIENT)
public class CableRenderer implements ISimpleBlockRenderingHandler {
    private static final double A = 0.375D, B = 0.625D;

    @Override
    public void renderInventoryBlock(Block block, int meta, int modelId, RenderBlocks r) {
        Tessellator t = Tessellator.instance;
        r.setRenderBounds(0.0D, A, A, 1.0D, B, B);
        GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
        t.startDrawingQuads();
        t.setNormal(0.0F, -1.0F, 0.0F);
        r.renderFaceYNeg(block, 0.0D, 0.0D, 0.0D, block.getIcon(0, meta));
        t.draw();
        t.startDrawingQuads();
        t.setNormal(0.0F, 1.0F, 0.0F);
        r.renderFaceYPos(block, 0.0D, 0.0D, 0.0D, block.getIcon(1, meta));
        t.draw();
        t.startDrawingQuads();
        t.setNormal(0.0F, 0.0F, -1.0F);
        r.renderFaceZNeg(block, 0.0D, 0.0D, 0.0D, block.getIcon(2, meta));
        t.draw();
        t.startDrawingQuads();
        t.setNormal(0.0F, 0.0F, 1.0F);
        r.renderFaceZPos(block, 0.0D, 0.0D, 0.0D, block.getIcon(3, meta));
        t.draw();
        t.startDrawingQuads();
        t.setNormal(-1.0F, 0.0F, 0.0F);
        r.renderFaceXNeg(block, 0.0D, 0.0D, 0.0D, block.getIcon(4, meta));
        t.draw();
        t.startDrawingQuads();
        t.setNormal(1.0F, 0.0F, 0.0F);
        r.renderFaceXPos(block, 0.0D, 0.0D, 0.0D, block.getIcon(5, meta));
        t.draw();
        GL11.glTranslatef(0.5F, 0.5F, 0.5F);
        r.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
    }

    @Override
    public boolean renderWorldBlock(IBlockAccess w, int x, int y, int z, Block block, int modelId, RenderBlocks r) {
        BlockWire c = (BlockWire) block;
        r.setRenderBounds(A, A, A, B, B, B);
        r.renderStandardBlock(block, x, y, z);
        if (c.connects(w, x, y, z, 0)) {
            r.setRenderBounds(A, 0.0D, A, B, A, B);
            r.renderStandardBlock(block, x, y, z);
        }
        if (c.connects(w, x, y, z, 1)) {
            r.setRenderBounds(A, B, A, B, 1.0D, B);
            r.renderStandardBlock(block, x, y, z);
        }
        if (c.connects(w, x, y, z, 2)) {
            r.setRenderBounds(A, A, 0.0D, B, B, A);
            r.renderStandardBlock(block, x, y, z);
        }
        if (c.connects(w, x, y, z, 3)) {
            r.setRenderBounds(A, A, B, B, B, 1.0D);
            r.renderStandardBlock(block, x, y, z);
        }
        if (c.connects(w, x, y, z, 4)) {
            r.setRenderBounds(0.0D, A, A, A, B, B);
            r.renderStandardBlock(block, x, y, z);
        }
        if (c.connects(w, x, y, z, 5)) {
            r.setRenderBounds(B, A, A, 1.0D, B, B);
            r.renderStandardBlock(block, x, y, z);
        }
        r.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
        return true;
    }

    @Override
    public boolean shouldRender3DInInventory(int modelId) {
        return true;
    }

    @Override
    public int getRenderId() {
        return BlockWire.renderId;
    }
}
