package ru.pcmod.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Container;
import org.lwjgl.input.Keyboard;
import ru.pcmod.PCMod;
import ru.pcmod.common.MonitorType;
import ru.pcmod.common.PacketAction;
import ru.pcmod.common.Screen;
import ru.pcmod.common.Sprites;
import ru.pcmod.common.TileComputer;

/** Экран монитора: рисует текстовый экран ПК и отправляет нажатия клавиш на сервер. */
@SideOnly(Side.CLIENT)
public class GuiMonitor extends GuiContainer {
    private static final int CW = 6, CH = 9;
    private static final int[] PAL = {
            0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xAA5500, 0xAAAAAA,
            0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};
    private static final int[] RGB = {0xFF5555, 0x55FF55, 0x5555FF, 0xFF55FF, 0x55FFFF, 0xFFFF55};
    private final TileComputer tile;

    public GuiMonitor(Container c, TileComputer t) {
        super(c);
        this.tile = t;
        this.xSize = 380;
        this.ySize = 250;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void initGui() {
        super.initGui();
        Keyboard.enableRepeatEvents(true);
        buttonList.add(new GuiButton(0, guiLeft + 10, guiTop + 218, 70, 20, "Power"));
        buttonList.add(new GuiButton(1, guiLeft + 86, guiTop + 218, 70, 20, "Reset"));
        buttonList.add(new GuiButton(2, guiLeft + 162, guiTop + 218, 90, 20, "Hardware"));
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        super.onGuiClosed();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    protected void actionPerformed(GuiButton b) {
        int type = b.id == 0 ? 1 : b.id == 1 ? 2 : 3;
        PCMod.net.sendToServer(new PacketAction(tile.xCoord, tile.yCoord, tile.zCoord, type, (char) 0, 0));
    }

    @Override
    protected void keyTyped(char c, int key) {
        if (key == Keyboard.KEY_ESCAPE) {
            mc.thePlayer.closeScreen();
            return;
        }
        if (!tile.screen.on) return;
        // клавиши-модификаторы сами по себе не отправляем
        if (key == 42 || key == 54 || key == 29 || key == 157 || key == 56 || key == 184 || key == 58) return;
        PCMod.net.sendToServer(new PacketAction(tile.xCoord, tile.yCoord, tile.zCoord, 0, c, key));
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) {
        super.mouseClicked(mx, my, button);
        if (button != 0 || !tile.screen.on || tile.screen.noSignal) return;
        int sx = guiLeft + 10, sy = guiTop + 8;
        if (mx < sx || my < sy) return;
        int cx = (mx - sx) / CW, cy = (my - sy) / CH;
        if (cx >= Screen.W || cy >= Screen.H) return;
        PCMod.net.sendToServer(new PacketAction(tile.xCoord, tile.yCoord, tile.zCoord, 5, (char) cx, cy));
    }

    /** Цвет символа с учётом видеокарты и типа монитора. */
    private int color(int fg, int tier, MonitorType mt) {
        if (mt.mono) return fg >= 8 ? mt.monoBright : fg == 0 ? 0x000000 : mt.monoDim;
        if (tier == 1) return fg >= 8 ? 0x33FF33 : fg == 0 ? 0x000000 : 0x1E9E1E;
        return PAL[fg & 15];
    }

    /** Пиксельные иконки PixelOS: каждый пиксель иконки - один пиксель экрана GUI, соседние одинаковые склеиваются в полосы. */
    private void drawSprites(Screen sc, int sx, int sy, MonitorType mt) {
        for (int i = 0; i < sc.spN; i++) {
            int id = sc.spId[i] & 0xFF;
            if (id >= Sprites.ART.length) continue;
            String[] art = Sprites.ART[id];
            int sh = art.length, sw = art[0].length();
            int bx = sx + (sc.spX[i] & 0xFF) * CW + (sw >= 16 ? 1 : 2);
            int by = sy + (sc.spY[i] & 0xFF) * CH + (sh >= 16 ? 1 : 0);
            for (int yy = 0; yy < sh; yy++) {
                String row = art[yy];
                int xx = 0;
                while (xx < sw) {
                    char c = row.charAt(xx);
                    if (c == '.') {
                        xx++;
                        continue;
                    }
                    int x2 = xx + 1;
                    while (x2 < sw && row.charAt(x2) == c) x2++;
                    int ci = Character.digit(c, 16);
                    if (ci >= 0) drawRect(bx + xx, by + yy, bx + x2, by + yy + 1, 0xFF000000 | color(ci, sc.gpuTier, mt));
                    xx = x2;
                }
            }
        }
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float pt, int mx, int my) {
        int l = guiLeft, t = guiTop;
        int mon = tile.monitorType();
        if (mon < 0) {
            drawRect(l, t, l + xSize, t + ySize, 0xFF3A3A3A);
            fontRendererObj.drawString("No monitor connected.", l + 130, t + 100, 0xFF5555);
            fontRendererObj.drawString("Place a monitor next to the case or use video cables.", l + 85, t + 115, 0xAAAAAA);
            return;
        }
        MonitorType mt = MonitorType.get(mon);
        drawRect(l, t, l + xSize, t + ySize, mt.bezel);
        if (mt.rgb) {
            int c = 0xFF000000 | RGB[(int) ((System.currentTimeMillis() / 400L) % RGB.length)];
            drawRect(l, t + ySize - 4, l + xSize, t + ySize, c);
        }
        fontRendererObj.drawString(mt.name, l + 262, t + 224, 0xAAAAAA);
        int sx = l + 10, sy = t + 8;
        drawRect(sx - 2, sy - 2, sx + Screen.W * CW + 2, sy + Screen.H * CH + 2, 0xFF000000);

        Screen sc = tile.screen;
        // индикатор питания
        drawRect(l + xSize - 24, t + 226, l + xSize - 14, t + 232, sc.on ? 0xFF33FF33 : 0xFF551111);

        if (!sc.on) {
            fontRendererObj.drawString("Monitor is off. Press Power.", sx + 90, sy + 95, 0x666666);
            return;
        }
        if (sc.noSignal) {
            fontRendererObj.drawString("NO SIGNAL", sx + 140, sy + 95, 0xAAAAAA);
            return;
        }
        for (int y = 0; y < Screen.H; y++) {
            int py = sy + y * CH;
            // фон: подряд идущие инверсные клетки одного цвета рисуем одним прямоугольником
            int x = 0;
            while (x < Screen.W) {
                int at = sc.at[y * Screen.W + x] & 0xFF;
                if ((at & 16) == 0) {
                    x++;
                    continue;
                }
                int bg = color(at & 15, sc.gpuTier, mt);
                int x2 = x + 1;
                while (x2 < Screen.W) {
                    int at2 = sc.at[y * Screen.W + x2] & 0xFF;
                    if ((at2 & 16) == 0 || (at2 & 15) != (at & 15)) break;
                    x2++;
                }
                drawRect(sx + x * CW, py, sx + x2 * CW, py + CH, 0xFF000000 | bg);
                x = x2;
            }
            // символы
            for (x = 0; x < Screen.W; x++) {
                int i = y * Screen.W + x;
                char ch = sc.ch[i];
                if (ch == ' ') continue;
                int at = sc.at[i] & 0xFF;
                int fg = (at & 16) != 0 ? 0x000000 : color(at & 15, sc.gpuTier, mt);
                fontRendererObj.drawString(String.valueOf(ch), sx + x * CW, py + 1, fg);
            }
        }
        drawSprites(sc, sx, sy, mt);
        if (sc.cursor && (System.currentTimeMillis() / 500L) % 2L == 0L && sc.cx < Screen.W && sc.cy < Screen.H) {
            int px = sx + sc.cx * CW, py = sy + sc.cy * CH;
            drawRect(px, py + CH - 2, px + CW - 1, py + CH, 0xFF000000 | color(7, sc.gpuTier, mt));
        }
        if (mt.scanlines) {
            for (int y = 1; y < Screen.H * CH; y += 2) {
                drawRect(sx, sy + y, sx + Screen.W * CW, sy + y + 1, 0x44000000);
            }
        }
    }
}
