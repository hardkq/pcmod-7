package ru.pcmod.client;

import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.client.registry.RenderingRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.world.World;
import ru.pcmod.common.BlockWire;
import ru.pcmod.common.CommonProxy;
import ru.pcmod.common.TileComputer;

public class ClientProxy extends CommonProxy {
    @Override
    public World clientWorld() {
        return Minecraft.getMinecraft().theWorld;
    }

    @Override
    public void registerRenderers() {
        BlockWire.renderId = RenderingRegistry.getNextAvailableRenderId();
        RenderingRegistry.registerBlockHandler(new CableRenderer());
        ClientRegistry.bindTileEntitySpecialRenderer(TileComputer.class, new RenderComputer());
    }
}
