package ru.pcmod.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Slot;
import ru.pcmod.PCMod;
import ru.pcmod.common.ContainerComputer;
import ru.pcmod.common.PacketAction;
import ru.pcmod.common.PartSpec;
import ru.pcmod.common.TileComputer;

/** Сервисная панель: установка комплектующих и диагностика совместимости. */
@SideOnly(Side.CLIENT)
public class GuiHardware extends GuiContainer {
    private static final String[] LABELS = {"MB", "CPU", "Cool", "RAM1", "RAM2", "RAM3", "RAM4", "GPU", "Disk", "PSU", "Media", "WiFi"};
    private final TileComputer tile;

    public GuiHardware(ContainerComputer c, TileComputer t) {
        super(c);
        this.tile = t;
        this.xSize = 176;
        this.ySize = 222;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void initGui() {
        super.initGui();
        buttonList.add(new GuiButton(0, guiLeft + 8, guiTop + 120, 62, 16, "Power on"));
        buttonList.add(new GuiButton(1, guiLeft + 74, guiTop + 120, 44, 16, "Reset"));
        buttonList.add(new GuiButton(2, guiLeft + 122, guiTop + 120, 46, 16, "Screen"));
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        if (!buttonList.isEmpty()) {
            ((GuiButton) buttonList.get(0)).displayString = tile.isOn() ? "Power off" : "Power on";
        }
    }

    @Override
    protected void actionPerformed(GuiButton b) {
        int type = b.id == 0 ? 1 : b.id == 1 ? 2 : 4;
        PCMod.net.sendToServer(new PacketAction(tile.xCoord, tile.yCoord, tile.zCoord, type, (char) 0, 0));
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float pt, int mx, int my) {
        int l = guiLeft, t = guiTop;
        drawRect(l, t, l + xSize, t + ySize, 0xFFC6C6C6);
        PartSpec mb = tile.spec(TileComputer.MB);
        for (Object o : inventorySlots.inventorySlots) {
            Slot s = (Slot) o;
            int x = l + s.xDisplayPosition, y = t + s.yDisplayPosition;
            drawRect(x - 1, y - 1, x + 17, y + 17, 0xFF373737);
            drawRect(x, y, x + 16, y + 16, 0xFF8B8B8B);
            int idx = s.getSlotIndex();
            if (s.inventory == tile && idx >= TileComputer.RAM0 && idx <= TileComputer.RAM3
                    && mb != null && idx - TileComputer.RAM0 >= mb.ramSlots) {
                drawRect(x, y, x + 16, y + 16, 0xAAAA0000); // слот недоступен на этой плате
            }
        }
    }

    @Override
    @SuppressWarnings("rawtypes")
    protected void drawGuiContainerForegroundLayer(int mx, int my) {
        fontRendererObj.drawString("PC Hardware", 8, 5, 0x404040);
        for (int i = 0; i < TileComputer.SLOTS; i++) {
            int[] p = ContainerComputer.POS[i];
            fontRendererObj.drawString(LABELS[i], p[0], p[1] - 10, 0x404040);
        }
        List<String> lines = new ArrayList<String>();
        List<Integer> cols = new ArrayList<Integer>();
        String led = tile.screen.led;
        if (led != null && led.length() > 0) {
            lines.add("LED: " + led);
            cols.add(0xAA0000);
        }
        for (String e : tile.errors()) {
            lines.add("x " + e);
            cols.add(0xAA0000);
        }
        for (String w : tile.warnings()) {
            lines.add("! " + w);
            cols.add(0x996600);
        }
        if (tile.errors().isEmpty() && (led == null || led.length() == 0)) {
            lines.add(tile.isOn() ? "Running. Power off to change parts." : "Build OK, ready to boot.");
            cols.add(0x007700);
        }
        int y = 80, rows = 0;
        for (int i = 0; i < lines.size() && rows < 4; i++) {
            List wrapped = fontRendererObj.listFormattedStringToWidth(lines.get(i), 160);
            for (Object w : wrapped) {
                if (rows >= 4) break;
                fontRendererObj.drawString((String) w, 8, y, cols.get(i));
                y += 9;
                rows++;
            }
        }
    }
}
