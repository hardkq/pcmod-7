package ru.pcmod.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.tileentity.TileEntity;
import org.lwjgl.input.Keyboard;
import ru.pcmod.PCMod;
import net.minecraft.inventory.Slot;
import ru.pcmod.common.ContainerBlank;
import ru.pcmod.common.ContainerServer;
import ru.pcmod.common.PacketNetConfig;
import ru.pcmod.common.TileRouter;
import ru.pcmod.common.TileServer;

/** Настройки роутера (SSID, пароль, Wi-Fi вкл/выкл) и сервера (домен, данные чата, отсеки под HDD). */
@SideOnly(Side.CLIENT)
public class GuiNetDevice extends GuiContainer {
    private final TileEntity te;
    private final boolean router;
    private GuiTextField f1, f2;
    private boolean wifi, synced, clearPass, confirmWipe;

    public GuiNetDevice(ContainerBlank c, TileEntity te) {
        super(c);
        this.te = te;
        this.router = te instanceof TileRouter;
        this.xSize = 200;
        this.ySize = router ? 128 : 230;
        if (router) wifi = ((TileRouter) te).wifiOn;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void initGui() {
        super.initGui();
        Keyboard.enableRepeatEvents(true);
        f1 = new GuiTextField(fontRendererObj, guiLeft + 62, guiTop + 22, 128, 16);
        f1.setMaxStringLength(router ? 16 : 20);
        f1.setFocused(true);
        if (router) {
            f2 = new GuiTextField(fontRendererObj, guiLeft + 62, guiTop + 46, 128, 16);
            f2.setMaxStringLength(16);
            buttonList.add(new GuiButton(0, guiLeft + 10, guiTop + 74, 85, 20, "Wi-Fi: ON"));
            buttonList.add(new GuiButton(1, guiLeft + 105, guiTop + 74, 85, 20, "[ ] No password"));
            buttonList.add(new GuiButton(2, guiLeft + 10, guiTop + 100, 85, 20, "Save"));
            buttonList.add(new GuiButton(3, guiLeft + 105, guiTop + 100, 85, 20, "Close"));
        } else {
            buttonList.add(new GuiButton(2, guiLeft + 10, guiTop + 88, 85, 20, "Save"));
            buttonList.add(new GuiButton(4, guiLeft + 105, guiTop + 88, 85, 20, "Wipe chat data"));
        }
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        super.onGuiClosed();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        f1.updateCursorCounter();
        if (f2 != null) f2.updateCursorCounter();
        if (!synced) {
            // данные блока приходят отдельным пакетом, возможно уже после открытия окна
            String v = router ? ((TileRouter) te).ssid : ((TileServer) te).domain;
            if (v.length() > 0) {
                f1.setText(v);
                if (router) wifi = ((TileRouter) te).wifiOn;
                synced = true;
            }
        }
        if (router) {
            ((GuiButton) buttonList.get(0)).displayString = "Wi-Fi: " + (wifi ? "ON" : "OFF");
            ((GuiButton) buttonList.get(1)).displayString = clearPass ? "[x] No password" : "[ ] No password";
        } else {
            ((GuiButton) buttonList.get(1)).displayString = confirmWipe ? "Click again!" : "Wipe chat data";
        }
    }

    private void save(boolean wipe) {
        int flags = 0;
        String a = f1.getText().trim(), b = "";
        if (router) {
            if (wifi) flags |= 1;
            if (clearPass) flags |= 2;
            b = f2.getText();
        } else if (wipe) {
            flags |= 4;
        }
        PCMod.net.sendToServer(new PacketNetConfig(te.xCoord, te.yCoord, te.zCoord, flags, a, b));
    }

    @Override
    protected void actionPerformed(GuiButton btn) {
        if (btn.id == 0) {
            wifi = !wifi;
        } else if (btn.id == 1) {
            clearPass = !clearPass;
        } else if (btn.id == 2) {
            save(false);
        } else if (btn.id == 3) {
            mc.thePlayer.closeScreen();
        } else if (btn.id == 4) {
            if (confirmWipe) {
                save(true);
                confirmWipe = false;
            } else {
                confirmWipe = true;
            }
        }
    }

    @Override
    protected void keyTyped(char c, int key) {
        if (key == Keyboard.KEY_ESCAPE) {
            mc.thePlayer.closeScreen();
            return;
        }
        if (key == Keyboard.KEY_TAB && f2 != null) {
            boolean first = f1.isFocused();
            f1.setFocused(!first);
            f2.setFocused(first);
            return;
        }
        if (key == Keyboard.KEY_RETURN) {
            save(false);
            return;
        }
        if (f1.isFocused()) f1.textboxKeyTyped(c, key);
        else if (f2 != null && f2.isFocused()) f2.textboxKeyTyped(c, key);
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) {
        super.mouseClicked(mx, my, button);
        f1.mouseClicked(mx, my, button);
        if (f2 != null) f2.mouseClicked(mx, my, button);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float pt, int mx, int my) {
        drawRect(guiLeft, guiTop, guiLeft + xSize, guiTop + ySize, 0xFFC6C6C6);
        if (!router) {
            // подложка под слоты (отсеки и инвентарь)
            for (Object o : inventorySlots.inventorySlots) {
                Slot s = (Slot) o;
                int sx = guiLeft + s.xDisplayPosition, sy = guiTop + s.yDisplayPosition;
                drawRect(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
                drawRect(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
            }
        }
        f1.drawTextBox();
        if (f2 != null) f2.drawTextBox();
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mx, int my) {
        if (router) {
            TileRouter r = (TileRouter) te;
            fontRendererObj.drawString("Router - Wi-Fi range " + r.range() + " blocks", 8, 6, 0x404040);
            fontRendererObj.drawString("SSID", 10, 26, 0x404040);
            fontRendererObj.drawString("Password", 10, 50, 0x404040);
            fontRendererObj.drawString(r.hasPassClient ? "Now: secured (empty field = keep it)" : "Now: open network, no password",
                    10, 64, 0x666666);
        } else {
            TileServer s = (TileServer) te;
            fontRendererObj.drawString("Server - chat service", 8, 6, 0x404040);
            fontRendererObj.drawString("Domain", 10, 26, 0x404040);
            fontRendererObj.drawString("Drives: " + s.driveCount() + " / " + s.bays() + "  (" + s.driveKB(-1) + " KB)", 10, 44, 0x404040);
            fontRendererObj.drawString("Accounts: " + s.cAcc + " / " + s.maxAccounts(), 10, 56, 0x404040);
            fontRendererObj.drawString("Messages: " + s.cMsg + " / " + s.maxMsgs(), 10, 68, 0x404040);
            fontRendererObj.drawString("Capacity grows with installed HDDs", 10, 78, 0x666666);
            fontRendererObj.drawString("Drive bays (HDD only)", 8, 110, 0x404040);
            fontRendererObj.drawString("Inventory", ContainerServer.INV_X, 138, 0x404040);
        }
    }
}
