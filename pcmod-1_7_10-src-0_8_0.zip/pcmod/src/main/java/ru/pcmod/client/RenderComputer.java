package ru.pcmod.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;
import ru.pcmod.common.BlockMonitor;
import ru.pcmod.common.MonitorType;
import ru.pcmod.common.Screen;
import ru.pcmod.common.Sprites;
import ru.pcmod.common.TileComputer;

/**
 * Рисует в мире:
 * - на лицевой грани соседнего блока монитора - живой экран ПК (ОС, рабочий стол, BIOS и т.д.);
 * - на лицевой грани корпуса - светодиод питания (выкл / запускается / работает / сбой).
 * Всё светится в темноте (полная яркость, без освещения).
 */
@SideOnly(Side.CLIENT)
public class RenderComputer extends TileEntitySpecialRenderer {
    private static final int CW = 6, CH = 9;
    private static final int PW = Screen.W * CW, PH = Screen.H * CH; // 360 x 198 «пикселей» экрана
    private static final int[] PAL = {
            0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xAA5500, 0xAAAAAA,
            0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};
    private static final int[] RGB = {0xFF5555, 0x55FF55, 0x5555FF, 0xFF55FF, 0x55FFFF, 0xFFFF55};

    /** Область экрана на лицевой грани монитора: от 1/16 слева, ширина 14/16, верх на 3/16 сверху. */
    private static final float SCALE = (14f / 16f) / PW;
    private static final float SX0 = -0.5f + 1f / 16f;
    private static final float SY0 = 0.5f - 3f / 16f;
    /** Лицевая грань блока в локальных координатах (чуть наружу, чтобы не пересекаться с текстурой блока). */
    private static final float Z = 0.5f + 0.0005f;
    /** Дальше этого расстояния (в блоках) вместо букв рисуются цветные полосы, а иконки пропускаются. */
    private static final double TEXT_DIST = 14.0, SPRITE_DIST = 40.0, SCAN_DIST = 10.0;

    private final Tessellator tess = Tessellator.instance;

    @Override
    public void renderTileEntityAt(TileEntity te, double x, double y, double z, float pt) {
        if (!(te instanceof TileComputer)) return;
        TileComputer c = (TileComputer) te;
        World w = c.getWorldObj();
        if (w == null) return;

        GL11.glPushMatrix();
        GL11.glPushAttrib(GL11.GL_ENABLE_BIT | GL11.GL_COLOR_BUFFER_BIT | GL11.GL_POLYGON_BIT | GL11.GL_LIGHTING_BIT);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240f, 240f);

        // светодиод на лицевой грани корпуса
        GL11.glPushMatrix();
        GL11.glTranslated(x + 0.5, y + 0.5, z + 0.5);
        GL11.glRotatef(angle(front(c.getBlockMetadata())), 0f, 1f, 0f);
        drawLed(c.screen);
        GL11.glPopMatrix();

        // экран на каждом подключённом мониторе (вплотную или через видеокабели)
        for (int[] mp : c.monitors()) {
            int mx = mp[0], my = mp[1], mz = mp[2];
            if (!w.blockExists(mx, my, mz)) continue;
            Block b = w.getBlock(mx, my, mz);
            if (!(b instanceof BlockMonitor)) continue;
            int side = front(w.getBlockMetadata(mx, my, mz));
            // перед лицом монитора сплошной блок (например, корпус или стена) - экрана снаружи не видно
            int fx = mx + sideX(side), fz = mz + sideZ(side);
            if (w.blockExists(fx, my, fz) && w.getBlock(fx, my, fz).isOpaqueCube()) continue;
            double cx = x + (mx - c.xCoord) + 0.5, cy = y + (my - c.yCoord) + 0.5, cz = z + (mz - c.zCoord) + 0.5;
            double dist = Math.sqrt(cx * cx + cy * cy + cz * cz);
            GL11.glPushMatrix();
            GL11.glTranslated(cx, cy, cz);
            GL11.glRotatef(angle(side), 0f, 1f, 0f);
            drawMonitor(c.screen, MonitorType.get(((BlockMonitor) b).type), dist);
            GL11.glPopMatrix();
        }

        GL11.glPopAttrib();
        GL11.glColor4f(1f, 1f, 1f, 1f);
        // вернуть освещение, как у обычного блока
        int light = w.getLightBrightnessForSkyBlocks(c.xCoord, c.yCoord, c.zCoord, 0);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, light % 65536, light / 65536);
        GL11.glPopMatrix();
    }

    // ===================== геометрия =====================

    /** Сторона лица блока по метадате (как в getIcon): 2 = север, 3 = юг, 4 = запад, 5 = восток. */
    private static int front(int meta) {
        return meta < 2 || meta > 5 ? 3 : meta;
    }

    /** Поворот вокруг Y, после которого лицевая грань смотрит в локальный +Z. */
    private static float angle(int side) {
        switch (side) {
            case 5: return 90f;
            case 2: return 180f;
            case 4: return 270f;
            default: return 0f;
        }
    }

    private static int sideX(int side) {
        return side == 5 ? 1 : side == 4 ? -1 : 0;
    }

    private static int sideZ(int side) {
        return side == 3 ? 1 : side == 2 ? -1 : 0;
    }

    // ===================== рисование прямоугольников =====================

    private void begin(float layer) {
        GL11.glPolygonOffset(-layer, -layer);
        tess.startDrawingQuads();
    }

    private void end() {
        tess.draw();
    }

    /** Прямоугольник в координатах блока (единицы 1/16 от левого верхнего угла грани). */
    private void blockRect(float x0, float y0, float x1, float y1, int rgb) {
        float lx0 = -0.5f + x0 / 16f, lx1 = -0.5f + x1 / 16f, ly0 = 0.5f - y1 / 16f, ly1 = 0.5f - y0 / 16f;
        tess.setColorOpaque_I(rgb);
        tess.addVertex(lx0, ly0, Z);
        tess.addVertex(lx1, ly0, Z);
        tess.addVertex(lx1, ly1, Z);
        tess.addVertex(lx0, ly1, Z);
    }

    /** Прямоугольник в «пикселях» экрана (0..360 x 0..198, начало слева сверху). */
    private void pxRect(float x0, float y0, float x1, float y1, int rgb, int alpha) {
        float lx0 = SX0 + x0 * SCALE, lx1 = SX0 + x1 * SCALE, ly0 = SY0 - y1 * SCALE, ly1 = SY0 - y0 * SCALE;
        if (alpha >= 255) tess.setColorOpaque_I(rgb);
        else tess.setColorRGBA_I(rgb, alpha);
        tess.addVertex(lx0, ly0, Z);
        tess.addVertex(lx1, ly0, Z);
        tess.addVertex(lx1, ly1, Z);
        tess.addVertex(lx0, ly1, Z);
    }

    // ===================== светодиод на корпусе =====================

    private void drawLed(Screen sc) {
        long now = System.currentTimeMillis();
        int col;
        switch (sc.stage) {
            case 1: col = (now / 250L) % 2L == 0L ? 0xFFAA00 : 0x553300; break;   // запускается: янтарный, мигает
            case 2: col = 0x33FF33; break;                                          // работает: зелёный
            case 3: col = (now / 160L) % 2L == 0L ? 0xFF2222 : 0x440808; break;    // сбой / ОС не найдена: красный, мигает часто
            default: col = 0x2A0E0E; break;                                         // выключен: еле тлеет
        }
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        begin(1f);
        blockRect(10.5f, 11.5f, 14.5f, 14.5f, 0x0C0C0C); // подложка
        end();
        begin(2f);
        blockRect(11.25f, 12.25f, 13.75f, 13.75f, col);
        end();
        if (sc.stage != 0) {
            // мягкое свечение вокруг включённого светодиода
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
            begin(3f);
            float lx0 = -0.5f + 10f / 16f, lx1 = -0.5f + 15f / 16f, ly0 = 0.5f - 15.5f / 16f, ly1 = 0.5f - 11f / 16f;
            tess.setColorRGBA_I(col, 0x30);
            tess.addVertex(lx0, ly0, Z);
            tess.addVertex(lx1, ly0, Z);
            tess.addVertex(lx1, ly1, Z);
            tess.addVertex(lx0, ly1, Z);
            end();
            GL11.glDisable(GL11.GL_BLEND);
        }
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }

    // ===================== экран на мониторе =====================

    /** Цвет символа с учётом видеокарты и типа монитора (та же логика, что в GuiMonitor). */
    private static int color(int fg, int tier, MonitorType mt) {
        if (mt.mono) return fg >= 8 ? mt.monoBright : fg == 0 ? 0x000000 : mt.monoDim;
        if (tier == 1) return fg >= 8 ? 0x33FF33 : fg == 0 ? 0x000000 : 0x1E9E1E;
        return PAL[fg & 15];
    }

    private void drawMonitor(Screen sc, MonitorType mt, double dist) {
        long now = System.currentTimeMillis();
        GL11.glDisable(GL11.GL_TEXTURE_2D);

        // фон экрана и индикатор питания монитора
        begin(1f);
        pxRect(0, 0, PW, PH, sc.on ? 0x000000 : 0x0B0D0B, 255);
        end();
        begin(2f);
        blockRect(12.25f, 12.75f, 13.75f, 13.75f, sc.on ? 0x33FF33 : 0x331111);
        if (mt.rgb && sc.on) {
            // RGB-подсветка игрового монитора: бегущая полоса снизу
            long phase = now / 300L;
            for (int i = 0; i < 7; i++) {
                blockRect(1f + i * 2f, 14.5f, 3f + i * 2f, 15.5f, RGB[(int) ((i + phase) % RGB.length)]);
            }
        }
        end();

        if (!sc.on) {
            GL11.glEnable(GL11.GL_TEXTURE_2D);
            return;
        }
        if (sc.noSignal) {
            drawNoSignal(dist);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
            return;
        }

        // инверсные клетки (фон выделения)
        begin(3f);
        for (int y = 0; y < Screen.H; y++) {
            int x = 0;
            while (x < Screen.W) {
                int at = sc.at[y * Screen.W + x] & 0xFF;
                if ((at & 16) == 0) {
                    x++;
                    continue;
                }
                int x2 = x + 1;
                while (x2 < Screen.W) {
                    int at2 = sc.at[y * Screen.W + x2] & 0xFF;
                    if ((at2 & 16) == 0 || (at2 & 15) != (at & 15)) break;
                    x2++;
                }
                pxRect(x * CW, y * CH, x2 * CW, y * CH + CH, color(at & 15, sc.gpuTier, mt), 255);
                x = x2;
            }
        }
        end();

        // пиксельные иконки PixelOS
        if (dist < SPRITE_DIST && sc.spN > 0) {
            begin(4f);
            drawSprites(sc, mt);
            end();
        }

        if (dist < TEXT_DIST) {
            drawText(sc, mt);
        } else {
            // издалека буквы не разобрать - рисуем слова цветными полосами
            begin(5f);
            for (int y = 0; y < Screen.H; y++) {
                int x = 0;
                while (x < Screen.W) {
                    int i = y * Screen.W + x;
                    if (sc.ch[i] == ' ') {
                        x++;
                        continue;
                    }
                    int at = sc.at[i] & 0xFF;
                    int fg = (at & 16) != 0 ? 0x000000 : color(at & 15, sc.gpuTier, mt);
                    int x2 = x + 1;
                    while (x2 < Screen.W) {
                        int j = y * Screen.W + x2;
                        if (sc.ch[j] == ' ' || (sc.at[j] & 0xFF) != at) break;
                        x2++;
                    }
                    pxRect(x * CW + 1, y * CH + 2, x2 * CW - 1, y * CH + 7, fg, 255);
                    x = x2;
                }
            }
            end();
        }

        // курсор и развёртка ЭЛТ
        boolean cursor = sc.cursor && (now / 500L) % 2L == 0L && sc.cx < Screen.W && sc.cy < Screen.H;
        boolean scan = mt.scanlines && dist < SCAN_DIST;
        if (cursor) {
            begin(7f);
            int px = sc.cx * CW, py = sc.cy * CH;
            pxRect(px, py + CH - 2, px + CW - 1, py + CH, color(7, sc.gpuTier, mt), 255);
            end();
        }
        if (scan) {
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            begin(8f);
            for (int y = 1; y < PH; y += 2) pxRect(0, y, PW, y + 1, 0x000000, 0x44);
            end();
            GL11.glDisable(GL11.GL_BLEND);
        }
        GL11.glEnable(GL11.GL_TEXTURE_2D);
    }

    /** Пиксельные иконки: каждый пиксель иконки - один пиксель экрана, соседние одинаковые склеиваются в полосы. */
    private void drawSprites(Screen sc, MonitorType mt) {
        for (int i = 0; i < sc.spN; i++) {
            int id = sc.spId[i] & 0xFF;
            if (id >= Sprites.ART.length) continue;
            String[] art = Sprites.ART[id];
            int sh = art.length, sw = art[0].length();
            int bx = (sc.spX[i] & 0xFF) * CW + (sw >= 16 ? 1 : 2);
            int by = (sc.spY[i] & 0xFF) * CH + (sh >= 16 ? 1 : 0);
            for (int yy = 0; yy < sh; yy++) {
                String row = art[yy];
                int xx = 0;
                while (xx < sw) {
                    char c = row.charAt(xx);
                    if (c == '.') {
                        xx++;
                        continue;
                    }
                    int x2 = xx + 1;
                    while (x2 < sw && row.charAt(x2) == c) x2++;
                    int ci = Character.digit(c, 16);
                    if (ci >= 0) pxRect(bx + xx, by + yy, bx + x2, by + yy + 1, color(ci, sc.gpuTier, mt), 255);
                    xx = x2;
                }
            }
        }
    }

    /** Текст шрифтом Minecraft, по одному символу в клетку, как в GuiMonitor. */
    private void drawText(Screen sc, MonitorType mt) {
        FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_ALPHA_TEST);
        GL11.glPolygonOffset(-6f, -6f);
        GL11.glPushMatrix();
        GL11.glTranslatef(SX0, SY0, Z);
        GL11.glScalef(SCALE, -SCALE, SCALE);
        for (int y = 0; y < Screen.H; y++) {
            for (int x = 0; x < Screen.W; x++) {
                int i = y * Screen.W + x;
                char ch = sc.ch[i];
                if (ch == ' ') continue;
                int at = sc.at[i] & 0xFF;
                int fg = (at & 16) != 0 ? 0x000000 : color(at & 15, sc.gpuTier, mt);
                fr.drawString(String.valueOf(ch), x * CW, y * CH + 1, 0xFF000000 | fg);
            }
        }
        GL11.glPopMatrix();
        GL11.glColor4f(1f, 1f, 1f, 1f);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
    }

    /** «NO SIGNAL» по центру экрана. */
    private void drawNoSignal(double dist) {
        if (dist >= TEXT_DIST) {
            begin(5f);
            pxRect(140, 92, 220, 102, 0xAAAAAA, 255);
            end();
            return;
        }
        FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_ALPHA_TEST);
        GL11.glPolygonOffset(-6f, -6f);
        GL11.glPushMatrix();
        GL11.glTranslatef(SX0, SY0, Z);
        GL11.glScalef(SCALE, -SCALE, SCALE);
        String s = "NO SIGNAL";
        fr.drawString(s, (PW - fr.getStringWidth(s)) / 2, PH / 2 - 4, 0xFFAAAAAA);
        GL11.glPopMatrix();
        GL11.glColor4f(1f, 1f, 1f, 1f);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
    }
}
