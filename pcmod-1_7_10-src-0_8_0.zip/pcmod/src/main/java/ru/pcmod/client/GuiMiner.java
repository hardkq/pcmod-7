package ru.pcmod.client;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Slot;
import ru.pcmod.common.ContainerMiner;
import ru.pcmod.common.TileMiner;

/** Окно майнер-фермы: статус, доход, температура, питание, кнопки Power / Collect и слоты деталей. */
@SideOnly(Side.CLIENT)
public class GuiMiner extends GuiContainer {
    private static final String[] STATUS = {"Off", "Mining", "No GPU installed", "PSU too weak",
            "Overheated - restart when cool", "No network (cable to a router)", "Storage full - Collect!"};
    private final ContainerMiner cm;
    private final TileMiner te;

    public GuiMiner(ContainerMiner c, TileMiner te) {
        super(c);
        this.cm = c;
        this.te = te;
        this.xSize = 200;
        this.ySize = ContainerMiner.HEIGHT;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void initGui() {
        super.initGui();
        buttonList.add(new GuiButton(0, guiLeft + 10, guiTop + 70, 85, 20, "Power"));
        buttonList.add(new GuiButton(1, guiLeft + 105, guiTop + 70, 85, 20, "Collect"));
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        ((GuiButton) buttonList.get(0)).displayString = cm.data[1] != 0 ? "Power: ON" : "Power: OFF";
        ((GuiButton) buttonList.get(1)).displayString = "Collect " + cm.data[8] + " K";
    }

    @Override
    protected void actionPerformed(GuiButton btn) {
        mc.playerController.sendEnchantPacket(inventorySlots.windowId, btn.id);
    }

    private static String f2(int v) {
        return (v / 100) + "." + (v % 100 < 10 ? "0" : "") + (v % 100);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float pt, int mx, int my) {
        drawRect(guiLeft, guiTop, guiLeft + xSize, guiTop + ySize, 0xFFC6C6C6);
        for (Object o : inventorySlots.inventorySlots) {
            Slot s = (Slot) o;
            int sx = guiLeft + s.xDisplayPosition, sy = guiTop + s.yDisplayPosition;
            drawRect(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            drawRect(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mx, int my) {
        int[] d = cm.data;
        int st = d[0] < 0 || d[0] >= STATUS.length ? 0 : d[0];
        String name = STATUS[st] + (st == 1 && d[5] >= 90 ? " (throttled)" : "");
        fontRendererObj.drawString("Miner Farm F" + (te.tier() + 1) + "  (" + te.gpuSlots() + " GPU)", 8, 6, 0x404040);
        fontRendererObj.drawString("Status: " + name, 10, 18, st == 1 ? 0x207020 : 0x802020);
        fontRendererObj.drawString("Hashrate: " + d[2] + " MH/s   Market x" + f2(d[3]), 10, 28, 0x404040);
        fontRendererObj.drawString("Income: " + (d[4] / 10) + "." + (d[4] % 10) + " K/hour", 10, 38, 0x404040);
        fontRendererObj.drawString("Temp: " + d[5] + " C    Power: " + d[6] + " / " + d[7] + " W", 10, 48, d[5] >= 90 ? 0x802020 : 0x404040);
        fontRendererObj.drawString("Mined: " + d[8] + " / " + d[9] + " K  (to your bank)", 10, 58, 0x404040);
        fontRendererObj.drawString("GPU (mining cards)", 10, 94, 0x404040);
        fontRendererObj.drawString("PSU", 10, 124, 0x404040);
        fontRendererObj.drawString("Cooler", 110, 124, 0x404040);
        fontRendererObj.drawString("Inventory", ContainerMiner.INV_X, 156, 0x404040);
    }
}
